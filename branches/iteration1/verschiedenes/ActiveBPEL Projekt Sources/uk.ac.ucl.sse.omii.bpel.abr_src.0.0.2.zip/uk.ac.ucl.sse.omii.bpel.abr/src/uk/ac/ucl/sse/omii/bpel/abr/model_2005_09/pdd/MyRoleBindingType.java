/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>My Role Binding Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleBindingType()
 * @model
 * @generated
 */
public final class MyRoleBindingType extends AbstractEnumerator {
	/**
	 * The '<em><b>RPC</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RPC</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RPC_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int RPC = 0;

	/**
	 * The '<em><b>RPCLIT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>RPCLIT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RPCLIT_LITERAL
	 * @model literal="RPC-LIT"
	 * @generated
	 * @ordered
	 */
	public static final int RPCLIT = 1;

	/**
	 * The '<em><b>MSG</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MSG</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MSG_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int MSG = 2;

	/**
	 * The '<em><b>EXTERNAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>EXTERNAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #EXTERNAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int EXTERNAL = 3;

	/**
	 * The '<em><b>RPC</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RPC
	 * @generated
	 * @ordered
	 */
	public static final MyRoleBindingType RPC_LITERAL = new MyRoleBindingType(RPC, "RPC", "RPC");

	/**
	 * The '<em><b>RPCLIT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RPCLIT
	 * @generated
	 * @ordered
	 */
	public static final MyRoleBindingType RPCLIT_LITERAL = new MyRoleBindingType(RPCLIT, "RPCLIT", "RPC-LIT");

	/**
	 * The '<em><b>MSG</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MSG
	 * @generated
	 * @ordered
	 */
	public static final MyRoleBindingType MSG_LITERAL = new MyRoleBindingType(MSG, "MSG", "MSG");

	/**
	 * The '<em><b>EXTERNAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #EXTERNAL
	 * @generated
	 * @ordered
	 */
	public static final MyRoleBindingType EXTERNAL_LITERAL = new MyRoleBindingType(EXTERNAL, "EXTERNAL", "EXTERNAL");

	/**
	 * An array of all the '<em><b>My Role Binding Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final MyRoleBindingType[] VALUES_ARRAY =
		new MyRoleBindingType[] {
			RPC_LITERAL,
			RPCLIT_LITERAL,
			MSG_LITERAL,
			EXTERNAL_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>My Role Binding Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>My Role Binding Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MyRoleBindingType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			MyRoleBindingType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>My Role Binding Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MyRoleBindingType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			MyRoleBindingType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>My Role Binding Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MyRoleBindingType get(int value) {
		switch (value) {
			case RPC: return RPC_LITERAL;
			case RPCLIT: return RPCLIT_LITERAL;
			case MSG: return MSG_LITERAL;
			case EXTERNAL: return EXTERNAL_LITERAL;
		}
		return null;	
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private MyRoleBindingType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //MyRoleBindingType
