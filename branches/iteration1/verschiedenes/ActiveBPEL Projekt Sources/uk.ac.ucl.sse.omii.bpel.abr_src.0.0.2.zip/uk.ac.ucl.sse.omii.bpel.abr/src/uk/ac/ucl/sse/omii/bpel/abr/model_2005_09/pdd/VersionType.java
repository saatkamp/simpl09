/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Version Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getEffectiveDate <em>Effective Date</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getExpirationDate <em>Expiration Date</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId <em>Id</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition <em>Running Process Disposition</em>}</li>
 * </ul>
 * </p>
 *
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getVersionType()
 * @model extendedMetaData="name='version_._type' kind='empty'"
 * @generated
 */
public interface VersionType extends EObject {
	/**
	 * Returns the value of the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effective Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effective Date</em>' attribute.
	 * @see #setEffectiveDate(Object)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getVersionType_EffectiveDate()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.DateTime"
	 *        extendedMetaData="kind='attribute' name='effectiveDate'"
	 * @generated
	 */
	Object getEffectiveDate();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getEffectiveDate <em>Effective Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effective Date</em>' attribute.
	 * @see #getEffectiveDate()
	 * @generated
	 */
	void setEffectiveDate(Object value);

	/**
	 * Returns the value of the '<em><b>Expiration Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Expiration Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Expiration Date</em>' attribute.
	 * @see #setExpirationDate(Object)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getVersionType_ExpirationDate()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.DateTime"
	 *        extendedMetaData="kind='attribute' name='expirationDate'"
	 * @generated
	 */
	Object getExpirationDate();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getExpirationDate <em>Expiration Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Expiration Date</em>' attribute.
	 * @see #getExpirationDate()
	 * @generated
	 */
	void setExpirationDate(Object value);

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see #unsetId()
	 * @see #setId(float)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getVersionType_Id()
	 * @model unique="false" unsettable="true" dataType="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionAttributeType"
	 *        extendedMetaData="kind='attribute' name='id'"
	 * @generated
	 */
	float getId();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #isSetId()
	 * @see #unsetId()
	 * @see #getId()
	 * @generated
	 */
	void setId(float value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetId()
	 * @see #getId()
	 * @see #setId(float)
	 * @generated
	 */
	void unsetId();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId <em>Id</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Id</em>' attribute is set.
	 * @see #unsetId()
	 * @see #getId()
	 * @see #setId(float)
	 * @generated
	 */
	boolean isSetId();

	/**
	 * Returns the value of the '<em><b>Running Process Disposition</b></em>' attribute.
	 * The default value is <code>"terminate"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Running Process Disposition</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Running Process Disposition</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @see #isSetRunningProcessDisposition()
	 * @see #unsetRunningProcessDisposition()
	 * @see #setRunningProcessDisposition(DispositionType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getVersionType_RunningProcessDisposition()
	 * @model default="terminate" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='runningProcessDisposition'"
	 * @generated
	 */
	DispositionType getRunningProcessDisposition();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition <em>Running Process Disposition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Running Process Disposition</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @see #isSetRunningProcessDisposition()
	 * @see #unsetRunningProcessDisposition()
	 * @see #getRunningProcessDisposition()
	 * @generated
	 */
	void setRunningProcessDisposition(DispositionType value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition <em>Running Process Disposition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetRunningProcessDisposition()
	 * @see #getRunningProcessDisposition()
	 * @see #setRunningProcessDisposition(DispositionType)
	 * @generated
	 */
	void unsetRunningProcessDisposition();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition <em>Running Process Disposition</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Running Process Disposition</em>' attribute is set.
	 * @see #unsetRunningProcessDisposition()
	 * @see #getRunningProcessDisposition()
	 * @see #setRunningProcessDisposition(DispositionType)
	 * @generated
	 */
	boolean isSetRunningProcessDisposition();

} // VersionType