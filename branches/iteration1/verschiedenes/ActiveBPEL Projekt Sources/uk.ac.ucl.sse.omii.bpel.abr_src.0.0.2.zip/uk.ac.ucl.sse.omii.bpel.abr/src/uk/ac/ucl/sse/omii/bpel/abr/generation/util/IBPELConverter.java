/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import org.w3c.dom.Document;

public interface IBPELConverter {

	/**
	 * Converting a BPEL DOM from one version to another (i.e. from BPEL 2.0
	 * source to BPEL 1.1).
	 * 
	 * @param dom <code>Document</code> containing source to be converted
	 */
	public void convertBpel(Document dom);
}
