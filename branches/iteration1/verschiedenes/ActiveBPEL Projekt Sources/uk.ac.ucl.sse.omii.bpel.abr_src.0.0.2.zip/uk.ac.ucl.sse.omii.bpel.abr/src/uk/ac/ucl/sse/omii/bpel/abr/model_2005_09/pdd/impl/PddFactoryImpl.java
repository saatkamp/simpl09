/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddFactory;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PddFactoryImpl extends EFactoryImpl implements PddFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PddFactory init() {
		try {
			PddFactory thePddFactory = (PddFactory)EPackage.Registry.INSTANCE.getEFactory("http://schemas.active-endpoints.com/pdd/2005/09/pdd.xsd"); 
			if (thePddFactory != null) {
				return thePddFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PddFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case PddPackage.DOCUMENT_ROOT: return createDocumentRoot();
			case PddPackage.INDEXED_PROPERTIES_TYPE: return createIndexedPropertiesType();
			case PddPackage.INDEXED_PROPERTY_TYPE: return createIndexedPropertyType();
			case PddPackage.MY_ROLE_TYPE: return createMyRoleType();
			case PddPackage.PARTNER_LINKS_TYPE: return createPartnerLinksType();
			case PddPackage.PARTNER_LINK_TYPE: return createPartnerLinkType();
			case PddPackage.PARTNER_ROLE_TYPE: return createPartnerRoleType();
			case PddPackage.PROCESS_TYPE: return createProcessType();
			case PddPackage.VARIABLE_TYPE: return createVariableType();
			case PddPackage.VARIABLE_TYPE1: return createVariableType1();
			case PddPackage.VERSION_TYPE: return createVersionType();
			case PddPackage.WSDL_REFERENCES_TYPE: return createWsdlReferencesType();
			case PddPackage.WSDL_TYPE: return createWsdlType();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case PddPackage.DISPOSITION_TYPE:
				return createDispositionTypeFromString(eDataType, initialValue);
			case PddPackage.MY_ROLE_BINDING_TYPE:
				return createMyRoleBindingTypeFromString(eDataType, initialValue);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE:
				return createPartnerRoleEndpointReferenceTypeFromString(eDataType, initialValue);
			case PddPackage.PERSISTENCE_TYPE:
				return createPersistenceTypeFromString(eDataType, initialValue);
			case PddPackage.SUSPEND_FLAG:
				return createSuspendFlagFromString(eDataType, initialValue);
			case PddPackage.TRANSACTION_TYPE:
				return createTransactionTypeFromString(eDataType, initialValue);
			case PddPackage.CUSTOM_INVOKER_URI_TYPE:
				return createCustomInvokerUriTypeFromString(eDataType, initialValue);
			case PddPackage.DISPOSITION_TYPE_OBJECT:
				return createDispositionTypeObjectFromString(eDataType, initialValue);
			case PddPackage.INVOKE_HANDLER_TYPE:
				return createInvokeHandlerTypeFromString(eDataType, initialValue);
			case PddPackage.MY_ROLE_BINDING_TYPE_OBJECT:
				return createMyRoleBindingTypeObjectFromString(eDataType, initialValue);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT:
				return createPartnerRoleEndpointReferenceTypeObjectFromString(eDataType, initialValue);
			case PddPackage.PERSISTENCE_TYPE_OBJECT:
				return createPersistenceTypeObjectFromString(eDataType, initialValue);
			case PddPackage.SUSPEND_FLAG_OBJECT:
				return createSuspendFlagObjectFromString(eDataType, initialValue);
			case PddPackage.TRANSACTION_TYPE_OBJECT:
				return createTransactionTypeObjectFromString(eDataType, initialValue);
			case PddPackage.VERSION_ATTRIBUTE_TYPE:
				return createVersionAttributeTypeFromString(eDataType, initialValue);
			case PddPackage.VERSION_ATTRIBUTE_TYPE_OBJECT:
				return createVersionAttributeTypeObjectFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case PddPackage.DISPOSITION_TYPE:
				return convertDispositionTypeToString(eDataType, instanceValue);
			case PddPackage.MY_ROLE_BINDING_TYPE:
				return convertMyRoleBindingTypeToString(eDataType, instanceValue);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE:
				return convertPartnerRoleEndpointReferenceTypeToString(eDataType, instanceValue);
			case PddPackage.PERSISTENCE_TYPE:
				return convertPersistenceTypeToString(eDataType, instanceValue);
			case PddPackage.SUSPEND_FLAG:
				return convertSuspendFlagToString(eDataType, instanceValue);
			case PddPackage.TRANSACTION_TYPE:
				return convertTransactionTypeToString(eDataType, instanceValue);
			case PddPackage.CUSTOM_INVOKER_URI_TYPE:
				return convertCustomInvokerUriTypeToString(eDataType, instanceValue);
			case PddPackage.DISPOSITION_TYPE_OBJECT:
				return convertDispositionTypeObjectToString(eDataType, instanceValue);
			case PddPackage.INVOKE_HANDLER_TYPE:
				return convertInvokeHandlerTypeToString(eDataType, instanceValue);
			case PddPackage.MY_ROLE_BINDING_TYPE_OBJECT:
				return convertMyRoleBindingTypeObjectToString(eDataType, instanceValue);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT:
				return convertPartnerRoleEndpointReferenceTypeObjectToString(eDataType, instanceValue);
			case PddPackage.PERSISTENCE_TYPE_OBJECT:
				return convertPersistenceTypeObjectToString(eDataType, instanceValue);
			case PddPackage.SUSPEND_FLAG_OBJECT:
				return convertSuspendFlagObjectToString(eDataType, instanceValue);
			case PddPackage.TRANSACTION_TYPE_OBJECT:
				return convertTransactionTypeObjectToString(eDataType, instanceValue);
			case PddPackage.VERSION_ATTRIBUTE_TYPE:
				return convertVersionAttributeTypeToString(eDataType, instanceValue);
			case PddPackage.VERSION_ATTRIBUTE_TYPE_OBJECT:
				return convertVersionAttributeTypeObjectToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DocumentRoot createDocumentRoot() {
		DocumentRootImpl documentRoot = new DocumentRootImpl();
		return documentRoot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IndexedPropertiesType createIndexedPropertiesType() {
		IndexedPropertiesTypeImpl indexedPropertiesType = new IndexedPropertiesTypeImpl();
		return indexedPropertiesType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IndexedPropertyType createIndexedPropertyType() {
		IndexedPropertyTypeImpl indexedPropertyType = new IndexedPropertyTypeImpl();
		return indexedPropertyType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyRoleType createMyRoleType() {
		MyRoleTypeImpl myRoleType = new MyRoleTypeImpl();
		return myRoleType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerLinksType createPartnerLinksType() {
		PartnerLinksTypeImpl partnerLinksType = new PartnerLinksTypeImpl();
		return partnerLinksType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerLinkType createPartnerLinkType() {
		PartnerLinkTypeImpl partnerLinkType = new PartnerLinkTypeImpl();
		return partnerLinkType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerRoleType createPartnerRoleType() {
		PartnerRoleTypeImpl partnerRoleType = new PartnerRoleTypeImpl();
		return partnerRoleType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ProcessType createProcessType() {
		ProcessTypeImpl processType = new ProcessTypeImpl();
		return processType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VariableType createVariableType() {
		VariableTypeImpl variableType = new VariableTypeImpl();
		return variableType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VariableType1 createVariableType1() {
		VariableType1Impl variableType1 = new VariableType1Impl();
		return variableType1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VersionType createVersionType() {
		VersionTypeImpl versionType = new VersionTypeImpl();
		return versionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WsdlReferencesType createWsdlReferencesType() {
		WsdlReferencesTypeImpl wsdlReferencesType = new WsdlReferencesTypeImpl();
		return wsdlReferencesType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WsdlType createWsdlType() {
		WsdlTypeImpl wsdlType = new WsdlTypeImpl();
		return wsdlType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DispositionType createDispositionTypeFromString(EDataType eDataType, String initialValue) {
		DispositionType result = DispositionType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDispositionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyRoleBindingType createMyRoleBindingTypeFromString(EDataType eDataType, String initialValue) {
		MyRoleBindingType result = MyRoleBindingType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMyRoleBindingTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerRoleEndpointReferenceType createPartnerRoleEndpointReferenceTypeFromString(EDataType eDataType, String initialValue) {
		PartnerRoleEndpointReferenceType result = PartnerRoleEndpointReferenceType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPartnerRoleEndpointReferenceTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PersistenceType createPersistenceTypeFromString(EDataType eDataType, String initialValue) {
		PersistenceType result = PersistenceType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPersistenceTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuspendFlag createSuspendFlagFromString(EDataType eDataType, String initialValue) {
		SuspendFlag result = SuspendFlag.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSuspendFlagToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransactionType createTransactionTypeFromString(EDataType eDataType, String initialValue) {
		TransactionType result = TransactionType.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTransactionTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createCustomInvokerUriTypeFromString(EDataType eDataType, String initialValue) {
		return (String)XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.ANY_URI, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCustomInvokerUriTypeToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.ANY_URI, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DispositionType createDispositionTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (DispositionType)createDispositionTypeFromString(PddPackage.Literals.DISPOSITION_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDispositionTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertDispositionTypeToString(PddPackage.Literals.DISPOSITION_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String createInvokeHandlerTypeFromString(EDataType eDataType, String initialValue) {
		return (String)XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.ANY_URI, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertInvokeHandlerTypeToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.ANY_URI, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyRoleBindingType createMyRoleBindingTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (MyRoleBindingType)createMyRoleBindingTypeFromString(PddPackage.Literals.MY_ROLE_BINDING_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMyRoleBindingTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertMyRoleBindingTypeToString(PddPackage.Literals.MY_ROLE_BINDING_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerRoleEndpointReferenceType createPartnerRoleEndpointReferenceTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (PartnerRoleEndpointReferenceType)createPartnerRoleEndpointReferenceTypeFromString(PddPackage.Literals.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPartnerRoleEndpointReferenceTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertPartnerRoleEndpointReferenceTypeToString(PddPackage.Literals.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PersistenceType createPersistenceTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (PersistenceType)createPersistenceTypeFromString(PddPackage.Literals.PERSISTENCE_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPersistenceTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertPersistenceTypeToString(PddPackage.Literals.PERSISTENCE_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuspendFlag createSuspendFlagObjectFromString(EDataType eDataType, String initialValue) {
		return (SuspendFlag)createSuspendFlagFromString(PddPackage.Literals.SUSPEND_FLAG, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSuspendFlagObjectToString(EDataType eDataType, Object instanceValue) {
		return convertSuspendFlagToString(PddPackage.Literals.SUSPEND_FLAG, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransactionType createTransactionTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (TransactionType)createTransactionTypeFromString(PddPackage.Literals.TRANSACTION_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTransactionTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertTransactionTypeToString(PddPackage.Literals.TRANSACTION_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Float createVersionAttributeTypeFromString(EDataType eDataType, String initialValue) {
		return (Float)XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.Literals.FLOAT, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertVersionAttributeTypeToString(EDataType eDataType, Object instanceValue) {
		return XMLTypeFactory.eINSTANCE.convertToString(XMLTypePackage.Literals.FLOAT, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Float createVersionAttributeTypeObjectFromString(EDataType eDataType, String initialValue) {
		return (Float)createVersionAttributeTypeFromString(PddPackage.Literals.VERSION_ATTRIBUTE_TYPE, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertVersionAttributeTypeObjectToString(EDataType eDataType, Object instanceValue) {
		return convertVersionAttributeTypeToString(PddPackage.Literals.VERSION_ATTRIBUTE_TYPE, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddPackage getPddPackage() {
		return (PddPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static PddPackage getPackage() {
		return PddPackage.eINSTANCE;
	}

} //PddFactoryImpl
