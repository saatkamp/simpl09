/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.FeatureMap;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>My Role Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAny <em>Any</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAllowedRoles <em>Allowed Roles</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding <em>Binding</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getService <em>Service</em>}</li>
 * </ul>
 * </p>
 *
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleType()
 * @model extendedMetaData="name='myRoleType' kind='elementOnly'"
 * @generated
 */
public interface MyRoleType extends EObject {
	/**
	 * Returns the value of the '<em><b>Any</b></em>' attribute list.
	 * The list contents are of type {@link org.eclipse.emf.ecore.util.FeatureMap.Entry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Any</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Any</em>' attribute list.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleType_Any()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.EFeatureMapEntry" many="true"
	 *        extendedMetaData="kind='elementWildcard' wildcards='##any' name=':0' processing='skip'"
	 * @generated
	 */
	FeatureMap getAny();

	/**
	 * Returns the value of the '<em><b>Allowed Roles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Allowed Roles</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Allowed Roles</em>' attribute.
	 * @see #setAllowedRoles(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleType_AllowedRoles()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
	 *        extendedMetaData="kind='attribute' name='allowedRoles'"
	 * @generated
	 */
	String getAllowedRoles();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAllowedRoles <em>Allowed Roles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Allowed Roles</em>' attribute.
	 * @see #getAllowedRoles()
	 * @generated
	 */
	void setAllowedRoles(String value);

	/**
	 * Returns the value of the '<em><b>Binding</b></em>' attribute.
	 * The default value is <code>"RPC"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Binding</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Binding</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @see #isSetBinding()
	 * @see #unsetBinding()
	 * @see #setBinding(MyRoleBindingType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleType_Binding()
	 * @model default="RPC" unique="false" unsettable="true" required="true"
	 *        extendedMetaData="kind='attribute' name='binding'"
	 * @generated
	 */
	MyRoleBindingType getBinding();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding <em>Binding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Binding</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @see #isSetBinding()
	 * @see #unsetBinding()
	 * @see #getBinding()
	 * @generated
	 */
	void setBinding(MyRoleBindingType value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding <em>Binding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetBinding()
	 * @see #getBinding()
	 * @see #setBinding(MyRoleBindingType)
	 * @generated
	 */
	void unsetBinding();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding <em>Binding</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Binding</em>' attribute is set.
	 * @see #unsetBinding()
	 * @see #getBinding()
	 * @see #setBinding(MyRoleBindingType)
	 * @generated
	 */
	boolean isSetBinding();

	/**
	 * Returns the value of the '<em><b>Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Service</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Service</em>' attribute.
	 * @see #setService(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getMyRoleType_Service()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='service'"
	 * @generated
	 */
	String getService();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getService <em>Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Service</em>' attribute.
	 * @see #getService()
	 * @generated
	 */
	void setService(String value);

} // MyRoleType