/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.BasicFeatureMap;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.InternalEList;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Partner Role Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl#getAny <em>Any</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl#getCustomInvokerUri <em>Custom Invoker Uri</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl#getEndpointReference <em>Endpoint Reference</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl#getInvokeHandler <em>Invoke Handler</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class PartnerRoleTypeImpl extends EObjectImpl implements PartnerRoleType {
	/**
	 * The cached value of the '{@link #getAny() <em>Any</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAny()
	 * @generated
	 * @ordered
	 */
	protected FeatureMap any = null;

	/**
	 * The default value of the '{@link #getCustomInvokerUri() <em>Custom Invoker Uri</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomInvokerUri()
	 * @generated
	 * @ordered
	 */
	protected static final String CUSTOM_INVOKER_URI_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCustomInvokerUri() <em>Custom Invoker Uri</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomInvokerUri()
	 * @generated
	 * @ordered
	 */
	protected String customInvokerUri = CUSTOM_INVOKER_URI_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndpointReference() <em>Endpoint Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndpointReference()
	 * @generated
	 * @ordered
	 */
	protected static final PartnerRoleEndpointReferenceType ENDPOINT_REFERENCE_EDEFAULT = PartnerRoleEndpointReferenceType.STATIC_LITERAL;

	/**
	 * The cached value of the '{@link #getEndpointReference() <em>Endpoint Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndpointReference()
	 * @generated
	 * @ordered
	 */
	protected PartnerRoleEndpointReferenceType endpointReference = ENDPOINT_REFERENCE_EDEFAULT;

	/**
	 * This is true if the Endpoint Reference attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean endpointReferenceESet = false;

	/**
	 * The default value of the '{@link #getInvokeHandler() <em>Invoke Handler</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInvokeHandler()
	 * @generated
	 * @ordered
	 */
	protected static final String INVOKE_HANDLER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInvokeHandler() <em>Invoke Handler</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInvokeHandler()
	 * @generated
	 * @ordered
	 */
	protected String invokeHandler = INVOKE_HANDLER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PartnerRoleTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PddPackage.Literals.PARTNER_ROLE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureMap getAny() {
		if (any == null) {
			any = new BasicFeatureMap(this, PddPackage.PARTNER_ROLE_TYPE__ANY);
		}
		return any;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCustomInvokerUri() {
		return customInvokerUri;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomInvokerUri(String newCustomInvokerUri) {
		String oldCustomInvokerUri = customInvokerUri;
		customInvokerUri = newCustomInvokerUri;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI, oldCustomInvokerUri, customInvokerUri));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerRoleEndpointReferenceType getEndpointReference() {
		return endpointReference;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndpointReference(PartnerRoleEndpointReferenceType newEndpointReference) {
		PartnerRoleEndpointReferenceType oldEndpointReference = endpointReference;
		endpointReference = newEndpointReference == null ? ENDPOINT_REFERENCE_EDEFAULT : newEndpointReference;
		boolean oldEndpointReferenceESet = endpointReferenceESet;
		endpointReferenceESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE, oldEndpointReference, endpointReference, !oldEndpointReferenceESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetEndpointReference() {
		PartnerRoleEndpointReferenceType oldEndpointReference = endpointReference;
		boolean oldEndpointReferenceESet = endpointReferenceESet;
		endpointReference = ENDPOINT_REFERENCE_EDEFAULT;
		endpointReferenceESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE, oldEndpointReference, ENDPOINT_REFERENCE_EDEFAULT, oldEndpointReferenceESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetEndpointReference() {
		return endpointReferenceESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInvokeHandler() {
		return invokeHandler;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInvokeHandler(String newInvokeHandler) {
		String oldInvokeHandler = invokeHandler;
		invokeHandler = newInvokeHandler;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PARTNER_ROLE_TYPE__INVOKE_HANDLER, oldInvokeHandler, invokeHandler));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PddPackage.PARTNER_ROLE_TYPE__ANY:
				return ((InternalEList)getAny()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PddPackage.PARTNER_ROLE_TYPE__ANY:
				if (coreType) return getAny();
				return ((FeatureMap.Internal)getAny()).getWrapper();
			case PddPackage.PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI:
				return getCustomInvokerUri();
			case PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE:
				return getEndpointReference();
			case PddPackage.PARTNER_ROLE_TYPE__INVOKE_HANDLER:
				return getInvokeHandler();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PddPackage.PARTNER_ROLE_TYPE__ANY:
				((FeatureMap.Internal)getAny()).set(newValue);
				return;
			case PddPackage.PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI:
				setCustomInvokerUri((String)newValue);
				return;
			case PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE:
				setEndpointReference((PartnerRoleEndpointReferenceType)newValue);
				return;
			case PddPackage.PARTNER_ROLE_TYPE__INVOKE_HANDLER:
				setInvokeHandler((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PddPackage.PARTNER_ROLE_TYPE__ANY:
				getAny().clear();
				return;
			case PddPackage.PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI:
				setCustomInvokerUri(CUSTOM_INVOKER_URI_EDEFAULT);
				return;
			case PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE:
				unsetEndpointReference();
				return;
			case PddPackage.PARTNER_ROLE_TYPE__INVOKE_HANDLER:
				setInvokeHandler(INVOKE_HANDLER_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PddPackage.PARTNER_ROLE_TYPE__ANY:
				return any != null && !any.isEmpty();
			case PddPackage.PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI:
				return CUSTOM_INVOKER_URI_EDEFAULT == null ? customInvokerUri != null : !CUSTOM_INVOKER_URI_EDEFAULT.equals(customInvokerUri);
			case PddPackage.PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE:
				return isSetEndpointReference();
			case PddPackage.PARTNER_ROLE_TYPE__INVOKE_HANDLER:
				return INVOKE_HANDLER_EDEFAULT == null ? invokeHandler != null : !INVOKE_HANDLER_EDEFAULT.equals(invokeHandler);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (any: ");
		result.append(any);
		result.append(", customInvokerUri: ");
		result.append(customInvokerUri);
		result.append(", endpointReference: ");
		if (endpointReferenceESet) result.append(endpointReference); else result.append("<unset>");
		result.append(", invokeHandler: ");
		result.append(invokeHandler);
		result.append(')');
		return result.toString();
	}

} //PartnerRoleTypeImpl