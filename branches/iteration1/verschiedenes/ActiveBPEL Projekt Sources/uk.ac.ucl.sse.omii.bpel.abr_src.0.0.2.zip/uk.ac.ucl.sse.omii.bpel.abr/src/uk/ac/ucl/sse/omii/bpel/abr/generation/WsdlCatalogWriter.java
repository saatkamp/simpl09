/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IBprConstants;

/**
 * Writes wsdlCatalogFiles from list of wsdl entries.
 * This is rubbish, but had no time at all to do any better :(
 * TODO use EMF or DOM and change all of this class!
 *
 * @author Bruno Wassermann, written Sep 13, 2006
 */
public class WsdlCatalogWriter {
	
	public WsdlCatalogWriter() {}
	
	/**
	 * Writes a wsdlCatalog.xml file in the most rubbish way, containing 
	 * the entries in wsdlEntryNames.
	 * For simplicity and 'coz got no time, this will create a file in a 
	 * default location (the ECLIPSE home dir). Clients might want to 
	 * delete this file once they are done.
	 *  
	 * @param wsdlEntryNames <code>List</code> of wsdlEntryNames in BPR file.
	 */
	public void write(List wsdlEntryNames) throws IOException {
		FileWriter fWriter = new FileWriter(IBprConstants.WSDL_CATALOG_FILE);
		
		StringBuffer buf = new StringBuffer();
		generateXMLPreamble(buf);
		generateWsdlCatalogStart(buf);
		
		for (Iterator iter = wsdlEntryNames.iterator(); iter.hasNext(); ) {	
			String wsdlEntry = (String) iter.next();
			generateWsdlEntry(buf, wsdlEntry);
			
		}		
		generateWsdlCatalogEnd(buf);
		fWriter.write(buf.toString());
		fWriter.flush();
		fWriter.close();
	}
	
	private void generateXMLPreamble(StringBuffer buf) {
		buf.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	}
	
	private void generateWsdlCatalogStart(StringBuffer buf) {
		buf.append("<wsdlCatalog xmlns='http://schemas.active-endpoints.com/wsdl-catalog/2005/09/wsdlCatalog.xml'>\n");
	}
	
	private void generateWsdlCatalogEnd(StringBuffer buf) {
		buf.append("</wsdlCatalog>");
	}
	
	private void generateWsdlEntry(StringBuffer buf, String wsdlEntry) {
		buf.append("<wsdlEntry location=\"" + wsdlEntry + "\" ");
		buf.append("classpath=\"" + wsdlEntry + "\"/>\n");
	}

}
