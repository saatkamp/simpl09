/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.BasicFeatureMap;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.InternalEList;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>My Role Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl#getAny <em>Any</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl#getAllowedRoles <em>Allowed Roles</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl#getBinding <em>Binding</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl#getService <em>Service</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MyRoleTypeImpl extends EObjectImpl implements MyRoleType {
	/**
	 * The cached value of the '{@link #getAny() <em>Any</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAny()
	 * @generated
	 * @ordered
	 */
	protected FeatureMap any = null;

	/**
	 * The default value of the '{@link #getAllowedRoles() <em>Allowed Roles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAllowedRoles()
	 * @generated
	 * @ordered
	 */
	protected static final String ALLOWED_ROLES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAllowedRoles() <em>Allowed Roles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAllowedRoles()
	 * @generated
	 * @ordered
	 */
	protected String allowedRoles = ALLOWED_ROLES_EDEFAULT;

	/**
	 * The default value of the '{@link #getBinding() <em>Binding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinding()
	 * @generated
	 * @ordered
	 */
	protected static final MyRoleBindingType BINDING_EDEFAULT = MyRoleBindingType.RPC_LITERAL;

	/**
	 * The cached value of the '{@link #getBinding() <em>Binding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBinding()
	 * @generated
	 * @ordered
	 */
	protected MyRoleBindingType binding = BINDING_EDEFAULT;

	/**
	 * This is true if the Binding attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean bindingESet = false;

	/**
	 * The default value of the '{@link #getService() <em>Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService()
	 * @generated
	 * @ordered
	 */
	protected static final String SERVICE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getService() <em>Service</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService()
	 * @generated
	 * @ordered
	 */
	protected String service = SERVICE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MyRoleTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PddPackage.Literals.MY_ROLE_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureMap getAny() {
		if (any == null) {
			any = new BasicFeatureMap(this, PddPackage.MY_ROLE_TYPE__ANY);
		}
		return any;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAllowedRoles() {
		return allowedRoles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAllowedRoles(String newAllowedRoles) {
		String oldAllowedRoles = allowedRoles;
		allowedRoles = newAllowedRoles;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.MY_ROLE_TYPE__ALLOWED_ROLES, oldAllowedRoles, allowedRoles));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MyRoleBindingType getBinding() {
		return binding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBinding(MyRoleBindingType newBinding) {
		MyRoleBindingType oldBinding = binding;
		binding = newBinding == null ? BINDING_EDEFAULT : newBinding;
		boolean oldBindingESet = bindingESet;
		bindingESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.MY_ROLE_TYPE__BINDING, oldBinding, binding, !oldBindingESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetBinding() {
		MyRoleBindingType oldBinding = binding;
		boolean oldBindingESet = bindingESet;
		binding = BINDING_EDEFAULT;
		bindingESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.MY_ROLE_TYPE__BINDING, oldBinding, BINDING_EDEFAULT, oldBindingESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetBinding() {
		return bindingESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getService() {
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setService(String newService) {
		String oldService = service;
		service = newService;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.MY_ROLE_TYPE__SERVICE, oldService, service));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PddPackage.MY_ROLE_TYPE__ANY:
				return ((InternalEList)getAny()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PddPackage.MY_ROLE_TYPE__ANY:
				if (coreType) return getAny();
				return ((FeatureMap.Internal)getAny()).getWrapper();
			case PddPackage.MY_ROLE_TYPE__ALLOWED_ROLES:
				return getAllowedRoles();
			case PddPackage.MY_ROLE_TYPE__BINDING:
				return getBinding();
			case PddPackage.MY_ROLE_TYPE__SERVICE:
				return getService();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PddPackage.MY_ROLE_TYPE__ANY:
				((FeatureMap.Internal)getAny()).set(newValue);
				return;
			case PddPackage.MY_ROLE_TYPE__ALLOWED_ROLES:
				setAllowedRoles((String)newValue);
				return;
			case PddPackage.MY_ROLE_TYPE__BINDING:
				setBinding((MyRoleBindingType)newValue);
				return;
			case PddPackage.MY_ROLE_TYPE__SERVICE:
				setService((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PddPackage.MY_ROLE_TYPE__ANY:
				getAny().clear();
				return;
			case PddPackage.MY_ROLE_TYPE__ALLOWED_ROLES:
				setAllowedRoles(ALLOWED_ROLES_EDEFAULT);
				return;
			case PddPackage.MY_ROLE_TYPE__BINDING:
				unsetBinding();
				return;
			case PddPackage.MY_ROLE_TYPE__SERVICE:
				setService(SERVICE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PddPackage.MY_ROLE_TYPE__ANY:
				return any != null && !any.isEmpty();
			case PddPackage.MY_ROLE_TYPE__ALLOWED_ROLES:
				return ALLOWED_ROLES_EDEFAULT == null ? allowedRoles != null : !ALLOWED_ROLES_EDEFAULT.equals(allowedRoles);
			case PddPackage.MY_ROLE_TYPE__BINDING:
				return isSetBinding();
			case PddPackage.MY_ROLE_TYPE__SERVICE:
				return SERVICE_EDEFAULT == null ? service != null : !SERVICE_EDEFAULT.equals(service);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (any: ");
		result.append(any);
		result.append(", allowedRoles: ");
		result.append(allowedRoles);
		result.append(", binding: ");
		if (bindingESet) result.append(binding); else result.append("<unset>");
		result.append(", service: ");
		result.append(service);
		result.append(')');
		return result.toString();
	}

} //MyRoleTypeImpl