/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Partner Role Endpoint Reference Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleEndpointReferenceType()
 * @model
 * @generated
 */
public final class PartnerRoleEndpointReferenceType extends AbstractEnumerator {
	/**
	 * The '<em><b>Static</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Static</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STATIC_LITERAL
	 * @model name="static"
	 * @generated
	 * @ordered
	 */
	public static final int STATIC = 0;

	/**
	 * The '<em><b>Dynamic</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Dynamic</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DYNAMIC_LITERAL
	 * @model name="dynamic"
	 * @generated
	 * @ordered
	 */
	public static final int DYNAMIC = 1;

	/**
	 * The '<em><b>Invoker</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Invoker</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #INVOKER_LITERAL
	 * @model name="invoker"
	 * @generated
	 * @ordered
	 */
	public static final int INVOKER = 2;

	/**
	 * The '<em><b>Principal</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Principal</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PRINCIPAL_LITERAL
	 * @model name="principal"
	 * @generated
	 * @ordered
	 */
	public static final int PRINCIPAL = 3;

	/**
	 * The '<em><b>Static</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STATIC
	 * @generated
	 * @ordered
	 */
	public static final PartnerRoleEndpointReferenceType STATIC_LITERAL = new PartnerRoleEndpointReferenceType(STATIC, "static", "static");

	/**
	 * The '<em><b>Dynamic</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DYNAMIC
	 * @generated
	 * @ordered
	 */
	public static final PartnerRoleEndpointReferenceType DYNAMIC_LITERAL = new PartnerRoleEndpointReferenceType(DYNAMIC, "dynamic", "dynamic");

	/**
	 * The '<em><b>Invoker</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #INVOKER
	 * @generated
	 * @ordered
	 */
	public static final PartnerRoleEndpointReferenceType INVOKER_LITERAL = new PartnerRoleEndpointReferenceType(INVOKER, "invoker", "invoker");

	/**
	 * The '<em><b>Principal</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PRINCIPAL
	 * @generated
	 * @ordered
	 */
	public static final PartnerRoleEndpointReferenceType PRINCIPAL_LITERAL = new PartnerRoleEndpointReferenceType(PRINCIPAL, "principal", "principal");

	/**
	 * An array of all the '<em><b>Partner Role Endpoint Reference Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final PartnerRoleEndpointReferenceType[] VALUES_ARRAY =
		new PartnerRoleEndpointReferenceType[] {
			STATIC_LITERAL,
			DYNAMIC_LITERAL,
			INVOKER_LITERAL,
			PRINCIPAL_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Partner Role Endpoint Reference Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Partner Role Endpoint Reference Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PartnerRoleEndpointReferenceType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PartnerRoleEndpointReferenceType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Partner Role Endpoint Reference Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PartnerRoleEndpointReferenceType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PartnerRoleEndpointReferenceType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Partner Role Endpoint Reference Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PartnerRoleEndpointReferenceType get(int value) {
		switch (value) {
			case STATIC: return STATIC_LITERAL;
			case DYNAMIC: return DYNAMIC_LITERAL;
			case INVOKER: return INVOKER_LITERAL;
			case PRINCIPAL: return PRINCIPAL_LITERAL;
		}
		return null;	
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private PartnerRoleEndpointReferenceType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //PartnerRoleEndpointReferenceType
