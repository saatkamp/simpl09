/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class PlnkRoleBpel2ToBpel1Converter implements IBPELConverter {

	public void convertBpel(Document dom) {
		NodeList list = dom.getElementsByTagName("plnk:role");
		
		if (list.getLength() != 0){
			
			for (int i=0; i<list.getLength(); i++){
				convertRole((Element) list.item(i), dom);
			}
		}
	}

	private void convertRole(Element element, Document dom){
		String portType = element.getAttribute("portType");
		Element portTypeElement = dom.createElement("plnk:portType");
		portTypeElement.setAttribute("name", portType);
		element.appendChild(portTypeElement);
		element.removeAttribute("portType");
	}
}
