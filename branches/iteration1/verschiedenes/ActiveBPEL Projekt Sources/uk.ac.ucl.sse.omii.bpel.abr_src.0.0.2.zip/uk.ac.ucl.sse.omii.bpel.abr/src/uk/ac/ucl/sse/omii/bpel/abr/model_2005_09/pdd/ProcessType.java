/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Process Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getVersion <em>Version</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPartnerLinks <em>Partner Links</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getIndexedProperties <em>Indexed Properties</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getWsdlReferences <em>Wsdl References</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getLocation <em>Location</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getName <em>Name</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType <em>Persistence Type</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType <em>Transaction Type</em>}</li>
 * </ul>
 * </p>
 *
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType()
 * @model extendedMetaData="name='process_._type' kind='elementOnly'"
 * @generated
 */
public interface ProcessType extends EObject {
	/**
	 * Returns the value of the '<em><b>Version</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Version</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Version</em>' containment reference.
	 * @see #setVersion(VersionType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_Version()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='version' namespace='##targetNamespace'"
	 * @generated
	 */
	VersionType getVersion();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getVersion <em>Version</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Version</em>' containment reference.
	 * @see #getVersion()
	 * @generated
	 */
	void setVersion(VersionType value);

	/**
	 * Returns the value of the '<em><b>Partner Links</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Partner Links</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Partner Links</em>' containment reference.
	 * @see #setPartnerLinks(PartnerLinksType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_PartnerLinks()
	 * @model containment="true" required="true"
	 *        extendedMetaData="kind='element' name='partnerLinks' namespace='##targetNamespace'"
	 * @generated
	 */
	PartnerLinksType getPartnerLinks();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPartnerLinks <em>Partner Links</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Partner Links</em>' containment reference.
	 * @see #getPartnerLinks()
	 * @generated
	 */
	void setPartnerLinks(PartnerLinksType value);

	/**
	 * Returns the value of the '<em><b>Indexed Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Indexed Properties</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Indexed Properties</em>' containment reference.
	 * @see #setIndexedProperties(IndexedPropertiesType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_IndexedProperties()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='indexedProperties' namespace='##targetNamespace'"
	 * @generated
	 */
	IndexedPropertiesType getIndexedProperties();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getIndexedProperties <em>Indexed Properties</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Indexed Properties</em>' containment reference.
	 * @see #getIndexedProperties()
	 * @generated
	 */
	void setIndexedProperties(IndexedPropertiesType value);

	/**
	 * Returns the value of the '<em><b>Wsdl References</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Wsdl References</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Wsdl References</em>' containment reference.
	 * @see #setWsdlReferences(WsdlReferencesType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_WsdlReferences()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='wsdlReferences' namespace='##targetNamespace'"
	 * @generated
	 */
	WsdlReferencesType getWsdlReferences();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getWsdlReferences <em>Wsdl References</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Wsdl References</em>' containment reference.
	 * @see #getWsdlReferences()
	 * @generated
	 */
	void setWsdlReferences(WsdlReferencesType value);

	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Location</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see #setLocation(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_Location()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='location'"
	 * @generated
	 */
	String getLocation();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(String value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(Object)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.QName" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	Object getName();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(Object value);

	/**
	 * Returns the value of the '<em><b>Persistence Type</b></em>' attribute.
	 * The default value is <code>"full"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Persistence Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Persistence Type</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @see #isSetPersistenceType()
	 * @see #unsetPersistenceType()
	 * @see #setPersistenceType(PersistenceType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_PersistenceType()
	 * @model default="full" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='persistenceType'"
	 * @generated
	 */
	PersistenceType getPersistenceType();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType <em>Persistence Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Persistence Type</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @see #isSetPersistenceType()
	 * @see #unsetPersistenceType()
	 * @see #getPersistenceType()
	 * @generated
	 */
	void setPersistenceType(PersistenceType value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType <em>Persistence Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetPersistenceType()
	 * @see #getPersistenceType()
	 * @see #setPersistenceType(PersistenceType)
	 * @generated
	 */
	void unsetPersistenceType();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType <em>Persistence Type</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Persistence Type</em>' attribute is set.
	 * @see #unsetPersistenceType()
	 * @see #getPersistenceType()
	 * @see #setPersistenceType(PersistenceType)
	 * @generated
	 */
	boolean isSetPersistenceType();

	/**
	 * Returns the value of the '<em><b>Suspend Process On Uncaught Fault</b></em>' attribute.
	 * The default value is <code>"true"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Suspend Process On Uncaught Fault</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Suspend Process On Uncaught Fault</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @see #isSetSuspendProcessOnUncaughtFault()
	 * @see #unsetSuspendProcessOnUncaughtFault()
	 * @see #setSuspendProcessOnUncaughtFault(SuspendFlag)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_SuspendProcessOnUncaughtFault()
	 * @model default="true" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='suspendProcessOnUncaughtFault'"
	 * @generated
	 */
	SuspendFlag getSuspendProcessOnUncaughtFault();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Suspend Process On Uncaught Fault</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @see #isSetSuspendProcessOnUncaughtFault()
	 * @see #unsetSuspendProcessOnUncaughtFault()
	 * @see #getSuspendProcessOnUncaughtFault()
	 * @generated
	 */
	void setSuspendProcessOnUncaughtFault(SuspendFlag value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetSuspendProcessOnUncaughtFault()
	 * @see #getSuspendProcessOnUncaughtFault()
	 * @see #setSuspendProcessOnUncaughtFault(SuspendFlag)
	 * @generated
	 */
	void unsetSuspendProcessOnUncaughtFault();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Suspend Process On Uncaught Fault</em>' attribute is set.
	 * @see #unsetSuspendProcessOnUncaughtFault()
	 * @see #getSuspendProcessOnUncaughtFault()
	 * @see #setSuspendProcessOnUncaughtFault(SuspendFlag)
	 * @generated
	 */
	boolean isSetSuspendProcessOnUncaughtFault();

	/**
	 * Returns the value of the '<em><b>Transaction Type</b></em>' attribute.
	 * The default value is <code>"bean"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Transaction Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transaction Type</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @see #isSetTransactionType()
	 * @see #unsetTransactionType()
	 * @see #setTransactionType(TransactionType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getProcessType_TransactionType()
	 * @model default="bean" unique="false" unsettable="true"
	 *        extendedMetaData="kind='attribute' name='transactionType'"
	 * @generated
	 */
	TransactionType getTransactionType();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType <em>Transaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Transaction Type</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @see #isSetTransactionType()
	 * @see #unsetTransactionType()
	 * @see #getTransactionType()
	 * @generated
	 */
	void setTransactionType(TransactionType value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType <em>Transaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetTransactionType()
	 * @see #getTransactionType()
	 * @see #setTransactionType(TransactionType)
	 * @generated
	 */
	void unsetTransactionType();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType <em>Transaction Type</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Transaction Type</em>' attribute is set.
	 * @see #unsetTransactionType()
	 * @see #getTransactionType()
	 * @see #setTransactionType(TransactionType)
	 * @generated
	 */
	boolean isSetTransactionType();

} // ProcessType