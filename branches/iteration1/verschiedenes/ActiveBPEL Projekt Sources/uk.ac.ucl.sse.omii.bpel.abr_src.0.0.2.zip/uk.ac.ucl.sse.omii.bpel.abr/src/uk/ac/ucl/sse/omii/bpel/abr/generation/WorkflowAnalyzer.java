/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import org.eclipse.bpel.model.Process;

/**
 * Determines the type of a workflow. The three relevant types are defined in 
 * <code>WorkflowTypeEnum</code>.
 * <p>
 * Each of the three major types of workflows imposes slightly different rules
 * for the generation of correct PDD (ActiveBPEL deployment descriptor).
 * <p>
 * We determine the three types as follows. 
 * <p>
 * An asynchronous provider workflow is one that has a partner with two roles
 * and the workflow has a Receive with this partner's myRole PT AND the process
 * has a subsequent invoke with this partner's partnerRole PT. Or, in case of
 * a Pick activity, process has partner with two roles AND process has an 
 * onMessage with this partner's myRole PT AND process has a subsequent Invoke
 * with partner's partnerRole PT.
 * <p>
 * Similarly, an asynchronous client workflow of an asynchronous provider 
 * workflow can be recognised by the fact that that it has a partner with two 
 * roles and uses its partnerRole PT in an invoke followed by a subsequent 
 * receive using this partner�s myRole PT.
 * <p>
 * <em>Note that these two cases are not exhaustive and just serve as some rules
 * of thumb. For example, a workflow could just define a Receive activity for
 * an asynchronous callback operation. However, only in the cases described
 * above does it become necessary to generate the PDD according to different 
 * rules.</em> 
 *
 * @author Bruno Wassermann, written Aug 22, 2006
 */
public class WorkflowAnalyzer {
	
	public WorkflowAnalyzer() {}
	
	// TODO implement the algorithm to determine type of workflow
	
	
	public WorkflowTypeEnum determineWorkflowType(final Process process) {
		// TODO this is just fake implementation
		return WorkflowTypeEnum.get(WorkflowTypeEnum.SYNC);
	}

}
