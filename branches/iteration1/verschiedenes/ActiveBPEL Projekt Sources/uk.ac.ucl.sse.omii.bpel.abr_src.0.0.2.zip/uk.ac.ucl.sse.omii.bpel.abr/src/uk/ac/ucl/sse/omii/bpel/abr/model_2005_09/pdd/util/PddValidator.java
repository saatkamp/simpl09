/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.util.EObjectValidator;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeUtil;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeValidator;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage
 * @generated
 */
public class PddValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final PddValidator INSTANCE = new PddValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * The cached base package validator.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected XMLTypeValidator xmlTypeValidator;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddValidator() {
		super();
		xmlTypeValidator = XMLTypeValidator.INSTANCE;
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EPackage getEPackage() {
	  return PddPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresonding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map context) {
		switch (classifierID) {
			case PddPackage.DOCUMENT_ROOT:
				return validateDocumentRoot((DocumentRoot)value, diagnostics, context);
			case PddPackage.INDEXED_PROPERTIES_TYPE:
				return validateIndexedPropertiesType((IndexedPropertiesType)value, diagnostics, context);
			case PddPackage.INDEXED_PROPERTY_TYPE:
				return validateIndexedPropertyType((IndexedPropertyType)value, diagnostics, context);
			case PddPackage.MY_ROLE_TYPE:
				return validateMyRoleType((MyRoleType)value, diagnostics, context);
			case PddPackage.PARTNER_LINKS_TYPE:
				return validatePartnerLinksType((PartnerLinksType)value, diagnostics, context);
			case PddPackage.PARTNER_LINK_TYPE:
				return validatePartnerLinkType((PartnerLinkType)value, diagnostics, context);
			case PddPackage.PARTNER_ROLE_TYPE:
				return validatePartnerRoleType((PartnerRoleType)value, diagnostics, context);
			case PddPackage.PROCESS_TYPE:
				return validateProcessType((ProcessType)value, diagnostics, context);
			case PddPackage.VARIABLE_TYPE:
				return validateVariableType((VariableType)value, diagnostics, context);
			case PddPackage.VARIABLE_TYPE1:
				return validateVariableType1((VariableType1)value, diagnostics, context);
			case PddPackage.VERSION_TYPE:
				return validateVersionType((VersionType)value, diagnostics, context);
			case PddPackage.WSDL_REFERENCES_TYPE:
				return validateWsdlReferencesType((WsdlReferencesType)value, diagnostics, context);
			case PddPackage.WSDL_TYPE:
				return validateWsdlType((WsdlType)value, diagnostics, context);
			case PddPackage.DISPOSITION_TYPE:
				return validateDispositionType((DispositionType)value, diagnostics, context);
			case PddPackage.MY_ROLE_BINDING_TYPE:
				return validateMyRoleBindingType((MyRoleBindingType)value, diagnostics, context);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE:
				return validatePartnerRoleEndpointReferenceType((PartnerRoleEndpointReferenceType)value, diagnostics, context);
			case PddPackage.PERSISTENCE_TYPE:
				return validatePersistenceType((PersistenceType)value, diagnostics, context);
			case PddPackage.SUSPEND_FLAG:
				return validateSuspendFlag((SuspendFlag)value, diagnostics, context);
			case PddPackage.TRANSACTION_TYPE:
				return validateTransactionType((TransactionType)value, diagnostics, context);
			case PddPackage.CUSTOM_INVOKER_URI_TYPE:
				return validateCustomInvokerUriType((String)value, diagnostics, context);
			case PddPackage.DISPOSITION_TYPE_OBJECT:
				return validateDispositionTypeObject((DispositionType)value, diagnostics, context);
			case PddPackage.INVOKE_HANDLER_TYPE:
				return validateInvokeHandlerType((String)value, diagnostics, context);
			case PddPackage.MY_ROLE_BINDING_TYPE_OBJECT:
				return validateMyRoleBindingTypeObject((MyRoleBindingType)value, diagnostics, context);
			case PddPackage.PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT:
				return validatePartnerRoleEndpointReferenceTypeObject((PartnerRoleEndpointReferenceType)value, diagnostics, context);
			case PddPackage.PERSISTENCE_TYPE_OBJECT:
				return validatePersistenceTypeObject((PersistenceType)value, diagnostics, context);
			case PddPackage.SUSPEND_FLAG_OBJECT:
				return validateSuspendFlagObject((SuspendFlag)value, diagnostics, context);
			case PddPackage.TRANSACTION_TYPE_OBJECT:
				return validateTransactionTypeObject((TransactionType)value, diagnostics, context);
			case PddPackage.VERSION_ATTRIBUTE_TYPE:
				return validateVersionAttributeType(((Float)value).floatValue(), diagnostics, context);
			case PddPackage.VERSION_ATTRIBUTE_TYPE_OBJECT:
				return validateVersionAttributeTypeObject((Float)value, diagnostics, context);
			default: 
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDocumentRoot(DocumentRoot documentRoot, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(documentRoot, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateIndexedPropertiesType(IndexedPropertiesType indexedPropertiesType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(indexedPropertiesType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateIndexedPropertyType(IndexedPropertyType indexedPropertyType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(indexedPropertyType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMyRoleType(MyRoleType myRoleType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(myRoleType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePartnerLinksType(PartnerLinksType partnerLinksType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(partnerLinksType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePartnerLinkType(PartnerLinkType partnerLinkType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(partnerLinkType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePartnerRoleType(PartnerRoleType partnerRoleType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(partnerRoleType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateProcessType(ProcessType processType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(processType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVariableType(VariableType variableType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(variableType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVariableType1(VariableType1 variableType1, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(variableType1, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionType(VersionType versionType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(versionType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWsdlReferencesType(WsdlReferencesType wsdlReferencesType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(wsdlReferencesType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWsdlType(WsdlType wsdlType, DiagnosticChain diagnostics, Map context) {
		return validate_EveryDefaultConstraint(wsdlType, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDispositionType(DispositionType dispositionType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMyRoleBindingType(MyRoleBindingType myRoleBindingType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePartnerRoleEndpointReferenceType(PartnerRoleEndpointReferenceType partnerRoleEndpointReferenceType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePersistenceType(PersistenceType persistenceType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSuspendFlag(SuspendFlag suspendFlag, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransactionType(TransactionType transactionType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCustomInvokerUriType(String customInvokerUriType, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDispositionTypeObject(DispositionType dispositionTypeObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInvokeHandlerType(String invokeHandlerType, DiagnosticChain diagnostics, Map context) {
		boolean result = validateInvokeHandlerType_Pattern(invokeHandlerType, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @see #validateInvokeHandlerType_Pattern
	 */
	public static final  PatternMatcher [][] INVOKE_HANDLER_TYPE__PATTERN__VALUES =
		new PatternMatcher [][] {
			new PatternMatcher [] {
				XMLTypeUtil.createPatternMatcher("[a-zA-Z0-9]+(:.+)?")
			}
		};

	/**
	 * Validates the Pattern constraint of '<em>Invoke Handler Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInvokeHandlerType_Pattern(String invokeHandlerType, DiagnosticChain diagnostics, Map context) {
		return validatePattern(PddPackage.Literals.INVOKE_HANDLER_TYPE, invokeHandlerType, INVOKE_HANDLER_TYPE__PATTERN__VALUES, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMyRoleBindingTypeObject(MyRoleBindingType myRoleBindingTypeObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePartnerRoleEndpointReferenceTypeObject(PartnerRoleEndpointReferenceType partnerRoleEndpointReferenceTypeObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePersistenceTypeObject(PersistenceType persistenceTypeObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSuspendFlagObject(SuspendFlag suspendFlagObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTransactionTypeObject(TransactionType transactionTypeObject, DiagnosticChain diagnostics, Map context) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionAttributeType(float versionAttributeType, DiagnosticChain diagnostics, Map context) {
		boolean result = validateVersionAttributeType_Pattern(versionAttributeType, diagnostics, context);
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @see #validateVersionAttributeType_Pattern
	 */
	public static final  PatternMatcher [][] VERSION_ATTRIBUTE_TYPE__PATTERN__VALUES =
		new PatternMatcher [][] {
			new PatternMatcher [] {
				XMLTypeUtil.createPatternMatcher("[0-9]+(\\.[0-9]{1,2})?")
			}
		};

	/**
	 * Validates the Pattern constraint of '<em>Version Attribute Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionAttributeType_Pattern(float versionAttributeType, DiagnosticChain diagnostics, Map context) {
		return validatePattern(PddPackage.Literals.VERSION_ATTRIBUTE_TYPE, new Float(versionAttributeType), VERSION_ATTRIBUTE_TYPE__PATTERN__VALUES, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVersionAttributeTypeObject(Float versionAttributeTypeObject, DiagnosticChain diagnostics, Map context) {
		boolean result = validateVersionAttributeType_Pattern(versionAttributeTypeObject.floatValue(), diagnostics, context);
		return result;
	}

} //PddValidator
