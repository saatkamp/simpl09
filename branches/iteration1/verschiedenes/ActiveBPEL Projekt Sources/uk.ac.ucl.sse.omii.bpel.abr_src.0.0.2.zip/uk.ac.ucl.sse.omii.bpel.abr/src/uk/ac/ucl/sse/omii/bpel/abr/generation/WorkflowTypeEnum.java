/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * A typesafe enum representing three different types of workflow, each 
 * posing different requirements on the generation of correct PDD (ActiveBPEL
 * deployment descriptor format). 
 * <p>
 * The three different types are:
 * <ul>
 * 	<li>Synchronous workflow - no asynchronous interactions offered or used</li>
 * 	<li>Asynchronous client workflow - invokes an asynchronous operation in
 * 	another service partner and later synchronizes with provider via callback
 * 	(corresponding receive activity)</li>
 * 	<li>Asynchronous provider workflow - provides an asynchronous operation
 * 	and eventually uses its caller's/client's callback operation via an invoke</li> 
 * </ul> 
 * 
 * Note that these cases are just useful to derive rules for the correct generation
 * of PDD and have no meaning beyond that. 
 *
 * @author Bruno Wassermann, written Aug 22, 2006
 */
public class WorkflowTypeEnum extends AbstractEnumerator {
	
	/**
	 * Private constructor to restrict creation on instances to this class. 
	 * 
	 * @param value
	 * @param name
	 * @param literal
	 */
	private WorkflowTypeEnum(int value, String name, String literal) {
		super(value, name, literal);
	}
	
	/* The SYNC literal value - synchronous wflow */
	public static final int SYNC = 0;
	
	/* The ASYNC_CLIENT literal value - asynchronous client wflow */
	public static final int ASYNC_CLIENT = 1;
	
	/* The ASYNC_PROVIDER literal value - asynchronous provider wflow */
	public static final int ASYNC_PROVIDER = 2;
	
	public static final WorkflowTypeEnum SYNC_LITERAL = new WorkflowTypeEnum(SYNC, "SYNC", "SYNC");
	
	public static final WorkflowTypeEnum ASYNC_CLIENT_LITERAL = new WorkflowTypeEnum(ASYNC_CLIENT, "ASYNC_CLIENT", "ASYNC_CLIENT");
	
	public static final WorkflowTypeEnum ASYNC_PROVIDER_LITERAL = new WorkflowTypeEnum(ASYNC_PROVIDER, "ASYNC_PROVIDER", "ASYNC_PROVIDER");
	
	private static final WorkflowTypeEnum[] VALUES_ARRAY =
	    new WorkflowTypeEnum[]
	    {
	      SYNC_LITERAL,
	      ASYNC_CLIENT_LITERAL,
	      ASYNC_PROVIDER_LITERAL,
	    };
	
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));
	
	/**
	 * Returns <code>WorkflowTypeEnum</code> with corresponding <code>String</code>
	 * literal value ('literal' argument to constructor).
	 *  
	 * @param literal
	 * @return <code>WorkflowTypeEnum</code> or <code>null</code>
	 */
	public static WorkflowTypeEnum get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
	      WorkflowTypeEnum result = VALUES_ARRAY[i];
	      if (result.toString().equals(literal)) {
	        return result;
	      }
	    }
	    return null;
	}
	
	/**
	 * Returns <code>WorkflowTypeEnum</code> with corresponding <code>String</code>
	 * name value ('name' argument to constructor).
	 *  
	 * @param name
	 * @return <code>WorkflowTypeEnum</code> or <code>null</code>
	 */
	public static WorkflowTypeEnum getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
	      WorkflowTypeEnum result = VALUES_ARRAY[i];
	      if (result.getName().equals(name)) {
	        return result;
	      }
	    }
	    return null;
	}
	
	/**
	 * Returns <code>WorkflowTypeEnum</code> with corresponding <code>int</code>
	 * value ('literal' argument to constructor).
	 *  
	 * @param value
	 * @return <code>WorkflowTypeEnum</code> or <code>null</code>
	 */
	public static WorkflowTypeEnum get(int value) {
	    switch (value)
	    {
	      case SYNC: return SYNC_LITERAL;
	      case ASYNC_CLIENT: return ASYNC_CLIENT_LITERAL;
	      case ASYNC_PROVIDER: return ASYNC_PROVIDER_LITERAL;
	    }
	    return null;	
	  }

}
