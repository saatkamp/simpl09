/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

/**
 * Holding relevant constants for the creation of BPR archives.
 *
 * @author Bruno Wassermann, written Sep 11, 2006
 */
public interface IBprConstants {
	
	// bpr file extension
	public final static String BPR_EXTENSION = "bpr"; //$NON-NLS-1$
	public final static String DOT_BPR_EXTENSION = "." + BPR_EXTENSION; //$NON-NLS-1$
	
	// bpel file extension
	public final static String BPEL_EXTENSION = "bpel"; //$NON-NLS-1$
	public final static String DOT_BPEL_EXTENSION = "." + BPEL_EXTENSION; //$NON-NLS-1$
	
	// bpr dir constants
	public final static String BPEL_DIR = "bpel/"; //$NON-NLS-1$
	public final static String WSDL_DIR = "wsdl/"; //$NON-NLS-1$
	public final static String META_INF_DIR = "META-INF/"; //$NON-NLS-1$
	public final static String PDD_DIR = "pdd/"; //$NON-NLS-1$
	public final static String WSDL_CATALOG_FILE = "wsdlCatalog.xml"; //$NON-NLS-1$

}
