/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.util.Iterator;

import org.eclipse.bpel.model.Import;
import org.eclipse.bpel.model.PartnerLink;
import org.eclipse.bpel.model.Process;
import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMapUtil;
import org.eclipse.emf.ecore.xml.type.AnyType;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.wst.server.core.IModuleArtifact;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IPddConstants;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddFactory;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util.PddResourceFactoryImpl;

/**
 * Responsible for generating PDD (ActiveBPEL deployment descriptor) for any
 * given valid <code>BPELModuleArtifact</code>.
 * 
 * TODO when workflow analyzer is implemented to recognise different types of
 * workflows think about refactoring this so that this becomes base class and
 * can use strategy pattern in order decide which concrete implementation ot
 * use for generating PDD
 *
 * @author Bruno Wassermann, written Aug 22, 2006
 */
public class PddGenerator {
	
	// TODO add logging whenever something is null and cannot succesfully generated PDD
	
	private final static String BPEL_LOCATION = "bpel/";
	private final static String WSDL_LOCATION = "wsdl/";
	private final static String PROCESS_PREFIX = "bpelns";
	private final static String COLON = ":";
	private final static String AUTO_PREFIX1 = "ns";
	private final static String AUTO_PREFIX2 = "longrandomprefix";
	private final static String ARTIFACTS_SUFFIX = "Artifacts";
	private final static String DOT_WSDL_FILE_EXT = ".wsdl";
	private static int counter;
	
	protected DocumentRoot docRoot = null;
	protected ResourceSet resourceSet = null;
	protected ExtendedMetaData metaData = null;
	protected String host = "localhost";
	protected int httpPort = 8080;
	
	public PddGenerator(String host, int httpPort) {
		init();
		counter = 0;
		
		if (host != null && !("".equals(host))) {
			this.host = host;
		}
		this.httpPort = httpPort;
	}
	
	
	/**
	 * Generates PDD given an <code>IModuleArtifact</code>.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code>
	 * @return <code>DocumentRoot</code> containing model instance with deployment
	 * descriptor for corresponding BPEL process or <code>null</code>, if 
	 * moduleArtifact or BPEL file is not valid
	 * <p>
	 * This method checks whether the <code>IModuleArtifact</code> is in fact a
	 * <code>BPELModuleArtifact</code> that contains a corresponding BPEL file.
	 * Without these requirements met, it is not possible to generate correct PDD
	 * and the method will therefore return null
	 */
	public DocumentRoot generatePDD(final IModuleArtifact moduleArtifact) {
		if (isNullBPELProcess(moduleArtifact)) return null;
		
		ProcessType process = createProcessType(moduleArtifact);
		
		PartnerLinksType partnerLinks = createPartnerLinks(moduleArtifact);
		process.setPartnerLinks(partnerLinks);
		
		WsdlReferencesType wsdlRef = createWsdlReferences(moduleArtifact, process);
		process.setWsdlReferences(wsdlRef);
				
		return docRoot;
	}
	
	/*
	 * TODO in case of local WSDLs, get the location from the bpelPartnerLink,
	 * read the WSDL and look for a wsdl:service element. if you find one,
	 * generate the partnerLink values from the information contained there.
	 */

	
	/**
	 * Generate <code>ProcessType</code> element according to the information
	 * from BPEL process to be deployed.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code> that is expected to
	 * be non-null and contain a valid bpel file
	 * @return <code>ProcessType</code> 
	 */
	protected ProcessType createProcessType(final IModuleArtifact moduleArtifact) {		
		Process bpelProcess = DeploymentDataProvider.getProcess(moduleArtifact);
		IFile bpelFile = DeploymentDataProvider.getBPELFile(moduleArtifact);
		
		// create the process element
		ProcessType process = PddFactory.eINSTANCE.createProcessType();
		docRoot.setProcess(process);
		process.setLocation(BPEL_LOCATION + bpelFile.getName());
		process.setName(PROCESS_PREFIX + COLON + bpelProcess.getName());
		
		// get namespace-prefix map from process to set required prefixes and nss
		EMap xmlnsPrefixMap = (EMap) docRoot.eGet(metaData.getXMLNSPrefixMapFeature(process.eContainer().eClass()));
		xmlnsPrefixMap.put(PROCESS_PREFIX, bpelProcess.getTargetNamespace());
		xmlnsPrefixMap.put(
				IPddConstants.PREFIX_ADDRESSING, 
				IPddConstants.NS_ADDRESSING);
		
		createPartnerNSPrefixMappings(moduleArtifact, xmlnsPrefixMap);
				
		return process;
	}
	
	/**
	 * Generate <code>WsdlReferencesType</code> according to information in
	 * <code>IModuleArtifact</code>.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code> that is expected to
	 * be non-null and contain a valid bpel file
	 * @return <code>{@link WsdlReferencesType}</code> 
	 */
	protected WsdlReferencesType createWsdlReferences(
			final IModuleArtifact moduleArtifact, 
			final ProcessType process) 
	{
		WsdlReferencesType wsdlReferences = PddFactory.eINSTANCE.createWsdlReferencesType();
		
		EList localWsdlImports = 
			DeploymentDataProvider.getLocalWsdlImports(moduleArtifact);
		EList remoteWsdlImports = 
			DeploymentDataProvider.getRemoteWsdlImports(moduleArtifact);
		
		for (Iterator localIter = localWsdlImports.iterator(); localIter.hasNext(); ) {
			Import imp = (Import) localIter.next();
			WsdlType wsdl = PddFactory.eINSTANCE.createWsdlType();
			String location = extractFileName(imp.getLocation());
			
			if (location == null) return null; // TODO add logging
			
			if (isArtifactsLocation(location, process.getName().toString())) {
				continue; // not interested in artifacts file
				
				// TODO reconsider whether we might actually need to include
				// the artifacts file
			}
			
			wsdl.setLocation(WSDL_LOCATION + location); 
			wsdl.setNamespace(imp.getNamespace());
			wsdlReferences.addWsdlType(wsdl);
		}
		
		for (Iterator remoteIter = remoteWsdlImports.iterator(); remoteIter.hasNext(); ) {
			Import imp = (Import) remoteIter.next();
			WsdlType wsdl = PddFactory.eINSTANCE.createWsdlType();
			wsdl.setLocation(imp.getLocation());
			wsdl.setNamespace(imp.getNamespace());
			wsdlReferences.addWsdlType(wsdl);
		}
		return wsdlReferences;
	}
	
	/** 
	 * Generate <code>PartnerLinksType</code> according to information in
	 * <code>IModuleArtifact</code>. The value of the name attribute of the 
	 * partnerLink element is set to be the name of the partnerLinkType attribute
	 * value from the BPEL partnerLink element without the prefix.
	 * <p>
	 * This method delegates the creation of partnerRoles and myRoles to other
	 * methods.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code> that is expected to
	 * be non-null and contain a valid bpel file
	 * @return <code>{@link PartnerLinksType}</code>
	 */ 
	protected PartnerLinksType createPartnerLinks(final IModuleArtifact moduleArtifact) {
		PartnerLinksType partnerLinks = PddFactory.eINSTANCE.createPartnerLinksType();
		Process bpelProcess = DeploymentDataProvider.getProcess(moduleArtifact);
		
		EList bpelPartnernLinks = bpelProcess.getPartnerLinks().getChildren();
		
		/*
		 * TODO Get the WSDL in which the corresponding partnerLinkType is
		 * defined.
		 * Read the WSDL into an EMF model instance (or just a simple DOM) and
		 * return service elements. 
		 * How do we determine which of several service elements to use? Could,
		 * for now, restrict user to have just one service element in the WSDL.
		 * If there is a service element, use the information contained in
		 * there for generation of values in myRole and partnerRole. 
		 * Else, if there is no service element, use the generic way of
		 * generating these values.  
		 */
		
		for (Iterator iter = bpelPartnernLinks.iterator(); iter.hasNext(); ) {
			PartnerLink bpelPartnerLink = (PartnerLink) iter.next();

			PartnerLinkType partnerLink = PddFactory.eINSTANCE.createPartnerLinkType();
			partnerLink.setName(bpelPartnerLink.getName());		
			MyRoleType myRole = generateMyRole(bpelPartnerLink);
			
			if (myRole != null) partnerLink.setMyRole(myRole);
			
			PartnerRoleType partnerRole = generatePartnerRole(bpelPartnerLink);
			if (partnerRole != null) partnerLink.setPartnerRole(partnerRole);

			partnerLinks.addPartnerLink(partnerLink);
		}
		
		return partnerLinks;
	}
	
	/**
	 * Detects whether partner link contains myRole value and if it does
	 * generates <code>MyRoleType</code>. 
	 * <p>
	 * The service attribute value is set to be the name of the partnerLinkType 
	 * attribute value from the partner link with 'Service' appended to it.
	 * 
	 * @param bpelPartnerLink <code>PartnerLink</code>
	 * @return <code>MyRoleType</code> or <code>null</code>, if no myRole value
	 * found
	 */
	protected MyRoleType generateMyRole(final PartnerLink bpelPartnerLink) {
		if (bpelPartnerLink.getMyRole() == null) return null;
		
		MyRoleType myRole = PddFactory.eINSTANCE.createMyRoleType();
		myRole.setAllowedRoles("");
		myRole.setBinding(MyRoleBindingType.get(MyRoleBindingType.MSG));
		myRole.setService("" + bpelPartnerLink.getName() + "Service");
		return myRole;
	}
	
	protected PartnerRoleType generatePartnerRole(final PartnerLink bpelPartnerLink) {
		if (bpelPartnerLink.getPartnerRole() == null) return null;
		
		PartnerRoleType partnerRole = PddFactory.eINSTANCE.createPartnerRoleType();
		partnerRole.setEndpointReference(
				PartnerRoleEndpointReferenceType.get(PartnerRoleEndpointReferenceType.STATIC));
		partnerRole.setInvokeHandler(IPddConstants.DEFAULT_INV_HANDLER);
		
		/* <wsa:EndpointReference> */
		// create <wsa:EndpointReference> element
		FeatureMap partnerRoleMixed = partnerRole.getAny();
		EStructuralFeature endpointFeature = metaData.demandFeature(
				IPddConstants.NS_ADDRESSING, 
				IPddConstants.ENDPOINT_REF_ELT, 
				true);
		AnyType endpointReferenceElt = XMLTypeFactory.eINSTANCE.createAnyType();
		partnerRoleMixed.add(endpointFeature, endpointReferenceElt);
		/* END <wsa:EndpointReference> */
		
		/* <wsa:Address> */
		// add <wsa:Address> element as child of <wsa:EndpointReference> elt
		FeatureMap endpointReferenceEltMixed = endpointReferenceElt.getAny();
		EStructuralFeature addressFeature = metaData.demandFeature(
				IPddConstants.NS_ADDRESSING, 
				IPddConstants.ADDRESS_ELT, 
				true);
		AnyType addressElt = XMLTypeFactory.eINSTANCE.createAnyType();
		endpointReferenceEltMixed.add(addressFeature, addressElt);
		
		// add the text content to the <wsa:Address> element
		FeatureMapUtil.addText(
				addressElt.getMixed(), 
				IPddConstants.HTTP_PROTOCOL + 
				IPddConstants.COLON + 
				IPddConstants.TWO_SLASHES + 
				host + IPddConstants.COLON +
				new Integer(httpPort).toString() + 
				IPddConstants.AE_SERVICES +
				bpelPartnerLink.getName() + 
				IPddConstants.SERVICE_SUFFIX);		
		/* END <wsa:Address> */
		
		/* <wsa:ServiceName> */
		EStructuralFeature serviceNameFeature = metaData.demandFeature(
				IPddConstants.NS_ADDRESSING, 
				IPddConstants.SERVICE_NAME_ELT, 
				true);
		AnyType serviceNameElt = XMLTypeFactory.eINSTANCE.createAnyType();
		endpointReferenceEltMixed.add(serviceNameFeature, serviceNameElt);
		
		// add text content to <wsa:ServiceName> element 
		String prefix = getPrefixUsedInPdd(bpelPartnerLink);
		
		if (prefix == null) {
			// TODO stop doing any more work, log the problem! and return null
			return null;
		}
		FeatureMapUtil.addText(
				serviceNameElt.getMixed(), 
				prefix + 
				IPddConstants.COLON + 
				bpelPartnerLink.getName() + 
				IPddConstants.SERVICE_SUFFIX);
		
		// set the PortName attribute of the <wsa:ServiceName> elt and assign value
		EStructuralFeature portNameAttr = metaData.demandFeature(
				null, 
				IPddConstants.PORT_NAME_ATTR, 
				false);
		serviceNameElt.eSet(
				portNameAttr, 
				bpelPartnerLink.getName() +
				IPddConstants.SERVICE_SUFFIX + 
				IPddConstants.PORT_SUFFIX);
		/* END <wsa:ServiceName> */
		
		
		return partnerRole;
	}
	
	/*
	 * Initialise doc root, resource set and meta data used to generate a 
	 * model instance of the required PDD. 
	 */
	private void init() {
		initialiseDocumentRoot();
		initialiseResourceSet();
		initialiseMetaData();
	}
	
	private void initialiseDocumentRoot() {
		docRoot = PddFactory.eINSTANCE.createDocumentRoot();
	}
	
	private void initialiseResourceSet() {
		resourceSet = new ResourceSetImpl();
		
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
				IPddConstants.PDD_EXTENSION, 
				new PddResourceFactoryImpl());

		resourceSet.getPackageRegistry().put
			(PddPackage.eNS_URI, 
			 PddPackage.eINSTANCE);
	}
	
	private void initialiseMetaData() {
		metaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
	}
	
	/*
	 * Traverses all WSDL imports in process to be deployed and adds any
	 * missing namespaces with generated prefixes to mapping used for 
	 * making ns-prefix mapping available to top-level element 
	 * (i.e. <code>ProcessType</code>).
	 */
	private void createPartnerNSPrefixMappings(
			final IModuleArtifact moduleArtifact, EMap xmlnsPrefixMap) 
	{
		/*
		 * TODO Test whether regardless of which kind of import we encounter
		 * the namespace will never be null. If it is for some reason, we 
		 * need to find a way of obtaining the namespace anyway or inform the
		 * user that deployment cannot proceed and indicate where the problem lies.
		 */
		
		
		EList wsdlImports = DeploymentDataProvider.getWsdlImports(moduleArtifact);
		
		for (Iterator iter = wsdlImports.iterator(); iter.hasNext(); ) {
			Import imp = (Import) iter.next();
			
			if (xmlnsPrefixMap.containsValue(imp.getNamespace())) continue;
			
			// generate prefix, check that is unique in map and add mapping
			String prefix = AUTO_PREFIX1 + incrementCounter();
			
			while(!isPrefixUniqueInMap(prefix, xmlnsPrefixMap)) {
				prefix = AUTO_PREFIX2 + incrementCounter();
			}
			
			xmlnsPrefixMap.put(prefix, imp.getNamespace());
		}		
	}
	
	/*
	 * Returns the prefix assinged in this PDD to the namesace of the given
	 * <code>PartnerLink</code>'s <code>PartnerLinkType</code>. 
	 * 
	 * @param bpelPartnerLink
	 * @return <code>String</code> representing prefix used for partnerLinkType
	 * of given bpws:partnerLink or null, if none could be found for such a 
	 * namespace
	 * 
	 * PUBLIC FOR TESTING PURPOSES ONLY!!!
	 */
	public String getPrefixUsedInPdd(final PartnerLink bpelPartnerLink) {
		String id = bpelPartnerLink.getPartnerLinkType().getID();
		String[] splits = id.split(":");
		
		if (splits.length != 4) {
			/*
			 * Something went horribly wrong. Format of ID string is:
			 * PartnerLinkType:http://namespace:PLTNAME and we wouldn't know
			 * how to extract just the namespace. In that case return null so
			 * that caller can do some logging and whatever
			 */
			return null;
		}
		String targetns = "http:" + splits[2];
		EMap xmlnsPrefixMap = 
			(EMap) docRoot.eGet(
					metaData.getXMLNSPrefixMapFeature(docRoot.getProcess().eContainer().eClass()));
		
		Object[] nss = xmlnsPrefixMap.values().toArray();
		
		for (int i = 0; i < nss.length; i++) {
			String somens = nss[i].toString();
			
			if (targetns.equals(somens)) {
				Object[] prefixes = xmlnsPrefixMap.keySet().toArray();
				return prefixes[i].toString();
			}
		}
		
		return null;
	}
	
	
	
	/*
	 * Returns an increasing int counter used for generating unique
	 * prefixes. 
	 */
	private static int incrementCounter() {
		return counter++;
	}
	
	private boolean isPrefixUniqueInMap(final String prefix, final EMap xmlnsPrefixMap) {
		return (!(xmlnsPrefixMap.containsKey(prefix)));
	}
	
	/*
	 * Returns whether the given <code>IModuleArtifact</code> refers to a 
	 * <code>BPELModuleArtifact</code> and whether there is a corresponding
	 * bpel file. 
	 * 
	 * @return true, if can obtain BPEL process from given artifact, otherwise
	 * return null
	 */
	private boolean isNullBPELProcess(final IModuleArtifact moduleArtifact) {
		return DeploymentDataProvider.getProcess(moduleArtifact) == null;
	}
	
	/*
	 * Given any <code>String</code> ending in a wsdl file, removes all elements
	 * preceeding the file name and returns only the file name plus extension.
	 */
	private String extractFileName(String filePath) {
		if (filePath == null || "".equals(filePath)) return null;
		
		String[] split = filePath.split("/");
		
		return split[split.length-1]; // else return last element of split
	}
	
	/*
	 * Determines whether the location string for a particular import referes
	 * to an artifacts file generated by BPEL Designer. 
	 * 
	 * @param loc String expected to be only WSDL file name and extension
	 * @return true, if loc indicates artifacts file, false otherwise
	 * 
	 * THIS ASSUMES THAT BPEL DESIGNER WILL CONTINUE TO NAME ARTIFACTS FILES AS
	 * <process name>+<Artifacts>+<.wsdl>
	 */
	private boolean isArtifactsLocation(String loc, String prefixProcessName) {
		String processName = prefixProcessName.split(":")[1];
		
		if ((processName + ARTIFACTS_SUFFIX + DOT_WSDL_FILE_EXT).equals(loc)) return true;
		
		return false;
	}
	
	/**
	 * ONLY FOR TESTING PURPOSES!
	 */
	public DocumentRoot getDocRoot() {
		return docRoot;
	}
	
	/**
	 * ONLY FOR TESTING PURPOSES!
	 * @return
	 */
	public ExtendedMetaData getMetaData() {
		return metaData;
	}
	
	/**
	 * ONLY FOR TESTING PURPOSES!
	 * @return
	 */
	public String getHost() {
		return host;
	}
	
	/**
	 * ONLY FOR TESTING PURPOSES!
	 * @return
	 */
	public int getHttpPort() {
		return httpPort;
	}

}
