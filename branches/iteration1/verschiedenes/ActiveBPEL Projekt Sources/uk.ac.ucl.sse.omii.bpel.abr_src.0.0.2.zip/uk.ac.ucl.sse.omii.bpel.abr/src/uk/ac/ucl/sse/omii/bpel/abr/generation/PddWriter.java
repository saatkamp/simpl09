/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.io.File;
import java.io.IOException;
import java.util.Collections;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IPddConstants;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util.PddResourceFactoryImpl;

/**
 * Class for serialising instances of PDD models to files. Currently, carries
 * out no further checks to ensure that input is actually for a valid PDD model
 * and writes files to Eclipse home directory by default!
 *
 * @author Bruno Wassermann, written Sep 13, 2006
 */
public class PddWriter {
	
	public PddWriter() {}
	
	/**
	 * Expects an instance of a PDD model in a <code>DocumentRoot</code> and
	 * serialises it to a file as indicated by the absFilePath argument.
	 * For simplicity and 'coz got no time, this will create a file in a 
	 * default location (the ECLIPSE home dir). Clients might want to 
	 * delete this file once they are done.
	 * 
	 * @param docRoot <code>DocumentRoot</code> containing PDD model instance
	 * @param processName name of the BPEL process for which this PDD has been
	 * generated
	 * @return returns handle to file written or null in case something went wrong
	 */
	public File write(DocumentRoot docRoot, String processName) 
		throws IllegalArgumentException, IOException 
	{
		if (processName == null || "".equals(processName)) {
			throw new IllegalArgumentException(
					"processName must not be null or empty string, but is: " + processName);
		}
		if (docRoot == null) {
			throw new IllegalArgumentException("DocumentRoot must not be null");
		}
		ResourceSet resourceSet = new ResourceSetImpl();
		
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
				IPddConstants.PDD_EXTENSION, 
				new PddResourceFactoryImpl());

		resourceSet.getPackageRegistry().put
			(PddPackage.eNS_URI, 
			 PddPackage.eINSTANCE);
		
		URI uri = URI.createURI(processName + IPddConstants.DOT_PDD_EXTENSION);
		Resource resource = resourceSet.createResource(uri);
		resource.getContents().add(docRoot);
		resource.save(Collections.EMPTY_MAP);
		
		return new File(uri.toFileString());
	}
	
	

}
