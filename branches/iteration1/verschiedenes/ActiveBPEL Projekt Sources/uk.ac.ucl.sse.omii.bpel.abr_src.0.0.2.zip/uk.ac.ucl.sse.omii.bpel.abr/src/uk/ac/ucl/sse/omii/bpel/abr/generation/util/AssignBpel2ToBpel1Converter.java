/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class AssignBpel2ToBpel1Converter implements IBPELConverter {

	public void convertBpel(Document dom) {
		// translateFrom
		NodeList fList = dom.getElementsByTagName("bpws:from");
		
		if (fList != null) {
			
			for (int i=0; i<fList.getLength(); i++){
				convertFrom((Element) fList.item(i));
			}
		}
		// translateTo
		NodeList tList = dom.getElementsByTagName("bpws:to");
		
		if (tList != null){
			
			for (int i=0; i<tList.getLength(); i++){
				convertTo((Element) tList.item(i));
			}
		}
	}

	private void convertFrom(Element element){
		// if <expression> exists
		NodeList eList = element.getElementsByTagName("bpws:expression");
		
		if (eList.getLength() != 0){ 
			Element expressionElement = (Element) eList.item(0);
			String expression = expressionElement.getFirstChild().getNodeValue();
			element.setAttribute("expression", expression);
			element.removeChild(expressionElement);
			return;
		}
		
		// if <query> exists
		NodeList qList = element.getElementsByTagName("bpws:query");
		
		if (qList.getLength() != 0){
			Element queryElement = (Element) qList.item(0);
			String query = queryElement.getFirstChild().getNodeValue();
			element.setAttribute("query", safeQuery(query));
			element.removeChild(queryElement);
			return;
		}
	}
	
	private void convertTo(Element element){
		// if <query> exists
		NodeList qList = element.getElementsByTagName("bpws:query");
		if (qList.getLength()!=0){
			Element queryElement = (Element)qList.item(0);
			String query = queryElement.getFirstChild().getNodeValue();
			element.setAttribute("query", safeQuery(query));
			element.removeChild(queryElement);
			return;
		}
	}
	
	private String safeQuery(String query){
		if (!query.startsWith("//")) {
			query = "/" + query;
		}
		return query;
	}
}
