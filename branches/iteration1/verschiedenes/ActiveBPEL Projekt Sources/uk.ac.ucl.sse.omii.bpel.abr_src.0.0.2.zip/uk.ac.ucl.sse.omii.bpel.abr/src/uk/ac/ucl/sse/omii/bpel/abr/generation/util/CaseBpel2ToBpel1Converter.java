/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class CaseBpel2ToBpel1Converter implements IBPELConverter {

	public void convertBpel(Document dom) {
		NodeList nList = dom.getElementsByTagName("bpws:case");
		
		if (nList != null) {
			
			for (int i=0; i<nList.getLength(); i++){
				convertCase((Element) nList.item(i));
			}
		}
	}

	private void convertCase(Element caseElement){
		Element conditionElement = 
			(Element)caseElement.getElementsByTagName("bpws:condition").item(0);
		String condition = conditionElement.getFirstChild().getNodeValue();
		caseElement.setAttribute("condition", condition);
		caseElement.removeChild(conditionElement);
	}
}
