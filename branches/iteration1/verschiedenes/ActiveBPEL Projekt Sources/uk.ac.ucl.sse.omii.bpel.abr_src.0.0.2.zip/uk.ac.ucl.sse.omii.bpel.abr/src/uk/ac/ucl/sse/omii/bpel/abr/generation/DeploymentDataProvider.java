/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.bpel.model.Import;
import org.eclipse.bpel.model.Process;
import org.eclipse.bpel.runtimes.module.BPELModuleArtifact;
import org.eclipse.bpel.ui.util.BPELReader;
import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.wst.server.core.IModuleArtifact;

/**
 * Makes available a bunch of utility classes that provide any data required
 * data about a process for generation of PDDs. Most of the methods of this 
 * class work on <code>IModuleArtifact</code>s.
 *
 * @author Bruno Wassermann, written Aug 21, 2006
 */
public class DeploymentDataProvider {
	
	private final static String WSDL_IMPORT_TYPE = "http://schemas.xmlsoap.org/wsdl/";
	private final static String HTTP = "http://";
	
	/**
	 * Obtain the <code>Process</code> from an <code>IModuleArtifact</code>. 
	 * 
	 * @param moduleArtifact <code>BPELModuleArtifact</code>
	 * @return <code>Process</code> or <code>null</code>
	 * <p>
	 * Note that <code>null</code> is returned when the module artifact has a 
	 * <code>null</code> bpel file
	 * 
	 * TODO make returned process immutable
	 */
	public static Process getProcess(final IModuleArtifact moduleArtifact) {
		return getProcessFromFile(getBPELFile(moduleArtifact));
	}
	
	/**
	 * Extracts the bpel file from a <code>BPELModuleArtifact</code>.
	 * 
	 * @param moduleArtifact
	 * @return <code>IFile</code> representing bpel file of a 
	 * <code>BPELModuleArtifact</code>
	 * 
	 * TODO make returned file immutable
	 */
	public static IFile getBPELFile(final IModuleArtifact moduleArtifact) {
		if (!(moduleArtifact instanceof BPELModuleArtifact)) return null;
		
		return ((BPELModuleArtifact) moduleArtifact).getFile();
	}

	/**
	 * Returns all imports defined in the bpel file of the correspoding
	 * module artifact.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code>
	 * @return list of imports
	 * 
	 * TODO make returned result immutable
	 */
	public static EList getImports(final IModuleArtifact moduleArtifact) {
		Process process = getProcessFromFile(getBPELFile(moduleArtifact));
		
		if (process == null) return null;
		return process.getImports();
	}
	
	/**
	 * Returns all WSDL imports defined in teh bpel file of the corresponding
	 * module artifact.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code>
	 * @return <code>EList</code> of all WSDL imports
	 */
	public static EList getWsdlImports(final IModuleArtifact moduleArtifact) {
		EList results = new BasicEList();
		EList allImports = getImports(moduleArtifact);
		
		if (allImports == null) return null;
		
		for (Iterator iter = allImports.iterator(); iter.hasNext(); ) {
			Import imp = (Import) iter.next();
			
			if (WSDL_IMPORT_TYPE.equals(imp.getImportType())) {
				results.add(imp);
			}
		}	
		return results;
	}

	/**
	 * Returns all local WSDL imports in the bpel file referenced in the module 
	 * artifact. 
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code> expected to be a
	 * <code>BPELModuleArtifact</code>
	 * @return <code>EList</code>
	 * 
	 * TODO makre returned results immutable
	 * TODO think about returning empty list instead of null
	 */
	public static EList getLocalWsdlImports(final IModuleArtifact moduleArtifact) {
		EList results = new BasicEList();
		EList allImports = getImports(moduleArtifact);
		
		if (allImports == null) return null; 
		
		for (Iterator iter = allImports.iterator(); iter.hasNext(); ) {
			Import imp = (Import) iter.next();
			
			if (WSDL_IMPORT_TYPE.equals(imp.getImportType())) {
				if (imp.getLocation() == null) continue; // indicates artifacts ns
				if (imp.getLocation().indexOf(HTTP) == -1) {
					results.add(imp);
				}
			}
		}
		return results;
	}
	
	/**
	 * Returns all remote WSDL imports (ones that have 'http://' in their location
	 * attribute) in the bpel file referenced in the module artifact.
	 * 
	 * @param moduleArtifact <code>IModuleArtifact</code> expected to be a
	 * <code>BPELModuleArtifact</code>
	 * @return <code>EList</code>
	 * 
	 * TODO make returned results immutable
	 * TODO think about returning empty list instead of null
	 */
	public static EList getRemoteWsdlImports(final IModuleArtifact moduleArtifact) {
		EList results = new BasicEList();
		EList allImports = getImports(moduleArtifact);
		
		if (allImports == null) return null; 
		
		for (Iterator iter = allImports.iterator(); iter.hasNext(); ) {
			Import imp = (Import) iter.next();
			
			if (WSDL_IMPORT_TYPE.equals(imp.getImportType())) {
				if (imp.getLocation() == null) continue; // indicates artifacts ns
				if (imp.getLocation().indexOf(HTTP) != -1) {
					results.add(imp);
				}
			}
		}
		return results;
	}
	
	
	/*
	 * Create a <code>Process</code> from a bpel file.
	 */
	private static Process getProcessFromFile(IFile bpelFile) {
		if (bpelFile == null) return null;
		
		ResourceSet resourceSet = new ResourceSetImpl();
		URI uri = URI.createPlatformResourceURI(bpelFile.getFullPath().toString());
		Resource bpelResource = resourceSet.getResource(uri, true);
		BPELReader reader = new BPELReader();
		reader.read(bpelResource, bpelFile, resourceSet);
		
		return reader.getProcess();	
	}


}
