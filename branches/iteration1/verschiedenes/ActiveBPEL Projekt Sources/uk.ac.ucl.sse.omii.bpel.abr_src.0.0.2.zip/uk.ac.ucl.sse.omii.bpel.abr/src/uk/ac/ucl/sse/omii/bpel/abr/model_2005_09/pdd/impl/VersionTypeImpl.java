/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Version Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl#getEffectiveDate <em>Effective Date</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl#getExpirationDate <em>Expiration Date</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl#getId <em>Id</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl#getRunningProcessDisposition <em>Running Process Disposition</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class VersionTypeImpl extends EObjectImpl implements VersionType {
	/**
	 * The default value of the '{@link #getEffectiveDate() <em>Effective Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffectiveDate()
	 * @generated
	 * @ordered
	 */
	protected static final Object EFFECTIVE_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEffectiveDate() <em>Effective Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffectiveDate()
	 * @generated
	 * @ordered
	 */
	protected Object effectiveDate = EFFECTIVE_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getExpirationDate() <em>Expiration Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpirationDate()
	 * @generated
	 * @ordered
	 */
	protected static final Object EXPIRATION_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExpirationDate() <em>Expiration Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExpirationDate()
	 * @generated
	 * @ordered
	 */
	protected Object expirationDate = EXPIRATION_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final float ID_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected float id = ID_EDEFAULT;

	/**
	 * This is true if the Id attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean idESet = false;

	/**
	 * The default value of the '{@link #getRunningProcessDisposition() <em>Running Process Disposition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRunningProcessDisposition()
	 * @generated
	 * @ordered
	 */
	protected static final DispositionType RUNNING_PROCESS_DISPOSITION_EDEFAULT = DispositionType.TERMINATE_LITERAL;

	/**
	 * The cached value of the '{@link #getRunningProcessDisposition() <em>Running Process Disposition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRunningProcessDisposition()
	 * @generated
	 * @ordered
	 */
	protected DispositionType runningProcessDisposition = RUNNING_PROCESS_DISPOSITION_EDEFAULT;

	/**
	 * This is true if the Running Process Disposition attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean runningProcessDispositionESet = false;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VersionTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PddPackage.Literals.VERSION_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getEffectiveDate() {
		return effectiveDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEffectiveDate(Object newEffectiveDate) {
		Object oldEffectiveDate = effectiveDate;
		effectiveDate = newEffectiveDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.VERSION_TYPE__EFFECTIVE_DATE, oldEffectiveDate, effectiveDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getExpirationDate() {
		return expirationDate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExpirationDate(Object newExpirationDate) {
		Object oldExpirationDate = expirationDate;
		expirationDate = newExpirationDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.VERSION_TYPE__EXPIRATION_DATE, oldExpirationDate, expirationDate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(float newId) {
		float oldId = id;
		id = newId;
		boolean oldIdESet = idESet;
		idESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.VERSION_TYPE__ID, oldId, id, !oldIdESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetId() {
		float oldId = id;
		boolean oldIdESet = idESet;
		id = ID_EDEFAULT;
		idESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.VERSION_TYPE__ID, oldId, ID_EDEFAULT, oldIdESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetId() {
		return idESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DispositionType getRunningProcessDisposition() {
		return runningProcessDisposition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRunningProcessDisposition(DispositionType newRunningProcessDisposition) {
		DispositionType oldRunningProcessDisposition = runningProcessDisposition;
		runningProcessDisposition = newRunningProcessDisposition == null ? RUNNING_PROCESS_DISPOSITION_EDEFAULT : newRunningProcessDisposition;
		boolean oldRunningProcessDispositionESet = runningProcessDispositionESet;
		runningProcessDispositionESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION, oldRunningProcessDisposition, runningProcessDisposition, !oldRunningProcessDispositionESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetRunningProcessDisposition() {
		DispositionType oldRunningProcessDisposition = runningProcessDisposition;
		boolean oldRunningProcessDispositionESet = runningProcessDispositionESet;
		runningProcessDisposition = RUNNING_PROCESS_DISPOSITION_EDEFAULT;
		runningProcessDispositionESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION, oldRunningProcessDisposition, RUNNING_PROCESS_DISPOSITION_EDEFAULT, oldRunningProcessDispositionESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetRunningProcessDisposition() {
		return runningProcessDispositionESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PddPackage.VERSION_TYPE__EFFECTIVE_DATE:
				return getEffectiveDate();
			case PddPackage.VERSION_TYPE__EXPIRATION_DATE:
				return getExpirationDate();
			case PddPackage.VERSION_TYPE__ID:
				return new Float(getId());
			case PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION:
				return getRunningProcessDisposition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PddPackage.VERSION_TYPE__EFFECTIVE_DATE:
				setEffectiveDate((Object)newValue);
				return;
			case PddPackage.VERSION_TYPE__EXPIRATION_DATE:
				setExpirationDate((Object)newValue);
				return;
			case PddPackage.VERSION_TYPE__ID:
				setId(((Float)newValue).floatValue());
				return;
			case PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION:
				setRunningProcessDisposition((DispositionType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PddPackage.VERSION_TYPE__EFFECTIVE_DATE:
				setEffectiveDate(EFFECTIVE_DATE_EDEFAULT);
				return;
			case PddPackage.VERSION_TYPE__EXPIRATION_DATE:
				setExpirationDate(EXPIRATION_DATE_EDEFAULT);
				return;
			case PddPackage.VERSION_TYPE__ID:
				unsetId();
				return;
			case PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION:
				unsetRunningProcessDisposition();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PddPackage.VERSION_TYPE__EFFECTIVE_DATE:
				return EFFECTIVE_DATE_EDEFAULT == null ? effectiveDate != null : !EFFECTIVE_DATE_EDEFAULT.equals(effectiveDate);
			case PddPackage.VERSION_TYPE__EXPIRATION_DATE:
				return EXPIRATION_DATE_EDEFAULT == null ? expirationDate != null : !EXPIRATION_DATE_EDEFAULT.equals(expirationDate);
			case PddPackage.VERSION_TYPE__ID:
				return isSetId();
			case PddPackage.VERSION_TYPE__RUNNING_PROCESS_DISPOSITION:
				return isSetRunningProcessDisposition();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (effectiveDate: ");
		result.append(effectiveDate);
		result.append(", expirationDate: ");
		result.append(expirationDate);
		result.append(", id: ");
		if (idESet) result.append(id); else result.append("<unset>");
		result.append(", runningProcessDisposition: ");
		if (runningProcessDispositionESet) result.append(runningProcessDisposition); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //VersionTypeImpl