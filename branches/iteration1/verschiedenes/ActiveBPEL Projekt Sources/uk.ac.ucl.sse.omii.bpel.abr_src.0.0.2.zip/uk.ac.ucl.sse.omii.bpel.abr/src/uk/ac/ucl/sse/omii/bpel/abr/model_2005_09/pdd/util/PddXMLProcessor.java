/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util;

import java.util.Map;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.xmi.util.XMLProcessor;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IPddConstants;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;

/**
 * This class contains helper methods to serialize and deserialize XML documents
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PddXMLProcessor extends XMLProcessor {
	/**
	 * Public constructor to instantiate the helper.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddXMLProcessor() {
		super((EPackage.Registry.INSTANCE));
		PddPackage.eINSTANCE.eClass();
	}
	
	/**
	 * Register for "*" and "xml" file extensions the PddResourceFactoryImpl factory.
	 * <!-- begin-user-doc -->
	 * Added registration for "pdd" file extension.
	 * <!-- end-user-doc -->
	 * @generated NOT
	 */
	protected Map getRegistrations() {
		if (registrations == null) {
			super.getRegistrations();
			registrations.put(XML_EXTENSION, new PddResourceFactoryImpl());
			registrations.put(STAR_EXTENSION, new PddResourceFactoryImpl());
			registrations.put(IPddConstants.PDD_EXTENSION, new PddResourceFactoryImpl());
		}
		return registrations;
	}
	

} //PddXMLProcessor
