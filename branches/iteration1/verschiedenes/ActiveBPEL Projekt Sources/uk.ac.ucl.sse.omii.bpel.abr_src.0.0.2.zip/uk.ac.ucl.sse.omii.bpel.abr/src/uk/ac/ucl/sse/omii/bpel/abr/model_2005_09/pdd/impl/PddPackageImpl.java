/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddFactory;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util.PddValidator;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PddPackageImpl extends EPackageImpl implements PddPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass documentRootEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass indexedPropertiesTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass indexedPropertyTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass myRoleTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass partnerLinksTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass partnerLinkTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass partnerRoleTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass processTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass variableTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass variableType1EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass versionTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass wsdlReferencesTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass wsdlTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum dispositionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum myRoleBindingTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum partnerRoleEndpointReferenceTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum persistenceTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum suspendFlagEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum transactionTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType customInvokerUriTypeEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType dispositionTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType invokeHandlerTypeEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType myRoleBindingTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType partnerRoleEndpointReferenceTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType persistenceTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType suspendFlagObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType transactionTypeObjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType versionAttributeTypeEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType versionAttributeTypeObjectEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private PddPackageImpl() {
		super(eNS_URI, PddFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static PddPackage init() {
		if (isInited) return (PddPackage)EPackage.Registry.INSTANCE.getEPackage(PddPackage.eNS_URI);

		// Obtain or create and register package
		PddPackageImpl thePddPackage = (PddPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof PddPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new PddPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		thePddPackage.createPackageContents();

		// Initialize created meta-data
		thePddPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(thePddPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return PddValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		thePddPackage.freeze();

		return thePddPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDocumentRoot() {
		return documentRootEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDocumentRoot_Mixed() {
		return (EAttribute)documentRootEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XMLNSPrefixMap() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_XSISchemaLocation() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDocumentRoot_Process() {
		return (EReference)documentRootEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIndexedPropertiesType() {
		return indexedPropertiesTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIndexedPropertiesType_Group() {
		return (EAttribute)indexedPropertiesTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIndexedPropertiesType_IndexedProperty() {
		return (EReference)indexedPropertiesTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIndexedPropertyType() {
		return indexedPropertyTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIndexedPropertyType_Group() {
		return (EAttribute)indexedPropertyTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIndexedPropertyType_Variable() {
		return (EReference)indexedPropertyTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIndexedPropertyType_Name() {
		return (EAttribute)indexedPropertyTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getIndexedPropertyType_Type() {
		return (EAttribute)indexedPropertyTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMyRoleType() {
		return myRoleTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMyRoleType_Any() {
		return (EAttribute)myRoleTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMyRoleType_AllowedRoles() {
		return (EAttribute)myRoleTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMyRoleType_Binding() {
		return (EAttribute)myRoleTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMyRoleType_Service() {
		return (EAttribute)myRoleTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPartnerLinksType() {
		return partnerLinksTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerLinksType_Group() {
		return (EAttribute)partnerLinksTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPartnerLinksType_PartnerLink() {
		return (EReference)partnerLinksTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPartnerLinkType() {
		return partnerLinkTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPartnerLinkType_PartnerRole() {
		return (EReference)partnerLinkTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPartnerLinkType_MyRole() {
		return (EReference)partnerLinkTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerLinkType_Name() {
		return (EAttribute)partnerLinkTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPartnerRoleType() {
		return partnerRoleTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerRoleType_Any() {
		return (EAttribute)partnerRoleTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerRoleType_CustomInvokerUri() {
		return (EAttribute)partnerRoleTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerRoleType_EndpointReference() {
		return (EAttribute)partnerRoleTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPartnerRoleType_InvokeHandler() {
		return (EAttribute)partnerRoleTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getProcessType() {
		return processTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcessType_Version() {
		return (EReference)processTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcessType_PartnerLinks() {
		return (EReference)processTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcessType_IndexedProperties() {
		return (EReference)processTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getProcessType_WsdlReferences() {
		return (EReference)processTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessType_Location() {
		return (EAttribute)processTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessType_Name() {
		return (EAttribute)processTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessType_PersistenceType() {
		return (EAttribute)processTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessType_SuspendProcessOnUncaughtFault() {
		return (EAttribute)processTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getProcessType_TransactionType() {
		return (EAttribute)processTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVariableType() {
		return variableTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType_Part() {
		return (EAttribute)variableTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType_Path() {
		return (EAttribute)variableTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType_Query() {
		return (EAttribute)variableTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVariableType1() {
		return variableType1EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType1_Part() {
		return (EAttribute)variableType1EClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType1_Path() {
		return (EAttribute)variableType1EClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVariableType1_Query() {
		return (EAttribute)variableType1EClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVersionType() {
		return versionTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionType_EffectiveDate() {
		return (EAttribute)versionTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionType_ExpirationDate() {
		return (EAttribute)versionTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionType_Id() {
		return (EAttribute)versionTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVersionType_RunningProcessDisposition() {
		return (EAttribute)versionTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWsdlReferencesType() {
		return wsdlReferencesTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWsdlReferencesType_Group() {
		return (EAttribute)wsdlReferencesTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWsdlReferencesType_Wsdl() {
		return (EReference)wsdlReferencesTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWsdlType() {
		return wsdlTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWsdlType_Location() {
		return (EAttribute)wsdlTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWsdlType_Namespace() {
		return (EAttribute)wsdlTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDispositionType() {
		return dispositionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getMyRoleBindingType() {
		return myRoleBindingTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPartnerRoleEndpointReferenceType() {
		return partnerRoleEndpointReferenceTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPersistenceType() {
		return persistenceTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getSuspendFlag() {
		return suspendFlagEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTransactionType() {
		return transactionTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getCustomInvokerUriType() {
		return customInvokerUriTypeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getDispositionTypeObject() {
		return dispositionTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getInvokeHandlerType() {
		return invokeHandlerTypeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getMyRoleBindingTypeObject() {
		return myRoleBindingTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPartnerRoleEndpointReferenceTypeObject() {
		return partnerRoleEndpointReferenceTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPersistenceTypeObject() {
		return persistenceTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getSuspendFlagObject() {
		return suspendFlagObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getTransactionTypeObject() {
		return transactionTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getVersionAttributeType() {
		return versionAttributeTypeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getVersionAttributeTypeObject() {
		return versionAttributeTypeObjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddFactory getPddFactory() {
		return (PddFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		documentRootEClass = createEClass(DOCUMENT_ROOT);
		createEAttribute(documentRootEClass, DOCUMENT_ROOT__MIXED);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XMLNS_PREFIX_MAP);
		createEReference(documentRootEClass, DOCUMENT_ROOT__XSI_SCHEMA_LOCATION);
		createEReference(documentRootEClass, DOCUMENT_ROOT__PROCESS);

		indexedPropertiesTypeEClass = createEClass(INDEXED_PROPERTIES_TYPE);
		createEAttribute(indexedPropertiesTypeEClass, INDEXED_PROPERTIES_TYPE__GROUP);
		createEReference(indexedPropertiesTypeEClass, INDEXED_PROPERTIES_TYPE__INDEXED_PROPERTY);

		indexedPropertyTypeEClass = createEClass(INDEXED_PROPERTY_TYPE);
		createEAttribute(indexedPropertyTypeEClass, INDEXED_PROPERTY_TYPE__GROUP);
		createEReference(indexedPropertyTypeEClass, INDEXED_PROPERTY_TYPE__VARIABLE);
		createEAttribute(indexedPropertyTypeEClass, INDEXED_PROPERTY_TYPE__NAME);
		createEAttribute(indexedPropertyTypeEClass, INDEXED_PROPERTY_TYPE__TYPE);

		myRoleTypeEClass = createEClass(MY_ROLE_TYPE);
		createEAttribute(myRoleTypeEClass, MY_ROLE_TYPE__ANY);
		createEAttribute(myRoleTypeEClass, MY_ROLE_TYPE__ALLOWED_ROLES);
		createEAttribute(myRoleTypeEClass, MY_ROLE_TYPE__BINDING);
		createEAttribute(myRoleTypeEClass, MY_ROLE_TYPE__SERVICE);

		partnerLinksTypeEClass = createEClass(PARTNER_LINKS_TYPE);
		createEAttribute(partnerLinksTypeEClass, PARTNER_LINKS_TYPE__GROUP);
		createEReference(partnerLinksTypeEClass, PARTNER_LINKS_TYPE__PARTNER_LINK);

		partnerLinkTypeEClass = createEClass(PARTNER_LINK_TYPE);
		createEReference(partnerLinkTypeEClass, PARTNER_LINK_TYPE__PARTNER_ROLE);
		createEReference(partnerLinkTypeEClass, PARTNER_LINK_TYPE__MY_ROLE);
		createEAttribute(partnerLinkTypeEClass, PARTNER_LINK_TYPE__NAME);

		partnerRoleTypeEClass = createEClass(PARTNER_ROLE_TYPE);
		createEAttribute(partnerRoleTypeEClass, PARTNER_ROLE_TYPE__ANY);
		createEAttribute(partnerRoleTypeEClass, PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI);
		createEAttribute(partnerRoleTypeEClass, PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE);
		createEAttribute(partnerRoleTypeEClass, PARTNER_ROLE_TYPE__INVOKE_HANDLER);

		processTypeEClass = createEClass(PROCESS_TYPE);
		createEReference(processTypeEClass, PROCESS_TYPE__VERSION);
		createEReference(processTypeEClass, PROCESS_TYPE__PARTNER_LINKS);
		createEReference(processTypeEClass, PROCESS_TYPE__INDEXED_PROPERTIES);
		createEReference(processTypeEClass, PROCESS_TYPE__WSDL_REFERENCES);
		createEAttribute(processTypeEClass, PROCESS_TYPE__LOCATION);
		createEAttribute(processTypeEClass, PROCESS_TYPE__NAME);
		createEAttribute(processTypeEClass, PROCESS_TYPE__PERSISTENCE_TYPE);
		createEAttribute(processTypeEClass, PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT);
		createEAttribute(processTypeEClass, PROCESS_TYPE__TRANSACTION_TYPE);

		variableTypeEClass = createEClass(VARIABLE_TYPE);
		createEAttribute(variableTypeEClass, VARIABLE_TYPE__PART);
		createEAttribute(variableTypeEClass, VARIABLE_TYPE__PATH);
		createEAttribute(variableTypeEClass, VARIABLE_TYPE__QUERY);

		variableType1EClass = createEClass(VARIABLE_TYPE1);
		createEAttribute(variableType1EClass, VARIABLE_TYPE1__PART);
		createEAttribute(variableType1EClass, VARIABLE_TYPE1__PATH);
		createEAttribute(variableType1EClass, VARIABLE_TYPE1__QUERY);

		versionTypeEClass = createEClass(VERSION_TYPE);
		createEAttribute(versionTypeEClass, VERSION_TYPE__EFFECTIVE_DATE);
		createEAttribute(versionTypeEClass, VERSION_TYPE__EXPIRATION_DATE);
		createEAttribute(versionTypeEClass, VERSION_TYPE__ID);
		createEAttribute(versionTypeEClass, VERSION_TYPE__RUNNING_PROCESS_DISPOSITION);

		wsdlReferencesTypeEClass = createEClass(WSDL_REFERENCES_TYPE);
		createEAttribute(wsdlReferencesTypeEClass, WSDL_REFERENCES_TYPE__GROUP);
		createEReference(wsdlReferencesTypeEClass, WSDL_REFERENCES_TYPE__WSDL);

		wsdlTypeEClass = createEClass(WSDL_TYPE);
		createEAttribute(wsdlTypeEClass, WSDL_TYPE__LOCATION);
		createEAttribute(wsdlTypeEClass, WSDL_TYPE__NAMESPACE);

		// Create enums
		dispositionTypeEEnum = createEEnum(DISPOSITION_TYPE);
		myRoleBindingTypeEEnum = createEEnum(MY_ROLE_BINDING_TYPE);
		partnerRoleEndpointReferenceTypeEEnum = createEEnum(PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE);
		persistenceTypeEEnum = createEEnum(PERSISTENCE_TYPE);
		suspendFlagEEnum = createEEnum(SUSPEND_FLAG);
		transactionTypeEEnum = createEEnum(TRANSACTION_TYPE);

		// Create data types
		customInvokerUriTypeEDataType = createEDataType(CUSTOM_INVOKER_URI_TYPE);
		dispositionTypeObjectEDataType = createEDataType(DISPOSITION_TYPE_OBJECT);
		invokeHandlerTypeEDataType = createEDataType(INVOKE_HANDLER_TYPE);
		myRoleBindingTypeObjectEDataType = createEDataType(MY_ROLE_BINDING_TYPE_OBJECT);
		partnerRoleEndpointReferenceTypeObjectEDataType = createEDataType(PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT);
		persistenceTypeObjectEDataType = createEDataType(PERSISTENCE_TYPE_OBJECT);
		suspendFlagObjectEDataType = createEDataType(SUSPEND_FLAG_OBJECT);
		transactionTypeObjectEDataType = createEDataType(TRANSACTION_TYPE_OBJECT);
		versionAttributeTypeEDataType = createEDataType(VERSION_ATTRIBUTE_TYPE);
		versionAttributeTypeObjectEDataType = createEDataType(VERSION_ATTRIBUTE_TYPE_OBJECT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);

		// Add supertypes to classes

		// Initialize classes and features; add operations and parameters
		initEClass(documentRootEClass, DocumentRoot.class, "DocumentRoot", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDocumentRoot_Mixed(), ecorePackage.getEFeatureMapEntry(), "mixed", null, 0, -1, null, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XMLNSPrefixMap(), ecorePackage.getEStringToStringMapEntry(), null, "xMLNSPrefixMap", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_XSISchemaLocation(), ecorePackage.getEStringToStringMapEntry(), null, "xSISchemaLocation", null, 0, -1, null, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocumentRoot_Process(), this.getProcessType(), null, "process", null, 0, -2, null, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(indexedPropertiesTypeEClass, IndexedPropertiesType.class, "IndexedPropertiesType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIndexedPropertiesType_Group(), ecorePackage.getEFeatureMapEntry(), "group", null, 0, -1, IndexedPropertiesType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIndexedPropertiesType_IndexedProperty(), this.getIndexedPropertyType(), null, "indexedProperty", null, 0, -1, IndexedPropertiesType.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(indexedPropertyTypeEClass, IndexedPropertyType.class, "IndexedPropertyType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getIndexedPropertyType_Group(), ecorePackage.getEFeatureMapEntry(), "group", null, 0, -1, IndexedPropertyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIndexedPropertyType_Variable(), this.getVariableType1(), null, "variable", null, 0, -1, IndexedPropertyType.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEAttribute(getIndexedPropertyType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, IndexedPropertyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getIndexedPropertyType_Type(), theXMLTypePackage.getString(), "type", null, 1, 1, IndexedPropertyType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(myRoleTypeEClass, MyRoleType.class, "MyRoleType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMyRoleType_Any(), ecorePackage.getEFeatureMapEntry(), "any", null, 0, -1, MyRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMyRoleType_AllowedRoles(), theXMLTypePackage.getString(), "allowedRoles", null, 0, 1, MyRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMyRoleType_Binding(), this.getMyRoleBindingType(), "binding", "RPC", 1, 1, MyRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMyRoleType_Service(), theXMLTypePackage.getString(), "service", null, 1, 1, MyRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(partnerLinksTypeEClass, PartnerLinksType.class, "PartnerLinksType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPartnerLinksType_Group(), ecorePackage.getEFeatureMapEntry(), "group", null, 0, -1, PartnerLinksType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPartnerLinksType_PartnerLink(), this.getPartnerLinkType(), null, "partnerLink", null, 1, -1, PartnerLinksType.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(partnerLinkTypeEClass, PartnerLinkType.class, "PartnerLinkType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPartnerLinkType_PartnerRole(), this.getPartnerRoleType(), null, "partnerRole", null, 0, 1, PartnerLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPartnerLinkType_MyRole(), this.getMyRoleType(), null, "myRole", null, 0, 1, PartnerLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPartnerLinkType_Name(), theXMLTypePackage.getString(), "name", null, 1, 1, PartnerLinkType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(partnerRoleTypeEClass, PartnerRoleType.class, "PartnerRoleType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPartnerRoleType_Any(), ecorePackage.getEFeatureMapEntry(), "any", null, 0, -1, PartnerRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPartnerRoleType_CustomInvokerUri(), this.getCustomInvokerUriType(), "customInvokerUri", null, 0, 1, PartnerRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPartnerRoleType_EndpointReference(), this.getPartnerRoleEndpointReferenceType(), "endpointReference", "static", 1, 1, PartnerRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPartnerRoleType_InvokeHandler(), this.getInvokeHandlerType(), "invokeHandler", null, 0, 1, PartnerRoleType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(processTypeEClass, ProcessType.class, "ProcessType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProcessType_Version(), this.getVersionType(), null, "version", null, 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProcessType_PartnerLinks(), this.getPartnerLinksType(), null, "partnerLinks", null, 1, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProcessType_IndexedProperties(), this.getIndexedPropertiesType(), null, "indexedProperties", null, 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProcessType_WsdlReferences(), this.getWsdlReferencesType(), null, "wsdlReferences", null, 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcessType_Location(), theXMLTypePackage.getString(), "location", null, 1, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcessType_Name(), theXMLTypePackage.getQName(), "name", null, 1, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcessType_PersistenceType(), this.getPersistenceType(), "persistenceType", "full", 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcessType_SuspendProcessOnUncaughtFault(), this.getSuspendFlag(), "suspendProcessOnUncaughtFault", "true", 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getProcessType_TransactionType(), this.getTransactionType(), "transactionType", "bean", 0, 1, ProcessType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(variableTypeEClass, VariableType.class, "VariableType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVariableType_Part(), theXMLTypePackage.getString(), "part", null, 0, 1, VariableType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVariableType_Path(), theXMLTypePackage.getString(), "path", null, 1, 1, VariableType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVariableType_Query(), theXMLTypePackage.getString(), "query", null, 0, 1, VariableType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(variableType1EClass, VariableType1.class, "VariableType1", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVariableType1_Part(), theXMLTypePackage.getString(), "part", null, 0, 1, VariableType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVariableType1_Path(), theXMLTypePackage.getString(), "path", null, 1, 1, VariableType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVariableType1_Query(), theXMLTypePackage.getString(), "query", null, 0, 1, VariableType1.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(versionTypeEClass, VersionType.class, "VersionType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVersionType_EffectiveDate(), theXMLTypePackage.getDateTime(), "effectiveDate", null, 0, 1, VersionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersionType_ExpirationDate(), theXMLTypePackage.getDateTime(), "expirationDate", null, 0, 1, VersionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersionType_Id(), this.getVersionAttributeType(), "id", null, 0, 1, VersionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVersionType_RunningProcessDisposition(), this.getDispositionType(), "runningProcessDisposition", "terminate", 0, 1, VersionType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(wsdlReferencesTypeEClass, WsdlReferencesType.class, "WsdlReferencesType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWsdlReferencesType_Group(), ecorePackage.getEFeatureMapEntry(), "group", null, 0, -1, WsdlReferencesType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWsdlReferencesType_Wsdl(), this.getWsdlType(), null, "wsdl", null, 1, -1, WsdlReferencesType.class, IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(wsdlTypeEClass, WsdlType.class, "WsdlType", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWsdlType_Location(), theXMLTypePackage.getString(), "location", null, 1, 1, WsdlType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWsdlType_Namespace(), theXMLTypePackage.getString(), "namespace", null, 1, 1, WsdlType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, !IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(dispositionTypeEEnum, DispositionType.class, "DispositionType");
		addEEnumLiteral(dispositionTypeEEnum, DispositionType.TERMINATE_LITERAL);
		addEEnumLiteral(dispositionTypeEEnum, DispositionType.MAINTAIN_LITERAL);
		addEEnumLiteral(dispositionTypeEEnum, DispositionType.MIGRATE_LITERAL);

		initEEnum(myRoleBindingTypeEEnum, MyRoleBindingType.class, "MyRoleBindingType");
		addEEnumLiteral(myRoleBindingTypeEEnum, MyRoleBindingType.RPC_LITERAL);
		addEEnumLiteral(myRoleBindingTypeEEnum, MyRoleBindingType.RPCLIT_LITERAL);
		addEEnumLiteral(myRoleBindingTypeEEnum, MyRoleBindingType.MSG_LITERAL);
		addEEnumLiteral(myRoleBindingTypeEEnum, MyRoleBindingType.EXTERNAL_LITERAL);

		initEEnum(partnerRoleEndpointReferenceTypeEEnum, PartnerRoleEndpointReferenceType.class, "PartnerRoleEndpointReferenceType");
		addEEnumLiteral(partnerRoleEndpointReferenceTypeEEnum, PartnerRoleEndpointReferenceType.STATIC_LITERAL);
		addEEnumLiteral(partnerRoleEndpointReferenceTypeEEnum, PartnerRoleEndpointReferenceType.DYNAMIC_LITERAL);
		addEEnumLiteral(partnerRoleEndpointReferenceTypeEEnum, PartnerRoleEndpointReferenceType.INVOKER_LITERAL);
		addEEnumLiteral(partnerRoleEndpointReferenceTypeEEnum, PartnerRoleEndpointReferenceType.PRINCIPAL_LITERAL);

		initEEnum(persistenceTypeEEnum, PersistenceType.class, "PersistenceType");
		addEEnumLiteral(persistenceTypeEEnum, PersistenceType.FULL_LITERAL);
		addEEnumLiteral(persistenceTypeEEnum, PersistenceType.NONE_LITERAL);

		initEEnum(suspendFlagEEnum, SuspendFlag.class, "SuspendFlag");
		addEEnumLiteral(suspendFlagEEnum, SuspendFlag.TRUE_LITERAL);
		addEEnumLiteral(suspendFlagEEnum, SuspendFlag.FALSE_LITERAL);

		initEEnum(transactionTypeEEnum, TransactionType.class, "TransactionType");
		addEEnumLiteral(transactionTypeEEnum, TransactionType.BEAN_LITERAL);
		addEEnumLiteral(transactionTypeEEnum, TransactionType.CONTAINER_LITERAL);

		// Initialize data types
		initEDataType(customInvokerUriTypeEDataType, String.class, "CustomInvokerUriType", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(dispositionTypeObjectEDataType, DispositionType.class, "DispositionTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(invokeHandlerTypeEDataType, String.class, "InvokeHandlerType", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(myRoleBindingTypeObjectEDataType, MyRoleBindingType.class, "MyRoleBindingTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(partnerRoleEndpointReferenceTypeObjectEDataType, PartnerRoleEndpointReferenceType.class, "PartnerRoleEndpointReferenceTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(persistenceTypeObjectEDataType, PersistenceType.class, "PersistenceTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(suspendFlagObjectEDataType, SuspendFlag.class, "SuspendFlagObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(transactionTypeObjectEDataType, TransactionType.class, "TransactionTypeObject", IS_SERIALIZABLE, IS_GENERATED_INSTANCE_CLASS);
		initEDataType(versionAttributeTypeEDataType, float.class, "VersionAttributeType", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(versionAttributeTypeObjectEDataType, Float.class, "VersionAttributeTypeObject", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http:///org/eclipse/emf/ecore/util/ExtendedMetaData
		createExtendedMetaDataAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http:///org/eclipse/emf/ecore/util/ExtendedMetaData</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createExtendedMetaDataAnnotations() {
		String source = "http:///org/eclipse/emf/ecore/util/ExtendedMetaData";		
		addAnnotation
		  (customInvokerUriTypeEDataType, 
		   source, 
		   new String[] {
			 "name", "customInvokerUriType",
			 "baseType", "http://www.eclipse.org/emf/2003/XMLType#anyURI"
		   });		
		addAnnotation
		  (dispositionTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "dispositionType"
		   });		
		addAnnotation
		  (dispositionTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "dispositionType:Object",
			 "baseType", "dispositionType"
		   });		
		addAnnotation
		  (documentRootEClass, 
		   source, 
		   new String[] {
			 "name", "",
			 "kind", "mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_Mixed(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "name", ":mixed"
		   });		
		addAnnotation
		  (getDocumentRoot_XMLNSPrefixMap(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xmlns:prefix"
		   });		
		addAnnotation
		  (getDocumentRoot_XSISchemaLocation(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "xsi:schemaLocation"
		   });		
		addAnnotation
		  (getDocumentRoot_Process(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "process",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (indexedPropertiesTypeEClass, 
		   source, 
		   new String[] {
			 "name", "indexedProperties_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getIndexedPropertiesType_Group(), 
		   source, 
		   new String[] {
			 "kind", "group",
			 "name", "group:0"
		   });		
		addAnnotation
		  (getIndexedPropertiesType_IndexedProperty(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "indexedProperty",
			 "namespace", "##targetNamespace",
			 "group", "#group:0"
		   });		
		addAnnotation
		  (indexedPropertyTypeEClass, 
		   source, 
		   new String[] {
			 "name", "indexedPropertyType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getIndexedPropertyType_Group(), 
		   source, 
		   new String[] {
			 "kind", "group",
			 "name", "group:0"
		   });		
		addAnnotation
		  (getIndexedPropertyType_Variable(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "variable",
			 "namespace", "##targetNamespace",
			 "group", "#group:0"
		   });		
		addAnnotation
		  (getIndexedPropertyType_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getIndexedPropertyType_Type(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "type"
		   });		
		addAnnotation
		  (invokeHandlerTypeEDataType, 
		   source, 
		   new String[] {
			 "name", "invokeHandlerType",
			 "baseType", "http://www.eclipse.org/emf/2003/XMLType#anyURI",
			 "pattern", "[a-zA-Z0-9]+(:.+)?"
		   });		
		addAnnotation
		  (myRoleBindingTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "myRoleBindingType"
		   });		
		addAnnotation
		  (myRoleBindingTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "myRoleBindingType:Object",
			 "baseType", "myRoleBindingType"
		   });		
		addAnnotation
		  (myRoleTypeEClass, 
		   source, 
		   new String[] {
			 "name", "myRoleType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getMyRoleType_Any(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "wildcards", "##any",
			 "name", ":0",
			 "processing", "skip"
		   });		
		addAnnotation
		  (getMyRoleType_AllowedRoles(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "allowedRoles"
		   });		
		addAnnotation
		  (getMyRoleType_Binding(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "binding"
		   });		
		addAnnotation
		  (getMyRoleType_Service(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "service"
		   });		
		addAnnotation
		  (partnerLinksTypeEClass, 
		   source, 
		   new String[] {
			 "name", "partnerLinks_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getPartnerLinksType_Group(), 
		   source, 
		   new String[] {
			 "kind", "group",
			 "name", "group:0"
		   });		
		addAnnotation
		  (getPartnerLinksType_PartnerLink(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "partnerLink",
			 "namespace", "##targetNamespace",
			 "group", "#group:0"
		   });		
		addAnnotation
		  (partnerLinkTypeEClass, 
		   source, 
		   new String[] {
			 "name", "partnerLinkType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getPartnerLinkType_PartnerRole(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "partnerRole",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getPartnerLinkType_MyRole(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "myRole",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getPartnerLinkType_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (partnerRoleEndpointReferenceTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "partnerRoleEndpointReferenceType"
		   });		
		addAnnotation
		  (partnerRoleEndpointReferenceTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "partnerRoleEndpointReferenceType:Object",
			 "baseType", "partnerRoleEndpointReferenceType"
		   });		
		addAnnotation
		  (partnerRoleTypeEClass, 
		   source, 
		   new String[] {
			 "name", "partnerRoleType",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getPartnerRoleType_Any(), 
		   source, 
		   new String[] {
			 "kind", "elementWildcard",
			 "wildcards", "##any",
			 "name", ":0",
			 "processing", "skip"
		   });		
		addAnnotation
		  (getPartnerRoleType_CustomInvokerUri(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "customInvokerUri"
		   });		
		addAnnotation
		  (getPartnerRoleType_EndpointReference(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "endpointReference"
		   });		
		addAnnotation
		  (getPartnerRoleType_InvokeHandler(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "invokeHandler"
		   });		
		addAnnotation
		  (persistenceTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "persistenceType"
		   });		
		addAnnotation
		  (persistenceTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "persistenceType:Object",
			 "baseType", "persistenceType"
		   });		
		addAnnotation
		  (processTypeEClass, 
		   source, 
		   new String[] {
			 "name", "process_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getProcessType_Version(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "version",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getProcessType_PartnerLinks(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "partnerLinks",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getProcessType_IndexedProperties(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "indexedProperties",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getProcessType_WsdlReferences(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "wsdlReferences",
			 "namespace", "##targetNamespace"
		   });		
		addAnnotation
		  (getProcessType_Location(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "location"
		   });		
		addAnnotation
		  (getProcessType_Name(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "name"
		   });		
		addAnnotation
		  (getProcessType_PersistenceType(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "persistenceType"
		   });		
		addAnnotation
		  (getProcessType_SuspendProcessOnUncaughtFault(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "suspendProcessOnUncaughtFault"
		   });		
		addAnnotation
		  (getProcessType_TransactionType(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "transactionType"
		   });		
		addAnnotation
		  (suspendFlagEEnum, 
		   source, 
		   new String[] {
			 "name", "suspendFlag"
		   });		
		addAnnotation
		  (suspendFlagObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "suspendFlag:Object",
			 "baseType", "suspendFlag"
		   });		
		addAnnotation
		  (transactionTypeEEnum, 
		   source, 
		   new String[] {
			 "name", "transactionType"
		   });		
		addAnnotation
		  (transactionTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "transactionType:Object",
			 "baseType", "transactionType"
		   });		
		addAnnotation
		  (variableTypeEClass, 
		   source, 
		   new String[] {
			 "name", "variableType",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getVariableType_Part(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "part"
		   });		
		addAnnotation
		  (getVariableType_Path(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "path"
		   });		
		addAnnotation
		  (getVariableType_Query(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "query"
		   });		
		addAnnotation
		  (variableType1EClass, 
		   source, 
		   new String[] {
			 "name", "variable_._type",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getVariableType1_Part(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "part"
		   });		
		addAnnotation
		  (getVariableType1_Path(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "path"
		   });		
		addAnnotation
		  (getVariableType1_Query(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "query"
		   });		
		addAnnotation
		  (versionAttributeTypeEDataType, 
		   source, 
		   new String[] {
			 "name", "versionAttributeType",
			 "baseType", "http://www.eclipse.org/emf/2003/XMLType#float",
			 "pattern", "[0-9]+(\\.[0-9]{1,2})?"
		   });		
		addAnnotation
		  (versionAttributeTypeObjectEDataType, 
		   source, 
		   new String[] {
			 "name", "versionAttributeType:Object",
			 "baseType", "versionAttributeType"
		   });		
		addAnnotation
		  (versionTypeEClass, 
		   source, 
		   new String[] {
			 "name", "version_._type",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getVersionType_EffectiveDate(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "effectiveDate"
		   });		
		addAnnotation
		  (getVersionType_ExpirationDate(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "expirationDate"
		   });		
		addAnnotation
		  (getVersionType_Id(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "id"
		   });		
		addAnnotation
		  (getVersionType_RunningProcessDisposition(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "runningProcessDisposition"
		   });		
		addAnnotation
		  (wsdlReferencesTypeEClass, 
		   source, 
		   new String[] {
			 "name", "wsdlReferences_._type",
			 "kind", "elementOnly"
		   });		
		addAnnotation
		  (getWsdlReferencesType_Group(), 
		   source, 
		   new String[] {
			 "kind", "group",
			 "name", "group:0"
		   });		
		addAnnotation
		  (getWsdlReferencesType_Wsdl(), 
		   source, 
		   new String[] {
			 "kind", "element",
			 "name", "wsdl",
			 "namespace", "##targetNamespace",
			 "group", "#group:0"
		   });		
		addAnnotation
		  (wsdlTypeEClass, 
		   source, 
		   new String[] {
			 "name", "wsdlType",
			 "kind", "empty"
		   });		
		addAnnotation
		  (getWsdlType_Location(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "location"
		   });		
		addAnnotation
		  (getWsdlType_Namespace(), 
		   source, 
		   new String[] {
			 "kind", "attribute",
			 "name", "namespace"
		   });
	}

} //PddPackageImpl
