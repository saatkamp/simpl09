/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IPddConstants;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util.PddResourceFactoryImpl
 * @generated
 */
public class PddResourceImpl extends XMLResourceImpl {
	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param uri the URI of the new resource.
	 * @generated
	 */
	public PddResourceImpl(URI uri) {
		super(uri);
	}
	
	/**
	 * Had to override this as default is 'ASCII' and we need 'UTF-8'.
	 * 
	 * @link XMLResourceImpl#getEncoding()
	 */
	public String getEncoding() {
		return IPddConstants.XML_ENCODING_UTF8;
	}

	
} //PddResourceImpl
