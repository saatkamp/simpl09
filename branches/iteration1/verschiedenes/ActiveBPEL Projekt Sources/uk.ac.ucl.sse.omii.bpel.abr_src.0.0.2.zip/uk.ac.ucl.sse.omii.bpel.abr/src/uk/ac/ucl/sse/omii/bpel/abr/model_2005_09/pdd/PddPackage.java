/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddFactory
 * @model kind="package"
 * @generated
 */
public interface PddPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "pdd";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * TODO THIS IS WHAT YOU CAN CHANGE AS A QUICK FIX TO THE BUG IN ACTIVEBPEL PDD VALIDATION!!!
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://schemas.active-endpoints.com/pdd/2005/09/pdd.xsd";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "pdd";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PddPackage eINSTANCE = uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl.init();

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.DocumentRootImpl <em>Document Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.DocumentRootImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDocumentRoot()
	 * @generated
	 */
	int DOCUMENT_ROOT = 0;

	/**
	 * The feature id for the '<em><b>Mixed</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__MIXED = 0;

	/**
	 * The feature id for the '<em><b>XMLNS Prefix Map</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XMLNS_PREFIX_MAP = 1;

	/**
	 * The feature id for the '<em><b>XSI Schema Location</b></em>' map.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = 2;

	/**
	 * The feature id for the '<em><b>Process</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT__PROCESS = 3;

	/**
	 * The number of structural features of the '<em>Document Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCUMENT_ROOT_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertiesTypeImpl <em>Indexed Properties Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertiesTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getIndexedPropertiesType()
	 * @generated
	 */
	int INDEXED_PROPERTIES_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Group</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTIES_TYPE__GROUP = 0;

	/**
	 * The feature id for the '<em><b>Indexed Property</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTIES_TYPE__INDEXED_PROPERTY = 1;

	/**
	 * The number of structural features of the '<em>Indexed Properties Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTIES_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertyTypeImpl <em>Indexed Property Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertyTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getIndexedPropertyType()
	 * @generated
	 */
	int INDEXED_PROPERTY_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Group</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTY_TYPE__GROUP = 0;

	/**
	 * The feature id for the '<em><b>Variable</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTY_TYPE__VARIABLE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTY_TYPE__NAME = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTY_TYPE__TYPE = 3;

	/**
	 * The number of structural features of the '<em>Indexed Property Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDEXED_PROPERTY_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl <em>My Role Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleType()
	 * @generated
	 */
	int MY_ROLE_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Any</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MY_ROLE_TYPE__ANY = 0;

	/**
	 * The feature id for the '<em><b>Allowed Roles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MY_ROLE_TYPE__ALLOWED_ROLES = 1;

	/**
	 * The feature id for the '<em><b>Binding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MY_ROLE_TYPE__BINDING = 2;

	/**
	 * The feature id for the '<em><b>Service</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MY_ROLE_TYPE__SERVICE = 3;

	/**
	 * The number of structural features of the '<em>My Role Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MY_ROLE_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinksTypeImpl <em>Partner Links Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinksTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerLinksType()
	 * @generated
	 */
	int PARTNER_LINKS_TYPE = 4;

	/**
	 * The feature id for the '<em><b>Group</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINKS_TYPE__GROUP = 0;

	/**
	 * The feature id for the '<em><b>Partner Link</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINKS_TYPE__PARTNER_LINK = 1;

	/**
	 * The number of structural features of the '<em>Partner Links Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINKS_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinkTypeImpl <em>Partner Link Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinkTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerLinkType()
	 * @generated
	 */
	int PARTNER_LINK_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Partner Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINK_TYPE__PARTNER_ROLE = 0;

	/**
	 * The feature id for the '<em><b>My Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINK_TYPE__MY_ROLE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINK_TYPE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Partner Link Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_LINK_TYPE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl <em>Partner Role Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleType()
	 * @generated
	 */
	int PARTNER_ROLE_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Any</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_ROLE_TYPE__ANY = 0;

	/**
	 * The feature id for the '<em><b>Custom Invoker Uri</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI = 1;

	/**
	 * The feature id for the '<em><b>Endpoint Reference</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE = 2;

	/**
	 * The feature id for the '<em><b>Invoke Handler</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_ROLE_TYPE__INVOKE_HANDLER = 3;

	/**
	 * The number of structural features of the '<em>Partner Role Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARTNER_ROLE_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl <em>Process Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getProcessType()
	 * @generated
	 */
	int PROCESS_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Version</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__VERSION = 0;

	/**
	 * The feature id for the '<em><b>Partner Links</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__PARTNER_LINKS = 1;

	/**
	 * The feature id for the '<em><b>Indexed Properties</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__INDEXED_PROPERTIES = 2;

	/**
	 * The feature id for the '<em><b>Wsdl References</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__WSDL_REFERENCES = 3;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__LOCATION = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__NAME = 5;

	/**
	 * The feature id for the '<em><b>Persistence Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__PERSISTENCE_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Suspend Process On Uncaught Fault</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT = 7;

	/**
	 * The feature id for the '<em><b>Transaction Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE__TRANSACTION_TYPE = 8;

	/**
	 * The number of structural features of the '<em>Process Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_TYPE_FEATURE_COUNT = 9;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableTypeImpl <em>Variable Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVariableType()
	 * @generated
	 */
	int VARIABLE_TYPE = 8;

	/**
	 * The feature id for the '<em><b>Part</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE__PART = 0;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE__PATH = 1;

	/**
	 * The feature id for the '<em><b>Query</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE__QUERY = 2;

	/**
	 * The number of structural features of the '<em>Variable Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableType1Impl <em>Variable Type1</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableType1Impl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVariableType1()
	 * @generated
	 */
	int VARIABLE_TYPE1 = 9;

	/**
	 * The feature id for the '<em><b>Part</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE1__PART = 0;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE1__PATH = 1;

	/**
	 * The feature id for the '<em><b>Query</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE1__QUERY = 2;

	/**
	 * The number of structural features of the '<em>Variable Type1</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VARIABLE_TYPE1_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl <em>Version Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionType()
	 * @generated
	 */
	int VERSION_TYPE = 10;

	/**
	 * The feature id for the '<em><b>Effective Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_TYPE__EFFECTIVE_DATE = 0;

	/**
	 * The feature id for the '<em><b>Expiration Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_TYPE__EXPIRATION_DATE = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_TYPE__ID = 2;

	/**
	 * The feature id for the '<em><b>Running Process Disposition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_TYPE__RUNNING_PROCESS_DISPOSITION = 3;

	/**
	 * The number of structural features of the '<em>Version Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VERSION_TYPE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlReferencesTypeImpl <em>Wsdl References Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlReferencesTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getWsdlReferencesType()
	 * @generated
	 */
	int WSDL_REFERENCES_TYPE = 11;

	/**
	 * The feature id for the '<em><b>Group</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_REFERENCES_TYPE__GROUP = 0;

	/**
	 * The feature id for the '<em><b>Wsdl</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_REFERENCES_TYPE__WSDL = 1;

	/**
	 * The number of structural features of the '<em>Wsdl References Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_REFERENCES_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlTypeImpl <em>Wsdl Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlTypeImpl
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getWsdlType()
	 * @generated
	 */
	int WSDL_TYPE = 12;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_TYPE__LOCATION = 0;

	/**
	 * The feature id for the '<em><b>Namespace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_TYPE__NAMESPACE = 1;

	/**
	 * The number of structural features of the '<em>Wsdl Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WSDL_TYPE_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType <em>Disposition Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDispositionType()
	 * @generated
	 */
	int DISPOSITION_TYPE = 13;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType <em>My Role Binding Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleBindingType()
	 * @generated
	 */
	int MY_ROLE_BINDING_TYPE = 14;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType <em>Partner Role Endpoint Reference Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleEndpointReferenceType()
	 * @generated
	 */
	int PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE = 15;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType <em>Persistence Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPersistenceType()
	 * @generated
	 */
	int PERSISTENCE_TYPE = 16;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag <em>Suspend Flag</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getSuspendFlag()
	 * @generated
	 */
	int SUSPEND_FLAG = 17;

	/**
	 * The meta object id for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType <em>Transaction Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getTransactionType()
	 * @generated
	 */
	int TRANSACTION_TYPE = 18;

	/**
	 * The meta object id for the '<em>Custom Invoker Uri Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getCustomInvokerUriType()
	 * @generated
	 */
	int CUSTOM_INVOKER_URI_TYPE = 19;

	/**
	 * The meta object id for the '<em>Disposition Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDispositionTypeObject()
	 * @generated
	 */
	int DISPOSITION_TYPE_OBJECT = 20;

	/**
	 * The meta object id for the '<em>Invoke Handler Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.String
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getInvokeHandlerType()
	 * @generated
	 */
	int INVOKE_HANDLER_TYPE = 21;

	/**
	 * The meta object id for the '<em>My Role Binding Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleBindingTypeObject()
	 * @generated
	 */
	int MY_ROLE_BINDING_TYPE_OBJECT = 22;

	/**
	 * The meta object id for the '<em>Partner Role Endpoint Reference Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleEndpointReferenceTypeObject()
	 * @generated
	 */
	int PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT = 23;

	/**
	 * The meta object id for the '<em>Persistence Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPersistenceTypeObject()
	 * @generated
	 */
	int PERSISTENCE_TYPE_OBJECT = 24;

	/**
	 * The meta object id for the '<em>Suspend Flag Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getSuspendFlagObject()
	 * @generated
	 */
	int SUSPEND_FLAG_OBJECT = 25;

	/**
	 * The meta object id for the '<em>Transaction Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getTransactionTypeObject()
	 * @generated
	 */
	int TRANSACTION_TYPE_OBJECT = 26;

	/**
	 * The meta object id for the '<em>Version Attribute Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionAttributeType()
	 * @generated
	 */
	int VERSION_ATTRIBUTE_TYPE = 27;

	/**
	 * The meta object id for the '<em>Version Attribute Type Object</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Float
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionAttributeTypeObject()
	 * @generated
	 */
	int VERSION_ATTRIBUTE_TYPE_OBJECT = 28;


	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Document Root</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot
	 * @generated
	 */
	EClass getDocumentRoot();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getMixed <em>Mixed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Mixed</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getMixed()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EAttribute getDocumentRoot_Mixed();

	/**
	 * Returns the meta object for the map '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getXMLNSPrefixMap <em>XMLNS Prefix Map</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XMLNS Prefix Map</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getXMLNSPrefixMap()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XMLNSPrefixMap();

	/**
	 * Returns the meta object for the map '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getXSISchemaLocation <em>XSI Schema Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the map '<em>XSI Schema Location</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getXSISchemaLocation()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_XSISchemaLocation();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getProcess <em>Process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Process</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot#getProcess()
	 * @see #getDocumentRoot()
	 * @generated
	 */
	EReference getDocumentRoot_Process();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType <em>Indexed Properties Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Indexed Properties Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType
	 * @generated
	 */
	EClass getIndexedPropertiesType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Group</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType#getGroup()
	 * @see #getIndexedPropertiesType()
	 * @generated
	 */
	EAttribute getIndexedPropertiesType_Group();

	/**
	 * Returns the meta object for the containment reference list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType#getIndexedProperty <em>Indexed Property</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Indexed Property</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType#getIndexedProperty()
	 * @see #getIndexedPropertiesType()
	 * @generated
	 */
	EReference getIndexedPropertiesType_IndexedProperty();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType <em>Indexed Property Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Indexed Property Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType
	 * @generated
	 */
	EClass getIndexedPropertyType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Group</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getGroup()
	 * @see #getIndexedPropertyType()
	 * @generated
	 */
	EAttribute getIndexedPropertyType_Group();

	/**
	 * Returns the meta object for the containment reference list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getVariable <em>Variable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Variable</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getVariable()
	 * @see #getIndexedPropertyType()
	 * @generated
	 */
	EReference getIndexedPropertyType_Variable();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getName()
	 * @see #getIndexedPropertyType()
	 * @generated
	 */
	EAttribute getIndexedPropertyType_Name();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType#getType()
	 * @see #getIndexedPropertyType()
	 * @generated
	 */
	EAttribute getIndexedPropertyType_Type();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType <em>My Role Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>My Role Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType
	 * @generated
	 */
	EClass getMyRoleType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAny <em>Any</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Any</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAny()
	 * @see #getMyRoleType()
	 * @generated
	 */
	EAttribute getMyRoleType_Any();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAllowedRoles <em>Allowed Roles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Allowed Roles</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getAllowedRoles()
	 * @see #getMyRoleType()
	 * @generated
	 */
	EAttribute getMyRoleType_AllowedRoles();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding <em>Binding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Binding</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getBinding()
	 * @see #getMyRoleType()
	 * @generated
	 */
	EAttribute getMyRoleType_Binding();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType#getService()
	 * @see #getMyRoleType()
	 * @generated
	 */
	EAttribute getMyRoleType_Service();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType <em>Partner Links Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Partner Links Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType
	 * @generated
	 */
	EClass getPartnerLinksType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Group</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType#getGroup()
	 * @see #getPartnerLinksType()
	 * @generated
	 */
	EAttribute getPartnerLinksType_Group();

	/**
	 * Returns the meta object for the containment reference list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType#getPartnerLink <em>Partner Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Partner Link</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType#getPartnerLink()
	 * @see #getPartnerLinksType()
	 * @generated
	 */
	EReference getPartnerLinksType_PartnerLink();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType <em>Partner Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Partner Link Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType
	 * @generated
	 */
	EClass getPartnerLinkType();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getPartnerRole <em>Partner Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Partner Role</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getPartnerRole()
	 * @see #getPartnerLinkType()
	 * @generated
	 */
	EReference getPartnerLinkType_PartnerRole();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getMyRole <em>My Role</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>My Role</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getMyRole()
	 * @see #getPartnerLinkType()
	 * @generated
	 */
	EReference getPartnerLinkType_MyRole();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getName()
	 * @see #getPartnerLinkType()
	 * @generated
	 */
	EAttribute getPartnerLinkType_Name();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType <em>Partner Role Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Partner Role Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType
	 * @generated
	 */
	EClass getPartnerRoleType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getAny <em>Any</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Any</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getAny()
	 * @see #getPartnerRoleType()
	 * @generated
	 */
	EAttribute getPartnerRoleType_Any();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getCustomInvokerUri <em>Custom Invoker Uri</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Custom Invoker Uri</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getCustomInvokerUri()
	 * @see #getPartnerRoleType()
	 * @generated
	 */
	EAttribute getPartnerRoleType_CustomInvokerUri();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference <em>Endpoint Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Endpoint Reference</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference()
	 * @see #getPartnerRoleType()
	 * @generated
	 */
	EAttribute getPartnerRoleType_EndpointReference();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getInvokeHandler <em>Invoke Handler</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Invoke Handler</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getInvokeHandler()
	 * @see #getPartnerRoleType()
	 * @generated
	 */
	EAttribute getPartnerRoleType_InvokeHandler();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType <em>Process Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Process Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType
	 * @generated
	 */
	EClass getProcessType();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Version</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getVersion()
	 * @see #getProcessType()
	 * @generated
	 */
	EReference getProcessType_Version();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPartnerLinks <em>Partner Links</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Partner Links</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPartnerLinks()
	 * @see #getProcessType()
	 * @generated
	 */
	EReference getProcessType_PartnerLinks();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getIndexedProperties <em>Indexed Properties</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Indexed Properties</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getIndexedProperties()
	 * @see #getProcessType()
	 * @generated
	 */
	EReference getProcessType_IndexedProperties();

	/**
	 * Returns the meta object for the containment reference '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getWsdlReferences <em>Wsdl References</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Wsdl References</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getWsdlReferences()
	 * @see #getProcessType()
	 * @generated
	 */
	EReference getProcessType_WsdlReferences();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getLocation()
	 * @see #getProcessType()
	 * @generated
	 */
	EAttribute getProcessType_Location();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getName()
	 * @see #getProcessType()
	 * @generated
	 */
	EAttribute getProcessType_Name();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType <em>Persistence Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Persistence Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getPersistenceType()
	 * @see #getProcessType()
	 * @generated
	 */
	EAttribute getProcessType_PersistenceType();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Suspend Process On Uncaught Fault</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getSuspendProcessOnUncaughtFault()
	 * @see #getProcessType()
	 * @generated
	 */
	EAttribute getProcessType_SuspendProcessOnUncaughtFault();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType <em>Transaction Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transaction Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType#getTransactionType()
	 * @see #getProcessType()
	 * @generated
	 */
	EAttribute getProcessType_TransactionType();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType <em>Variable Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Variable Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType
	 * @generated
	 */
	EClass getVariableType();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getPart <em>Part</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Part</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getPart()
	 * @see #getVariableType()
	 * @generated
	 */
	EAttribute getVariableType_Part();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Path</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getPath()
	 * @see #getVariableType()
	 * @generated
	 */
	EAttribute getVariableType_Path();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getQuery <em>Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Query</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType#getQuery()
	 * @see #getVariableType()
	 * @generated
	 */
	EAttribute getVariableType_Query();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1 <em>Variable Type1</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Variable Type1</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1
	 * @generated
	 */
	EClass getVariableType1();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getPart <em>Part</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Part</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getPart()
	 * @see #getVariableType1()
	 * @generated
	 */
	EAttribute getVariableType1_Part();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Path</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getPath()
	 * @see #getVariableType1()
	 * @generated
	 */
	EAttribute getVariableType1_Path();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getQuery <em>Query</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Query</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1#getQuery()
	 * @see #getVariableType1()
	 * @generated
	 */
	EAttribute getVariableType1_Query();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType <em>Version Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Version Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType
	 * @generated
	 */
	EClass getVersionType();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getEffectiveDate <em>Effective Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effective Date</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getEffectiveDate()
	 * @see #getVersionType()
	 * @generated
	 */
	EAttribute getVersionType_EffectiveDate();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getExpirationDate <em>Expiration Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Expiration Date</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getExpirationDate()
	 * @see #getVersionType()
	 * @generated
	 */
	EAttribute getVersionType_ExpirationDate();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getId()
	 * @see #getVersionType()
	 * @generated
	 */
	EAttribute getVersionType_Id();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition <em>Running Process Disposition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Running Process Disposition</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType#getRunningProcessDisposition()
	 * @see #getVersionType()
	 * @generated
	 */
	EAttribute getVersionType_RunningProcessDisposition();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType <em>Wsdl References Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wsdl References Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType
	 * @generated
	 */
	EClass getWsdlReferencesType();

	/**
	 * Returns the meta object for the attribute list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Group</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType#getGroup()
	 * @see #getWsdlReferencesType()
	 * @generated
	 */
	EAttribute getWsdlReferencesType_Group();

	/**
	 * Returns the meta object for the containment reference list '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType#getWsdl <em>Wsdl</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Wsdl</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType#getWsdl()
	 * @see #getWsdlReferencesType()
	 * @generated
	 */
	EReference getWsdlReferencesType_Wsdl();

	/**
	 * Returns the meta object for class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType <em>Wsdl Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Wsdl Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType
	 * @generated
	 */
	EClass getWsdlType();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType#getLocation()
	 * @see #getWsdlType()
	 * @generated
	 */
	EAttribute getWsdlType_Location();

	/**
	 * Returns the meta object for the attribute '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType#getNamespace <em>Namespace</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Namespace</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType#getNamespace()
	 * @see #getWsdlType()
	 * @generated
	 */
	EAttribute getWsdlType_Namespace();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType <em>Disposition Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Disposition Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @generated
	 */
	EEnum getDispositionType();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType <em>My Role Binding Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>My Role Binding Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @generated
	 */
	EEnum getMyRoleBindingType();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType <em>Partner Role Endpoint Reference Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Partner Role Endpoint Reference Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @generated
	 */
	EEnum getPartnerRoleEndpointReferenceType();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType <em>Persistence Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Persistence Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @generated
	 */
	EEnum getPersistenceType();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag <em>Suspend Flag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Suspend Flag</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @generated
	 */
	EEnum getSuspendFlag();

	/**
	 * Returns the meta object for enum '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType <em>Transaction Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Transaction Type</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @generated
	 */
	EEnum getTransactionType();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Custom Invoker Uri Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Custom Invoker Uri Type</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='customInvokerUriType' baseType='http://www.eclipse.org/emf/2003/XMLType#anyURI'" 
	 * @generated
	 */
	EDataType getCustomInvokerUriType();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType <em>Disposition Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Disposition Type Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType"
	 *        extendedMetaData="name='dispositionType:Object' baseType='dispositionType'" 
	 * @generated
	 */
	EDataType getDispositionTypeObject();

	/**
	 * Returns the meta object for data type '{@link java.lang.String <em>Invoke Handler Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Invoke Handler Type</em>'.
	 * @see java.lang.String
	 * @model instanceClass="java.lang.String"
	 *        extendedMetaData="name='invokeHandlerType' baseType='http://www.eclipse.org/emf/2003/XMLType#anyURI' pattern='[a-zA-Z0-9]+(:.+)?'" 
	 * @generated
	 */
	EDataType getInvokeHandlerType();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType <em>My Role Binding Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>My Role Binding Type Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType"
	 *        extendedMetaData="name='myRoleBindingType:Object' baseType='myRoleBindingType'" 
	 * @generated
	 */
	EDataType getMyRoleBindingTypeObject();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType <em>Partner Role Endpoint Reference Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Partner Role Endpoint Reference Type Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType"
	 *        extendedMetaData="name='partnerRoleEndpointReferenceType:Object' baseType='partnerRoleEndpointReferenceType'" 
	 * @generated
	 */
	EDataType getPartnerRoleEndpointReferenceTypeObject();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType <em>Persistence Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Persistence Type Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType"
	 *        extendedMetaData="name='persistenceType:Object' baseType='persistenceType'" 
	 * @generated
	 */
	EDataType getPersistenceTypeObject();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag <em>Suspend Flag Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Suspend Flag Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag"
	 *        extendedMetaData="name='suspendFlag:Object' baseType='suspendFlag'" 
	 * @generated
	 */
	EDataType getSuspendFlagObject();

	/**
	 * Returns the meta object for data type '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType <em>Transaction Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Transaction Type Object</em>'.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
	 * @model instanceClass="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType"
	 *        extendedMetaData="name='transactionType:Object' baseType='transactionType'" 
	 * @generated
	 */
	EDataType getTransactionTypeObject();

	/**
	 * Returns the meta object for data type '<em>Version Attribute Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Version Attribute Type</em>'.
	 * @model instanceClass="float"
	 *        extendedMetaData="name='versionAttributeType' baseType='http://www.eclipse.org/emf/2003/XMLType#float' pattern='[0-9]+(\\.[0-9]{1,2})?'" 
	 * @generated
	 */
	EDataType getVersionAttributeType();

	/**
	 * Returns the meta object for data type '{@link java.lang.Float <em>Version Attribute Type Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Version Attribute Type Object</em>'.
	 * @see java.lang.Float
	 * @model instanceClass="java.lang.Float"
	 *        extendedMetaData="name='versionAttributeType:Object' baseType='versionAttributeType'" 
	 * @generated
	 */
	EDataType getVersionAttributeTypeObject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PddFactory getPddFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.DocumentRootImpl <em>Document Root</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.DocumentRootImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDocumentRoot()
		 * @generated
		 */
		EClass DOCUMENT_ROOT = eINSTANCE.getDocumentRoot();

		/**
		 * The meta object literal for the '<em><b>Mixed</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCUMENT_ROOT__MIXED = eINSTANCE.getDocumentRoot_Mixed();

		/**
		 * The meta object literal for the '<em><b>XMLNS Prefix Map</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XMLNS_PREFIX_MAP = eINSTANCE.getDocumentRoot_XMLNSPrefixMap();

		/**
		 * The meta object literal for the '<em><b>XSI Schema Location</b></em>' map feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__XSI_SCHEMA_LOCATION = eINSTANCE.getDocumentRoot_XSISchemaLocation();

		/**
		 * The meta object literal for the '<em><b>Process</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCUMENT_ROOT__PROCESS = eINSTANCE.getDocumentRoot_Process();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertiesTypeImpl <em>Indexed Properties Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertiesTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getIndexedPropertiesType()
		 * @generated
		 */
		EClass INDEXED_PROPERTIES_TYPE = eINSTANCE.getIndexedPropertiesType();

		/**
		 * The meta object literal for the '<em><b>Group</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INDEXED_PROPERTIES_TYPE__GROUP = eINSTANCE.getIndexedPropertiesType_Group();

		/**
		 * The meta object literal for the '<em><b>Indexed Property</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INDEXED_PROPERTIES_TYPE__INDEXED_PROPERTY = eINSTANCE.getIndexedPropertiesType_IndexedProperty();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertyTypeImpl <em>Indexed Property Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.IndexedPropertyTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getIndexedPropertyType()
		 * @generated
		 */
		EClass INDEXED_PROPERTY_TYPE = eINSTANCE.getIndexedPropertyType();

		/**
		 * The meta object literal for the '<em><b>Group</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INDEXED_PROPERTY_TYPE__GROUP = eINSTANCE.getIndexedPropertyType_Group();

		/**
		 * The meta object literal for the '<em><b>Variable</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INDEXED_PROPERTY_TYPE__VARIABLE = eINSTANCE.getIndexedPropertyType_Variable();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INDEXED_PROPERTY_TYPE__NAME = eINSTANCE.getIndexedPropertyType_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INDEXED_PROPERTY_TYPE__TYPE = eINSTANCE.getIndexedPropertyType_Type();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl <em>My Role Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.MyRoleTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleType()
		 * @generated
		 */
		EClass MY_ROLE_TYPE = eINSTANCE.getMyRoleType();

		/**
		 * The meta object literal for the '<em><b>Any</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MY_ROLE_TYPE__ANY = eINSTANCE.getMyRoleType_Any();

		/**
		 * The meta object literal for the '<em><b>Allowed Roles</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MY_ROLE_TYPE__ALLOWED_ROLES = eINSTANCE.getMyRoleType_AllowedRoles();

		/**
		 * The meta object literal for the '<em><b>Binding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MY_ROLE_TYPE__BINDING = eINSTANCE.getMyRoleType_Binding();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MY_ROLE_TYPE__SERVICE = eINSTANCE.getMyRoleType_Service();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinksTypeImpl <em>Partner Links Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinksTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerLinksType()
		 * @generated
		 */
		EClass PARTNER_LINKS_TYPE = eINSTANCE.getPartnerLinksType();

		/**
		 * The meta object literal for the '<em><b>Group</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_LINKS_TYPE__GROUP = eINSTANCE.getPartnerLinksType_Group();

		/**
		 * The meta object literal for the '<em><b>Partner Link</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARTNER_LINKS_TYPE__PARTNER_LINK = eINSTANCE.getPartnerLinksType_PartnerLink();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinkTypeImpl <em>Partner Link Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerLinkTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerLinkType()
		 * @generated
		 */
		EClass PARTNER_LINK_TYPE = eINSTANCE.getPartnerLinkType();

		/**
		 * The meta object literal for the '<em><b>Partner Role</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARTNER_LINK_TYPE__PARTNER_ROLE = eINSTANCE.getPartnerLinkType_PartnerRole();

		/**
		 * The meta object literal for the '<em><b>My Role</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARTNER_LINK_TYPE__MY_ROLE = eINSTANCE.getPartnerLinkType_MyRole();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_LINK_TYPE__NAME = eINSTANCE.getPartnerLinkType_Name();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl <em>Partner Role Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PartnerRoleTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleType()
		 * @generated
		 */
		EClass PARTNER_ROLE_TYPE = eINSTANCE.getPartnerRoleType();

		/**
		 * The meta object literal for the '<em><b>Any</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_ROLE_TYPE__ANY = eINSTANCE.getPartnerRoleType_Any();

		/**
		 * The meta object literal for the '<em><b>Custom Invoker Uri</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_ROLE_TYPE__CUSTOM_INVOKER_URI = eINSTANCE.getPartnerRoleType_CustomInvokerUri();

		/**
		 * The meta object literal for the '<em><b>Endpoint Reference</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_ROLE_TYPE__ENDPOINT_REFERENCE = eINSTANCE.getPartnerRoleType_EndpointReference();

		/**
		 * The meta object literal for the '<em><b>Invoke Handler</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARTNER_ROLE_TYPE__INVOKE_HANDLER = eINSTANCE.getPartnerRoleType_InvokeHandler();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl <em>Process Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getProcessType()
		 * @generated
		 */
		EClass PROCESS_TYPE = eINSTANCE.getProcessType();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS_TYPE__VERSION = eINSTANCE.getProcessType_Version();

		/**
		 * The meta object literal for the '<em><b>Partner Links</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS_TYPE__PARTNER_LINKS = eINSTANCE.getProcessType_PartnerLinks();

		/**
		 * The meta object literal for the '<em><b>Indexed Properties</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS_TYPE__INDEXED_PROPERTIES = eINSTANCE.getProcessType_IndexedProperties();

		/**
		 * The meta object literal for the '<em><b>Wsdl References</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS_TYPE__WSDL_REFERENCES = eINSTANCE.getProcessType_WsdlReferences();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS_TYPE__LOCATION = eINSTANCE.getProcessType_Location();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS_TYPE__NAME = eINSTANCE.getProcessType_Name();

		/**
		 * The meta object literal for the '<em><b>Persistence Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS_TYPE__PERSISTENCE_TYPE = eINSTANCE.getProcessType_PersistenceType();

		/**
		 * The meta object literal for the '<em><b>Suspend Process On Uncaught Fault</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT = eINSTANCE.getProcessType_SuspendProcessOnUncaughtFault();

		/**
		 * The meta object literal for the '<em><b>Transaction Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS_TYPE__TRANSACTION_TYPE = eINSTANCE.getProcessType_TransactionType();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableTypeImpl <em>Variable Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVariableType()
		 * @generated
		 */
		EClass VARIABLE_TYPE = eINSTANCE.getVariableType();

		/**
		 * The meta object literal for the '<em><b>Part</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE__PART = eINSTANCE.getVariableType_Part();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE__PATH = eINSTANCE.getVariableType_Path();

		/**
		 * The meta object literal for the '<em><b>Query</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE__QUERY = eINSTANCE.getVariableType_Query();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableType1Impl <em>Variable Type1</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VariableType1Impl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVariableType1()
		 * @generated
		 */
		EClass VARIABLE_TYPE1 = eINSTANCE.getVariableType1();

		/**
		 * The meta object literal for the '<em><b>Part</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE1__PART = eINSTANCE.getVariableType1_Part();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE1__PATH = eINSTANCE.getVariableType1_Path();

		/**
		 * The meta object literal for the '<em><b>Query</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VARIABLE_TYPE1__QUERY = eINSTANCE.getVariableType1_Query();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl <em>Version Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.VersionTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionType()
		 * @generated
		 */
		EClass VERSION_TYPE = eINSTANCE.getVersionType();

		/**
		 * The meta object literal for the '<em><b>Effective Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSION_TYPE__EFFECTIVE_DATE = eINSTANCE.getVersionType_EffectiveDate();

		/**
		 * The meta object literal for the '<em><b>Expiration Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSION_TYPE__EXPIRATION_DATE = eINSTANCE.getVersionType_ExpirationDate();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSION_TYPE__ID = eINSTANCE.getVersionType_Id();

		/**
		 * The meta object literal for the '<em><b>Running Process Disposition</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VERSION_TYPE__RUNNING_PROCESS_DISPOSITION = eINSTANCE.getVersionType_RunningProcessDisposition();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlReferencesTypeImpl <em>Wsdl References Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlReferencesTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getWsdlReferencesType()
		 * @generated
		 */
		EClass WSDL_REFERENCES_TYPE = eINSTANCE.getWsdlReferencesType();

		/**
		 * The meta object literal for the '<em><b>Group</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WSDL_REFERENCES_TYPE__GROUP = eINSTANCE.getWsdlReferencesType_Group();

		/**
		 * The meta object literal for the '<em><b>Wsdl</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WSDL_REFERENCES_TYPE__WSDL = eINSTANCE.getWsdlReferencesType_Wsdl();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlTypeImpl <em>Wsdl Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.WsdlTypeImpl
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getWsdlType()
		 * @generated
		 */
		EClass WSDL_TYPE = eINSTANCE.getWsdlType();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WSDL_TYPE__LOCATION = eINSTANCE.getWsdlType_Location();

		/**
		 * The meta object literal for the '<em><b>Namespace</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WSDL_TYPE__NAMESPACE = eINSTANCE.getWsdlType_Namespace();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType <em>Disposition Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDispositionType()
		 * @generated
		 */
		EEnum DISPOSITION_TYPE = eINSTANCE.getDispositionType();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType <em>My Role Binding Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleBindingType()
		 * @generated
		 */
		EEnum MY_ROLE_BINDING_TYPE = eINSTANCE.getMyRoleBindingType();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType <em>Partner Role Endpoint Reference Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleEndpointReferenceType()
		 * @generated
		 */
		EEnum PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE = eINSTANCE.getPartnerRoleEndpointReferenceType();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType <em>Persistence Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPersistenceType()
		 * @generated
		 */
		EEnum PERSISTENCE_TYPE = eINSTANCE.getPersistenceType();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag <em>Suspend Flag</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getSuspendFlag()
		 * @generated
		 */
		EEnum SUSPEND_FLAG = eINSTANCE.getSuspendFlag();

		/**
		 * The meta object literal for the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType <em>Transaction Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getTransactionType()
		 * @generated
		 */
		EEnum TRANSACTION_TYPE = eINSTANCE.getTransactionType();

		/**
		 * The meta object literal for the '<em>Custom Invoker Uri Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getCustomInvokerUriType()
		 * @generated
		 */
		EDataType CUSTOM_INVOKER_URI_TYPE = eINSTANCE.getCustomInvokerUriType();

		/**
		 * The meta object literal for the '<em>Disposition Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DispositionType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getDispositionTypeObject()
		 * @generated
		 */
		EDataType DISPOSITION_TYPE_OBJECT = eINSTANCE.getDispositionTypeObject();

		/**
		 * The meta object literal for the '<em>Invoke Handler Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.String
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getInvokeHandlerType()
		 * @generated
		 */
		EDataType INVOKE_HANDLER_TYPE = eINSTANCE.getInvokeHandlerType();

		/**
		 * The meta object literal for the '<em>My Role Binding Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleBindingType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getMyRoleBindingTypeObject()
		 * @generated
		 */
		EDataType MY_ROLE_BINDING_TYPE_OBJECT = eINSTANCE.getMyRoleBindingTypeObject();

		/**
		 * The meta object literal for the '<em>Partner Role Endpoint Reference Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPartnerRoleEndpointReferenceTypeObject()
		 * @generated
		 */
		EDataType PARTNER_ROLE_ENDPOINT_REFERENCE_TYPE_OBJECT = eINSTANCE.getPartnerRoleEndpointReferenceTypeObject();

		/**
		 * The meta object literal for the '<em>Persistence Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getPersistenceTypeObject()
		 * @generated
		 */
		EDataType PERSISTENCE_TYPE_OBJECT = eINSTANCE.getPersistenceTypeObject();

		/**
		 * The meta object literal for the '<em>Suspend Flag Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getSuspendFlagObject()
		 * @generated
		 */
		EDataType SUSPEND_FLAG_OBJECT = eINSTANCE.getSuspendFlagObject();

		/**
		 * The meta object literal for the '<em>Transaction Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getTransactionTypeObject()
		 * @generated
		 */
		EDataType TRANSACTION_TYPE_OBJECT = eINSTANCE.getTransactionTypeObject();

		/**
		 * The meta object literal for the '<em>Version Attribute Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionAttributeType()
		 * @generated
		 */
		EDataType VERSION_ATTRIBUTE_TYPE = eINSTANCE.getVersionAttributeType();

		/**
		 * The meta object literal for the '<em>Version Attribute Type Object</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Float
		 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.PddPackageImpl#getVersionAttributeTypeObject()
		 * @generated
		 */
		EDataType VERSION_ATTRIBUTE_TYPE_OBJECT = eINSTANCE.getVersionAttributeTypeObject();

	}

} //PddPackage
