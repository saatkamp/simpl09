/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;

import org.eclipse.bpel.model.Import;
import org.eclipse.bpel.model.Process;
import org.eclipse.bpel.runtimes.module.BPELModuleArtifact;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.jem.util.logger.proxy.Logger;
import org.eclipse.wst.server.core.IModuleArtifact;

import uk.ac.ucl.sse.omii.bpel.abr.generation.util.AssignBpel2ToBpel1Converter;
import uk.ac.ucl.sse.omii.bpel.abr.generation.util.Bpel2ToBpel1Converter;
import uk.ac.ucl.sse.omii.bpel.abr.generation.util.CaseBpel2ToBpel1Converter;
import uk.ac.ucl.sse.omii.bpel.abr.generation.util.IBPELConverter;
import uk.ac.ucl.sse.omii.bpel.abr.generation.util.NSBpel2ToBpel1Converter;
import uk.ac.ucl.sse.omii.bpel.abr.generation.util.PlnkRoleBpel2ToBpel1Converter;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IBprConstants;

/**
 * Responsible for generating a BPR archive file containing all required files
 * required for deployment of a BPEL process onto a ActiveBPEL runtime.
 * 
 * @author Bruno Wassermann, written Sep 11, 2006
 */
public class BprGenerator {

	private final static int BUFFER = 2048;

	protected String host = "localhost";

	protected int httpPort = 8080;

	public BprGenerator(String host, int httpPort) {
		if (host != null && !("".equals(host))) {
			this.host = host;
		}
		this.httpPort = httpPort;
	}

	/*
	 * TODO the generators should probably be abstract base classes just
	 * defining the generatePdd/generateBpr method; need to refactor these
	 * classes
	 */

	/**
	 * Generates BPR given an <code>IModuleArtifact</code>.
	 * 
	 * @param moduleArtifact
	 *            <code>IModuleArtifact</code>
	 * @return <code>File</code> containing a handle to the deployment archive
	 *         for the corresponding BPEL process or <code>null</code>, if
	 *         moduleArtifact or BPEL file is not valid
	 *         <p>
	 *         This method checks whether the <code>IModuleArtifact</code> is
	 *         in fact a <code>BPELModuleArtifact</code> that contains a
	 *         corresponding BPEL file. Without these requirements met, it is
	 *         not possible to generate a correct BPR archive and the method
	 *         will therefore return null
	 */
	public File generateBpr(final IModuleArtifact moduleArtifact) 
		throws IllegalArgumentException 
	{
		if (!(moduleArtifact instanceof BPELModuleArtifact)) {
			throw new IllegalArgumentException("BprGenerator::" +
					"moduleArtifact must be instance of BPELModuleArtifact");
		}
		
		if (isNullBPELProcess(moduleArtifact)) return null;
		
		Process bpelProcess = DeploymentDataProvider.getProcess(moduleArtifact);
		
		final IProject moduleProject = 
			((BPELModuleArtifact) moduleArtifact).getModule().getProject();
		
		if (moduleProject == null) {
			// TODO this prevents us from generating BPR; do some logging and
			// inform user of problem
			return null;
		}
		/*
		 * TODO remove this fix once we consider wsdl:service elements This is a
		 * dirty, dirty quick fix for the cancergrid wflow demo at AHM 2006.
		 */
// if ("easyjob".equals(bpelProcess.getName())) {
// // TODO read pre-prepared cancergrid.bpr and write it out to the
// // project
// try {
// File demoBprFile = new File("easyjob.bpr");
// File manualBprFile = new File(
// moduleProject.getLocationURI().toString().replaceFirst("file:/","") +
// File.separatorChar + "easyjob.bpr");
// FileInputStream cin = new FileInputStream(demoBprFile);
// FileOutputStream cout = new FileOutputStream(manualBprFile);
// byte data[] = new byte[BUFFER];
// int count = 0;
//				
// while((count = cin.read(data, 0, BUFFER)) != -1) {
// cout.write(data, 0, count);
// }
// cin.close();
// cout.close();
// return manualBprFile;
// } catch (FileNotFoundException e) {
// Logger.getLogger().logError(e);
// } catch (IOException e) {
// Logger.getLogger().logError(e);
// }
// }
		/* end of AHM 2006 fix */
		
		/*
		 * TODO this is ugly stuff. think about creating IFile in project, 
		 * create a bpr file in some tmp dir, input stream this to the IFile
		 * and delete the tmp bpr file.
		 */
		
		File bprFile = new File(
				moduleProject.getLocationURI().toString().replaceFirst("file:/", "/").replaceFirst("[a-zA-Z]{0,1}:{0,1}", "") + 
				File.separatorChar + 
				bpelProcess.getName() + 
				IBprConstants.DOT_BPR_EXTENSION);
		
		try {
			FileOutputStream dest = new FileOutputStream(bprFile);
			JarOutputStream jarOut = new JarOutputStream(new BufferedOutputStream(dest));
			jarOut.setMethod(JarOutputStream.DEFLATED);
			
			archiveBpelFile(moduleArtifact, jarOut);
			List wsdlEntryNames = archiveLocalWsdlFiles(moduleArtifact, jarOut);
			archivePddFile(moduleArtifact, jarOut);
			
			if (wsdlEntryNames != null) {
				if (0 != wsdlEntryNames.size()) {
					
					// only generate and archive wsdlCatalog, if there are wsdl
					// entries
					archiveWsdlCatalogFile(moduleArtifact, jarOut, wsdlEntryNames);
				}
			}
			jarOut.closeEntry();
			jarOut.flush();
			jarOut.close();
			dest.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			// TODO add logging and user notifcation
		} catch (IOException e) {
			e.printStackTrace();
			// TODO add logging and user notifcation
		} catch (CoreException e) {
			e.printStackTrace();
			// TODO add logging and user notifcation
		}
		
		return bprFile;
	}

	private void archiveBpelFile(final IModuleArtifact moduleArtifact,
			final JarOutputStream jarOut) throws IOException, CoreException 
	{
		Process bpelProcess = DeploymentDataProvider.getProcess(moduleArtifact);
		IFile bpelFile = DeploymentDataProvider.getBPELFile(moduleArtifact);

		// TODO once we have engines supporting BPEL 2.0, remove this stuff
		// conversion from BPEL 2.0 to BPEL 1.1
		Bpel2ToBpel1Converter bpelConverter = new Bpel2ToBpel1Converter(
				bpelFile.getLocationURI().toString().replaceFirst("file:/", "/").replaceFirst("[a-zA-Z]{0,1}:{0,1}", ""),
				bpelFile.getName()); // stores in default location
		IBPELConverter assignConverter = new AssignBpel2ToBpel1Converter();
		bpelConverter.registerConverter(assignConverter);
		IBPELConverter caseConverter = new CaseBpel2ToBpel1Converter();
		bpelConverter.registerConverter(caseConverter);
		IBPELConverter nsConverter = new NSBpel2ToBpel1Converter();
		bpelConverter.registerConverter(nsConverter);
		bpelConverter.convertBpel2ToBpel1();
		// end conversion

		JarEntry entry = new JarEntry(IBprConstants.BPEL_DIR
				+ bpelFile.getName());
		jarOut.putNextEntry(entry);

		/*
		 * TODO once we got rid of need for conversion, uncomment the line below
		 * and remove the line after that
		 */
		// FileInputStream fis = new
		// FileInputStream(bpelFile.getLocationURI().toString().replaceFirst("file:/",
		// ""));
		FileInputStream fis = new FileInputStream(bpelFile.getName()); // read
																		// conversion
		byte data[] = new byte[BUFFER];
		int count = 0;

		while ((count = fis.read(data, 0, BUFFER)) != -1) {
			jarOut.write(data, 0, count);
		}
		fis.close();
		File bpelConversionFile = new File(bpelFile.getName());
		bpelConversionFile.delete();
	}

	private List archiveLocalWsdlFiles(final IModuleArtifact moduleArtifact,
			final JarOutputStream jarOut) throws IOException, CoreException {
		List wsdlEntryNames = new ArrayList();
		IFile bpelFile = DeploymentDataProvider.getBPELFile(moduleArtifact);
		EList localImports = DeploymentDataProvider
				.getLocalWsdlImports(moduleArtifact);

		for (Iterator iter = localImports.iterator(); iter.hasNext();) {
			Import wsdlImport = (Import) iter.next();
			String importPath = getAbosluteImportPath(wsdlImport, bpelFile);

			if (importPath == null) {
				// TODO figure out how to react to this, if at all
				continue;
			}

			// TODO once we don't have to worry about supporting plnk ns and
			// and plnk role as used in WSDL for BPEL 1.1, remove the below
			// conversion from BPEL 2.0 to BPEL 1.1
			Bpel2ToBpel1Converter wsdlConverter = new Bpel2ToBpel1Converter(
					importPath, extractFileName(wsdlImport.getLocation())); // stores
																			// in
																			// default
																			// location
			IBPELConverter nsConverter = new NSBpel2ToBpel1Converter();
			wsdlConverter.registerConverter(nsConverter);
			IBPELConverter plnkRoleConverter = new PlnkRoleBpel2ToBpel1Converter();
			wsdlConverter.registerConverter(plnkRoleConverter);
			wsdlConverter.convertBpel2ToBpel1();
			// end conversion

			JarEntry entry = new JarEntry(IBprConstants.WSDL_DIR
					+ extractFileName(wsdlImport.getLocation()));
			wsdlEntryNames.add(IBprConstants.WSDL_DIR
					+ extractFileName(wsdlImport.getLocation()));
			jarOut.putNextEntry(entry);

			/*
			 * TODO once we got rid of need for conversion, uncomment the line
			 * below and remove the line after that
			 */
			FileInputStream fis = new FileInputStream(
					extractFileName(wsdlImport.getLocation())); // read
																// conversion
			// FileInputStream fis = new FileInputStream(new File(importPath));
			byte data[] = new byte[BUFFER];
			int count = 0;

			while ((count = fis.read(data, 0, BUFFER)) != -1) {
				jarOut.write(data, 0, count);
			}
			fis.close();
			File wsdlConversionFile = new File(extractFileName(wsdlImport
					.getLocation()));
			wsdlConversionFile.delete();
		}
		return wsdlEntryNames;
	}

	private void archivePddFile(final IModuleArtifact moduleArtifact,
			final JarOutputStream jarOut) throws IOException, CoreException {
		PddGenerator pddGenerator = new PddGenerator(host, httpPort);
		DocumentRoot docRoot = pddGenerator
				.generatePDD((BPELModuleArtifact) moduleArtifact);
		IFile bpelFile = DeploymentDataProvider.getBPELFile(moduleArtifact);
		PddWriter pddWriter = new PddWriter();
		File pddFile = pddWriter.write(docRoot, bpelFile.getName().replaceAll(
				IBprConstants.DOT_BPEL_EXTENSION, ""));

		JarEntry entry = new JarEntry(IBprConstants.META_INF_DIR
				+ IBprConstants.PDD_DIR + pddFile.getName());
		jarOut.putNextEntry(entry);
		FileInputStream fis = new FileInputStream(pddFile);
		byte data[] = new byte[BUFFER];
		int count = 0;

		while ((count = fis.read(data, 0, BUFFER)) != -1) {
			jarOut.write(data, 0, count);
		}
		fis.close();
		pddFile.delete();
	}

	private void archiveWsdlCatalogFile(final IModuleArtifact moduleArtifact,
			final JarOutputStream jarOut, final List wsdlEntryNames)
			throws IOException, CoreException {
		WsdlCatalogWriter wsdlCatWriter = new WsdlCatalogWriter();
		wsdlCatWriter.write(wsdlEntryNames); // should have created
												// wsdlCatalog.xml at def loc
		File wsdlCatalogFile = new File(IBprConstants.WSDL_CATALOG_FILE);

		JarEntry entry = new JarEntry(IBprConstants.META_INF_DIR
				+ wsdlCatalogFile.getName());
		jarOut.putNextEntry(entry);
		FileInputStream fis = new FileInputStream(wsdlCatalogFile);
		byte data[] = new byte[BUFFER];
		int count = 0;

		while ((count = fis.read(data, 0, BUFFER)) != -1) {
			jarOut.write(data, 0, count);
		}
		fis.close();
		wsdlCatalogFile.delete();
	}

	/*
	 * TODO use the code below to create an IFile representation of the BPR in
	 * the Eclipse BPEL project!!! not necessarily used by this class but, maybe
	 * rather the client of this class
	 *  // IFile bprFile = // moduleProject.getFile(new Path(processName +
	 * IBprConstants.DOT_BPR_EXTENSION)); // // try { // InputStream in = new
	 * FileInputStream(bpr); // bprFile.create(in, true, null); // } catch
	 * (FileNotFoundException e) { // e.printStackTrace(); // } catch
	 * (CoreException e) { // e.printStackTrace(); // }
	 */

	//
	//		
	// /*
	// * TODO use the code below to create an IFile representation of the
	// * BPR in the Eclipse BPEL project!!!
	// */
	// // IFile bprFile =
	// // moduleProject.getFile(new Path(processName +
	// IBprConstants.DOT_BPR_EXTENSION));
	// //
	// // try {
	// // InputStream in = new FileInputStream(bpr);
	// // bprFile.create(in, true, null);
	// // } catch (FileNotFoundException e) {
	// // e.printStackTrace();
	// // } catch (CoreException e) {
	// // e.printStackTrace();
	// // }

	/*
	 * Returns whether the given <code>IModuleArtifact</code> refers to a
	 * <code>BPELModuleArtifact</code> and whether there is a corresponding
	 * bpel file.
	 * 
	 * @return true, if can obtain BPEL process from given artifact, otherwise
	 * return null
	 */
	private boolean isNullBPELProcess(final IModuleArtifact moduleArtifact) {
		return DeploymentDataProvider.getProcess(moduleArtifact) == null;
	}

	/*
	 * Tries to get an absolute file path to a WSDL file by looking at its
	 * import location attribute value in BPEL file importing it. What nasty
	 * code :(
	 */
	private String getAbosluteImportPath(final Import wsdlImport,
			final IFile bpelFile) {
		// get absolute path to project containing our bpel file
		String tmp = bpelFile.getLocationURI().toString().replaceFirst("file:/", "/").replaceFirst("[a-zA-Z]{0,1}:{0,1}", "");
		String prjAbsPath = tmp.substring(0, tmp.lastIndexOf('/'));

		// count the number of occurences of ../ in the wsdl import value
		String impLocation = wsdlImport.getLocation();

		int sum = 0;
		int searchIndex = 0;

		while ((searchIndex = impLocation.indexOf("../", searchIndex)) != -1) {
			sum++;
			searchIndex++;
		}
		String higherLevelDirPath = null;

		// create absolute import path
		if (sum == 0) {
			higherLevelDirPath = prjAbsPath;
			String result = higherLevelDirPath + "/" + impLocation;
			return result;
		} else if (sum != 0) {
			File prjDir = new File(prjAbsPath);
			File higherLevelDir = null;
			for (int i = 0; i < sum; i++) {
				higherLevelDir = new File(prjDir.getParent());
			}
			if (higherLevelDir == null) {
				prjDir.delete();
				higherLevelDir.delete();
				return null;
			} else {
				higherLevelDirPath = higherLevelDir.getAbsolutePath();
				String modifiedImpLocation = impLocation.substring(impLocation
						.lastIndexOf("../") + 3, impLocation.length());
				String result = higherLevelDirPath + "/" + modifiedImpLocation;
				prjDir.delete();
				higherLevelDir.delete();
				return result;
			}
		}
		return null;
	}

	/*
	 * Given any <code>String</code> ending in a wsdl file, removes all
	 * elements preceeding the file name and returns only the file name plus
	 * extension.
	 */
	private String extractFileName(String filePath) {
		if (filePath == null || "".equals(filePath))
			return null;

		String[] split = filePath.split("/");

		return split[split.length - 1];
	}

	// /**
	// * Given any <code>String</code> representing a file path to a BPEL file,
	// * removes the file extension and replaces it by .pdd extension.
	// *
	// * Very brittle, but have no time to base on better assumptions.
	// *
	// * PUBLIC FOR TESTING PURPOSES ONLY!!!
	// */
	// public String convertPathToPDDFilePath(String filePath) {
	// if (filePath == null || "".equals(filePath)) return null;
	// if (!(filePath).endsWith(IBprConstants.DOT_BPEL_EXTENSION)) return null;
	//		
	// if (filePath.endsWith(IBprConstants.DOT_BPEL_EXTENSION)) {
	// System.out.println("Returned pdd file path: " + filePath.substring(0,
	// filePath.lastIndexOf(IBprConstants.DOT_BPEL_EXTENSION)).concat(IPddConstants.DOT_PDD_EXTENSION));
	// return filePath.substring(0,
	// filePath.lastIndexOf(IBprConstants.DOT_BPEL_EXTENSION)).concat(IPddConstants.DOT_PDD_EXTENSION);
	// }
	// return null;
	// }

}
