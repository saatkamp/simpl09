/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.FeatureMap;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Partner Role Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getAny <em>Any</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getCustomInvokerUri <em>Custom Invoker Uri</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference <em>Endpoint Reference</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getInvokeHandler <em>Invoke Handler</em>}</li>
 * </ul>
 * </p>
 *
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleType()
 * @model extendedMetaData="name='partnerRoleType' kind='elementOnly'"
 * @generated
 */
public interface PartnerRoleType extends EObject {
	/**
	 * Returns the value of the '<em><b>Any</b></em>' attribute list.
	 * The list contents are of type {@link org.eclipse.emf.ecore.util.FeatureMap.Entry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Any</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Any</em>' attribute list.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleType_Any()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.EFeatureMapEntry" many="true"
	 *        extendedMetaData="kind='elementWildcard' wildcards='##any' name=':0' processing='skip'"
	 * @generated
	 */
	FeatureMap getAny();

	/**
	 * Returns the value of the '<em><b>Custom Invoker Uri</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Custom Invoker Uri</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Custom Invoker Uri</em>' attribute.
	 * @see #setCustomInvokerUri(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleType_CustomInvokerUri()
	 * @model unique="false" dataType="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.CustomInvokerUriType"
	 *        extendedMetaData="kind='attribute' name='customInvokerUri'"
	 * @generated
	 */
	String getCustomInvokerUri();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getCustomInvokerUri <em>Custom Invoker Uri</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Custom Invoker Uri</em>' attribute.
	 * @see #getCustomInvokerUri()
	 * @generated
	 */
	void setCustomInvokerUri(String value);

	/**
	 * Returns the value of the '<em><b>Endpoint Reference</b></em>' attribute.
	 * The default value is <code>"static"</code>.
	 * The literals are from the enumeration {@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Endpoint Reference</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Endpoint Reference</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @see #isSetEndpointReference()
	 * @see #unsetEndpointReference()
	 * @see #setEndpointReference(PartnerRoleEndpointReferenceType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleType_EndpointReference()
	 * @model default="static" unique="false" unsettable="true" required="true"
	 *        extendedMetaData="kind='attribute' name='endpointReference'"
	 * @generated
	 */
	PartnerRoleEndpointReferenceType getEndpointReference();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference <em>Endpoint Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Endpoint Reference</em>' attribute.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleEndpointReferenceType
	 * @see #isSetEndpointReference()
	 * @see #unsetEndpointReference()
	 * @see #getEndpointReference()
	 * @generated
	 */
	void setEndpointReference(PartnerRoleEndpointReferenceType value);

	/**
	 * Unsets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference <em>Endpoint Reference</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isSetEndpointReference()
	 * @see #getEndpointReference()
	 * @see #setEndpointReference(PartnerRoleEndpointReferenceType)
	 * @generated
	 */
	void unsetEndpointReference();

	/**
	 * Returns whether the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getEndpointReference <em>Endpoint Reference</em>}' attribute is set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return whether the value of the '<em>Endpoint Reference</em>' attribute is set.
	 * @see #unsetEndpointReference()
	 * @see #getEndpointReference()
	 * @see #setEndpointReference(PartnerRoleEndpointReferenceType)
	 * @generated
	 */
	boolean isSetEndpointReference();

	/**
	 * Returns the value of the '<em><b>Invoke Handler</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Invoke Handler</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Invoke Handler</em>' attribute.
	 * @see #setInvokeHandler(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerRoleType_InvokeHandler()
	 * @model unique="false" dataType="uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.InvokeHandlerType"
	 *        extendedMetaData="kind='attribute' name='invokeHandler'"
	 * @generated
	 */
	String getInvokeHandler();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType#getInvokeHandler <em>Invoke Handler</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Invoke Handler</em>' attribute.
	 * @see #getInvokeHandler()
	 * @generated
	 */
	void setInvokeHandler(String value);

} // PartnerRoleType