/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class NSBpel2ToBpel1Converter implements IBPELConverter{
	
	public static final String BPWS_BPEL_20 = "http://schemas.xmlsoap.org/ws/2004/03/business-process/";
	public static final String BPWS_BPEL_11 = "http://schemas.xmlsoap.org/ws/2003/03/business-process/";
	public static final String PLNK_BPEL_11 = "http://schemas.xmlsoap.org/ws/2003/05/partner-link/";

	public NSBpel2ToBpel1Converter() {}
	
	public void convertBpel(Document dom){
		Element root = dom.getDocumentElement();
		convertNamespaceBPWS(root);
		convertNamespacePLNK(root);
	}
	
	private void convertNamespaceBPWS(Element root){
		Attr bpwsAttr = root.getAttributeNode("xmlns:bpws");
		Attr defAttr = root.getAttributeNode("xmlns");
		
		if (bpwsAttr != null) {
			 if (BPWS_BPEL_20.equals(bpwsAttr.getValue())) {
				 bpwsAttr.setValue(BPWS_BPEL_11);
			 }
		}
		else if (defAttr != null) {
			if (BPWS_BPEL_20.equals(defAttr.getValue())) {
				defAttr.setValue(BPWS_BPEL_11);
			}
		}
	}
	
	// TODO should search for occurrence of ns not assume prefix
	private void convertNamespacePLNK(Element root){
		Attr attr = root.getAttributeNode("xmlns:plnk");
		if (attr != null) attr.setValue(PLNK_BPEL_11);
	}

}
