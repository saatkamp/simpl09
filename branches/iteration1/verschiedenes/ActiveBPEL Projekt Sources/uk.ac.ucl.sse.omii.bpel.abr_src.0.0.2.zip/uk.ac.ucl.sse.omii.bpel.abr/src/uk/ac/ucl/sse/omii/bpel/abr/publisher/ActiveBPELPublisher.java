/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.publisher;

import java.io.File;

import org.eclipse.bpel.runtimes.module.BPELModuleArtifact;
import org.eclipse.bpel.runtimes.publishers.GenericBPELPublisher;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.jem.util.logger.proxy.Logger;
import org.eclipse.wst.server.core.IModule;
import org.eclipse.wst.server.core.IModuleArtifact;

import uk.ac.ucl.sse.omii.bpel.abr.ActiveBPELRuntimePlugin;
import uk.ac.ucl.sse.omii.bpel.abr.generation.BprGenerator;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IPddConstants;


/**
 * Publishes BPEL processes on ActiveBPEL engine.
 * <p>
 * Transforms modules to be published into depoyable format (BPR) and 
 * responsible for coordinating the deployment including analysis of BPEL process
 * data, generation of descriptors, engine-specific validation, etc.  
 *
 * @author Bruno Wassermann, written Jun 8, 2006
 */
public class ActiveBPELPublisher extends GenericBPELPublisher {

	/*
	 * @see <code>GenericPublisher{@link #unpublish(IProgressMonitor)}</code> 
	 */
	public IStatus[] unpublish(IProgressMonitor monitor) {
		return null;
	}

	/*
	 * @see <code>GenericPublisher{@link #publish(IModuleArtifact[], IProgressMonitor)}</code>
	 */
	public IStatus[] publish(IModuleArtifact[] resources, IProgressMonitor monitor) {
		// resources will always be null for some weird reason :(
		// therefore we generate a BPELModuleArtifact
		// the module id value enables us to get BPEL file path relative to its project
		IModule[] modules = super.getModule();
		resources = new IModuleArtifact[modules.length];
		for (int i=0; i<modules.length; i++) {
			IModule module = modules[i];
			String moduleId = module.getId();
			String bpelFileRelativePathString = moduleId.split(">>")[1];			
			IPath path = new Path(bpelFileRelativePathString);
			IFile bpelFile = module.getProject().getFile(path);
			BPELModuleArtifact moduleArtifact = new BPELModuleArtifact(module, bpelFile);
			resources[i] = moduleArtifact;
		}
		
		IStatus[] result = new Status[1];
		
		// TODO maybe check that validation status of resource in editor is okay
		// before attempting to publish
		
		try {
			for (int i=0; i<resources.length; i++) {
				BprGenerator bprGen = new BprGenerator(
						super.getHost(), 
						super.getHttpPort());
				File bprFile = bprGen.generateBpr(resources[i]);				
			}
		} catch (IllegalArgumentException e) {
			/*
			 * TODO Any problem that was encountered during the generation of
			 * PDD or BPR needs to be propagated up here so that we can wrap
			 * information about problem up in an IStatus here.
			 * Problems that could occur are either exceptions thrown or cases
			 * where the generation code currently just returns null. You must 
			 * revisit all classes involved in generation and consider what 
			 * information should be provided (via exceptions) in which cases.
			 */
			
			/*
			 * TODO devise some status codes in teh plug-in to use as the third
			 * argument in Status constructor (here, 0 indicates problem, 1 
			 * success) and some messages (ActiveBPELPublisherMessages) for use 
			 * as fourth argument.
			 */
			IStatus status = new Status(
					IStatus.ERROR, 
					ActiveBPELRuntimePlugin.PLUGIN_ID, 
					0, 
					"Error during deployment: " + e.getMessage(), 
					e);
			result[0] = status;
			// TODO need to do some logging here!
			Logger.getLogger().logError(e);
			return result;
			
		} catch (Exception e) {
			Logger.getLogger().logError(e);
		}
		result[0] = new Status(
				IStatus.OK, 
				ActiveBPELRuntimePlugin.PLUGIN_ID, 
				1, 
				"Deployment successful", 
				null);
		return result;

		// TODO actually publish bprFile to server ia servlet (develop servlet:)
		// TODO drive validation and provide feedback to user
		// TODO create and return Status
	} 

}
