/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Disposition Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getDispositionType()
 * @model
 * @generated
 */
public final class DispositionType extends AbstractEnumerator {
	/**
	 * The '<em><b>Terminate</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Terminate</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TERMINATE_LITERAL
	 * @model name="terminate"
	 * @generated
	 * @ordered
	 */
	public static final int TERMINATE = 0;

	/**
	 * The '<em><b>Maintain</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Maintain</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MAINTAIN_LITERAL
	 * @model name="maintain"
	 * @generated
	 * @ordered
	 */
	public static final int MAINTAIN = 1;

	/**
	 * The '<em><b>Migrate</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Migrate</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MIGRATE_LITERAL
	 * @model name="migrate"
	 * @generated
	 * @ordered
	 */
	public static final int MIGRATE = 2;

	/**
	 * The '<em><b>Terminate</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TERMINATE
	 * @generated
	 * @ordered
	 */
	public static final DispositionType TERMINATE_LITERAL = new DispositionType(TERMINATE, "terminate", "terminate");

	/**
	 * The '<em><b>Maintain</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MAINTAIN
	 * @generated
	 * @ordered
	 */
	public static final DispositionType MAINTAIN_LITERAL = new DispositionType(MAINTAIN, "maintain", "maintain");

	/**
	 * The '<em><b>Migrate</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MIGRATE
	 * @generated
	 * @ordered
	 */
	public static final DispositionType MIGRATE_LITERAL = new DispositionType(MIGRATE, "migrate", "migrate");

	/**
	 * An array of all the '<em><b>Disposition Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final DispositionType[] VALUES_ARRAY =
		new DispositionType[] {
			TERMINATE_LITERAL,
			MAINTAIN_LITERAL,
			MIGRATE_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Disposition Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Disposition Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DispositionType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DispositionType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Disposition Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DispositionType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			DispositionType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Disposition Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DispositionType get(int value) {
		switch (value) {
			case TERMINATE: return TERMINATE_LITERAL;
			case MAINTAIN: return MAINTAIN_LITERAL;
			case MIGRATE: return MIGRATE_LITERAL;
		}
		return null;	
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private DispositionType(int value, String name, String literal) {
		super(value, name, literal);
	}

} //DispositionType
