/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage
 * @generated
 */
public class PddAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PddPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PddAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PddPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch the delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PddSwitch modelSwitch =
		new PddSwitch() {
			public Object caseDocumentRoot(DocumentRoot object) {
				return createDocumentRootAdapter();
			}
			public Object caseIndexedPropertiesType(IndexedPropertiesType object) {
				return createIndexedPropertiesTypeAdapter();
			}
			public Object caseIndexedPropertyType(IndexedPropertyType object) {
				return createIndexedPropertyTypeAdapter();
			}
			public Object caseMyRoleType(MyRoleType object) {
				return createMyRoleTypeAdapter();
			}
			public Object casePartnerLinksType(PartnerLinksType object) {
				return createPartnerLinksTypeAdapter();
			}
			public Object casePartnerLinkType(PartnerLinkType object) {
				return createPartnerLinkTypeAdapter();
			}
			public Object casePartnerRoleType(PartnerRoleType object) {
				return createPartnerRoleTypeAdapter();
			}
			public Object caseProcessType(ProcessType object) {
				return createProcessTypeAdapter();
			}
			public Object caseVariableType(VariableType object) {
				return createVariableTypeAdapter();
			}
			public Object caseVariableType1(VariableType1 object) {
				return createVariableType1Adapter();
			}
			public Object caseVersionType(VersionType object) {
				return createVersionTypeAdapter();
			}
			public Object caseWsdlReferencesType(WsdlReferencesType object) {
				return createWsdlReferencesTypeAdapter();
			}
			public Object caseWsdlType(WsdlType object) {
				return createWsdlTypeAdapter();
			}
			public Object defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	public Adapter createAdapter(Notifier target) {
		return (Adapter)modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot <em>Document Root</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.DocumentRoot
	 * @generated
	 */
	public Adapter createDocumentRootAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType <em>Indexed Properties Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType
	 * @generated
	 */
	public Adapter createIndexedPropertiesTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType <em>Indexed Property Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertyType
	 * @generated
	 */
	public Adapter createIndexedPropertyTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType <em>My Role Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.MyRoleType
	 * @generated
	 */
	public Adapter createMyRoleTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType <em>Partner Links Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType
	 * @generated
	 */
	public Adapter createPartnerLinksTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType <em>Partner Link Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType
	 * @generated
	 */
	public Adapter createPartnerLinkTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType <em>Partner Role Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerRoleType
	 * @generated
	 */
	public Adapter createPartnerRoleTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType <em>Process Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType
	 * @generated
	 */
	public Adapter createProcessTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType <em>Variable Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType
	 * @generated
	 */
	public Adapter createVariableTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1 <em>Variable Type1</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VariableType1
	 * @generated
	 */
	public Adapter createVariableType1Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType <em>Version Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType
	 * @generated
	 */
	public Adapter createVersionTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType <em>Wsdl References Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType
	 * @generated
	 */
	public Adapter createWsdlReferencesTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType <em>Wsdl Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlType
	 * @generated
	 */
	public Adapter createWsdlTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PddAdapterFactory
