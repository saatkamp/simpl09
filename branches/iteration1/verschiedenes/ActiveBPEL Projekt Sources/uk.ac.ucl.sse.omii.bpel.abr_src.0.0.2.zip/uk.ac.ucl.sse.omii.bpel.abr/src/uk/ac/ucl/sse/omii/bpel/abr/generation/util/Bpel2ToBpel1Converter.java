/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.generation.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class Bpel2ToBpel1Converter {
	
	/*
	 * TODO need to make sure that a particular converter cannot be used
	 * on a wrong file type (i.e. apply plnk role converter on BPEL file).
	 */
	
	private static String srcFilePath;
	private static String destFilePath;
	
	private List bpelConverters = new ArrayList();
	
	public Bpel2ToBpel1Converter(String srcFilePath, String destFilePath) {
		if ((srcFilePath == null) || (destFilePath == null)) {
			throw new IllegalArgumentException("srcFilePath and destFilePath must not be null");
		}
		if (("".equals(srcFilePath)) || ("".equals(destFilePath))) {
			throw new IllegalArgumentException("srcFilePath and destFilePath must not be empty string");
		}
		this.srcFilePath = srcFilePath;
		this.destFilePath = destFilePath;
	}
		
	/**
	 * Register an <code>IBPELConverter</code> to carry out a particular
	 * conversion. Assumes that converters for the various parts needed
	 * to convert a BPEL 2.0 source to a BPEL 1.1 source are registered.
	 */
	public void registerConverter(IBPELConverter supporter){
		bpelConverters.add(supporter);
	}

	/**
	 * Carry out the conversion and write to indicated destination file.
	 * 
	 * @param dom
	 */
	public void convertBpel2ToBpel1() {
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document dom = db.parse(srcFilePath);
			
			for (int i=0; i<bpelConverters.size(); i++){
				((IBPELConverter) bpelConverters.get(i)).convertBpel(dom);
			}
			TransformerFactory tff = TransformerFactory.newInstance();
			DOMSource ds = new DOMSource(dom);
			StreamResult sr = new StreamResult(new File(destFilePath));

			Transformer t = tff.newTransformer();
			t.transform(ds, sr);
			
			// TODO add logging to catch statements
			
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (FactoryConfigurationError e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}	
	}
}
