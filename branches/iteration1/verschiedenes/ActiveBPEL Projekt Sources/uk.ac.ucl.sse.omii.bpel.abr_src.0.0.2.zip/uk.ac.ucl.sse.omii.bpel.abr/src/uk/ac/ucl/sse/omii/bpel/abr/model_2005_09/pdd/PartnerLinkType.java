/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Partner Link Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getPartnerRole <em>Partner Role</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getMyRole <em>My Role</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerLinkType()
 * @model extendedMetaData="name='partnerLinkType' kind='elementOnly'"
 * @generated
 */
public interface PartnerLinkType extends EObject {
	/**
	 * Returns the value of the '<em><b>Partner Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Partner Role</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Partner Role</em>' containment reference.
	 * @see #setPartnerRole(PartnerRoleType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerLinkType_PartnerRole()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='partnerRole' namespace='##targetNamespace'"
	 * @generated
	 */
	PartnerRoleType getPartnerRole();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getPartnerRole <em>Partner Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Partner Role</em>' containment reference.
	 * @see #getPartnerRole()
	 * @generated
	 */
	void setPartnerRole(PartnerRoleType value);

	/**
	 * Returns the value of the '<em><b>My Role</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>My Role</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>My Role</em>' containment reference.
	 * @see #setMyRole(MyRoleType)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerLinkType_MyRole()
	 * @model containment="true"
	 *        extendedMetaData="kind='element' name='myRole' namespace='##targetNamespace'"
	 * @generated
	 */
	MyRoleType getMyRole();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getMyRole <em>My Role</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>My Role</em>' containment reference.
	 * @see #getMyRole()
	 * @generated
	 */
	void setMyRole(MyRoleType value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage#getPartnerLinkType_Name()
	 * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
	 *        extendedMetaData="kind='attribute' name='name'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinkType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // PartnerLinkType