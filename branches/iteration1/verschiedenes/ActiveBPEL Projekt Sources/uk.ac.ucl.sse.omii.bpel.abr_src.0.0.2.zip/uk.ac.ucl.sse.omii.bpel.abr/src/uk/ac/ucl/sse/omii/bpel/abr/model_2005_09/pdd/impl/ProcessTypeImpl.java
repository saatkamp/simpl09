/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.IndexedPropertiesType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PartnerLinksType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PddPackage;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.PersistenceType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.ProcessType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.SuspendFlag;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.TransactionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.VersionType;
import uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.WsdlReferencesType;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Process Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getVersion <em>Version</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getPartnerLinks <em>Partner Links</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getIndexedProperties <em>Indexed Properties</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getWsdlReferences <em>Wsdl References</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getPersistenceType <em>Persistence Type</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getSuspendProcessOnUncaughtFault <em>Suspend Process On Uncaught Fault</em>}</li>
 *   <li>{@link uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd.impl.ProcessTypeImpl#getTransactionType <em>Transaction Type</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ProcessTypeImpl extends EObjectImpl implements ProcessType {
	/**
	 * The cached value of the '{@link #getVersion() <em>Version</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVersion()
	 * @generated
	 * @ordered
	 */
	protected VersionType version = null;

	/**
	 * The cached value of the '{@link #getPartnerLinks() <em>Partner Links</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartnerLinks()
	 * @generated
	 * @ordered
	 */
	protected PartnerLinksType partnerLinks = null;

	/**
	 * The cached value of the '{@link #getIndexedProperties() <em>Indexed Properties</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIndexedProperties()
	 * @generated
	 * @ordered
	 */
	protected IndexedPropertiesType indexedProperties = null;

	/**
	 * The cached value of the '{@link #getWsdlReferences() <em>Wsdl References</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWsdlReferences()
	 * @generated
	 * @ordered
	 */
	protected WsdlReferencesType wsdlReferences = null;

	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final String LOCATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected String location = LOCATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final Object NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected Object name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getPersistenceType() <em>Persistence Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPersistenceType()
	 * @generated
	 * @ordered
	 */
	protected static final PersistenceType PERSISTENCE_TYPE_EDEFAULT = PersistenceType.FULL_LITERAL;

	/**
	 * The cached value of the '{@link #getPersistenceType() <em>Persistence Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPersistenceType()
	 * @generated
	 * @ordered
	 */
	protected PersistenceType persistenceType = PERSISTENCE_TYPE_EDEFAULT;

	/**
	 * This is true if the Persistence Type attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean persistenceTypeESet = false;

	/**
	 * The default value of the '{@link #getSuspendProcessOnUncaughtFault() <em>Suspend Process On Uncaught Fault</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuspendProcessOnUncaughtFault()
	 * @generated
	 * @ordered
	 */
	protected static final SuspendFlag SUSPEND_PROCESS_ON_UNCAUGHT_FAULT_EDEFAULT = SuspendFlag.TRUE_LITERAL;

	/**
	 * The cached value of the '{@link #getSuspendProcessOnUncaughtFault() <em>Suspend Process On Uncaught Fault</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSuspendProcessOnUncaughtFault()
	 * @generated
	 * @ordered
	 */
	protected SuspendFlag suspendProcessOnUncaughtFault = SUSPEND_PROCESS_ON_UNCAUGHT_FAULT_EDEFAULT;

	/**
	 * This is true if the Suspend Process On Uncaught Fault attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean suspendProcessOnUncaughtFaultESet = false;

	/**
	 * The default value of the '{@link #getTransactionType() <em>Transaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionType()
	 * @generated
	 * @ordered
	 */
	protected static final TransactionType TRANSACTION_TYPE_EDEFAULT = TransactionType.BEAN_LITERAL;

	/**
	 * The cached value of the '{@link #getTransactionType() <em>Transaction Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransactionType()
	 * @generated
	 * @ordered
	 */
	protected TransactionType transactionType = TRANSACTION_TYPE_EDEFAULT;

	/**
	 * This is true if the Transaction Type attribute has been set.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	protected boolean transactionTypeESet = false;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcessTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return PddPackage.Literals.PROCESS_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VersionType getVersion() {
		return version;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVersion(VersionType newVersion, NotificationChain msgs) {
		VersionType oldVersion = version;
		version = newVersion;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__VERSION, oldVersion, newVersion);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVersion(VersionType newVersion) {
		if (newVersion != version) {
			NotificationChain msgs = null;
			if (version != null)
				msgs = ((InternalEObject)version).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__VERSION, null, msgs);
			if (newVersion != null)
				msgs = ((InternalEObject)newVersion).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__VERSION, null, msgs);
			msgs = basicSetVersion(newVersion, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__VERSION, newVersion, newVersion));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartnerLinksType getPartnerLinks() {
		return partnerLinks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPartnerLinks(PartnerLinksType newPartnerLinks, NotificationChain msgs) {
		PartnerLinksType oldPartnerLinks = partnerLinks;
		partnerLinks = newPartnerLinks;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__PARTNER_LINKS, oldPartnerLinks, newPartnerLinks);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPartnerLinks(PartnerLinksType newPartnerLinks) {
		if (newPartnerLinks != partnerLinks) {
			NotificationChain msgs = null;
			if (partnerLinks != null)
				msgs = ((InternalEObject)partnerLinks).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__PARTNER_LINKS, null, msgs);
			if (newPartnerLinks != null)
				msgs = ((InternalEObject)newPartnerLinks).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__PARTNER_LINKS, null, msgs);
			msgs = basicSetPartnerLinks(newPartnerLinks, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__PARTNER_LINKS, newPartnerLinks, newPartnerLinks));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IndexedPropertiesType getIndexedProperties() {
		return indexedProperties;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIndexedProperties(IndexedPropertiesType newIndexedProperties, NotificationChain msgs) {
		IndexedPropertiesType oldIndexedProperties = indexedProperties;
		indexedProperties = newIndexedProperties;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES, oldIndexedProperties, newIndexedProperties);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIndexedProperties(IndexedPropertiesType newIndexedProperties) {
		if (newIndexedProperties != indexedProperties) {
			NotificationChain msgs = null;
			if (indexedProperties != null)
				msgs = ((InternalEObject)indexedProperties).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES, null, msgs);
			if (newIndexedProperties != null)
				msgs = ((InternalEObject)newIndexedProperties).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES, null, msgs);
			msgs = basicSetIndexedProperties(newIndexedProperties, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES, newIndexedProperties, newIndexedProperties));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WsdlReferencesType getWsdlReferences() {
		return wsdlReferences;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWsdlReferences(WsdlReferencesType newWsdlReferences, NotificationChain msgs) {
		WsdlReferencesType oldWsdlReferences = wsdlReferences;
		wsdlReferences = newWsdlReferences;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__WSDL_REFERENCES, oldWsdlReferences, newWsdlReferences);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWsdlReferences(WsdlReferencesType newWsdlReferences) {
		if (newWsdlReferences != wsdlReferences) {
			NotificationChain msgs = null;
			if (wsdlReferences != null)
				msgs = ((InternalEObject)wsdlReferences).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__WSDL_REFERENCES, null, msgs);
			if (newWsdlReferences != null)
				msgs = ((InternalEObject)newWsdlReferences).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - PddPackage.PROCESS_TYPE__WSDL_REFERENCES, null, msgs);
			msgs = basicSetWsdlReferences(newWsdlReferences, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__WSDL_REFERENCES, newWsdlReferences, newWsdlReferences));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(String newLocation) {
		String oldLocation = location;
		location = newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__LOCATION, oldLocation, location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(Object newName) {
		Object oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PersistenceType getPersistenceType() {
		return persistenceType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPersistenceType(PersistenceType newPersistenceType) {
		PersistenceType oldPersistenceType = persistenceType;
		persistenceType = newPersistenceType == null ? PERSISTENCE_TYPE_EDEFAULT : newPersistenceType;
		boolean oldPersistenceTypeESet = persistenceTypeESet;
		persistenceTypeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE, oldPersistenceType, persistenceType, !oldPersistenceTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetPersistenceType() {
		PersistenceType oldPersistenceType = persistenceType;
		boolean oldPersistenceTypeESet = persistenceTypeESet;
		persistenceType = PERSISTENCE_TYPE_EDEFAULT;
		persistenceTypeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE, oldPersistenceType, PERSISTENCE_TYPE_EDEFAULT, oldPersistenceTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetPersistenceType() {
		return persistenceTypeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SuspendFlag getSuspendProcessOnUncaughtFault() {
		return suspendProcessOnUncaughtFault;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSuspendProcessOnUncaughtFault(SuspendFlag newSuspendProcessOnUncaughtFault) {
		SuspendFlag oldSuspendProcessOnUncaughtFault = suspendProcessOnUncaughtFault;
		suspendProcessOnUncaughtFault = newSuspendProcessOnUncaughtFault == null ? SUSPEND_PROCESS_ON_UNCAUGHT_FAULT_EDEFAULT : newSuspendProcessOnUncaughtFault;
		boolean oldSuspendProcessOnUncaughtFaultESet = suspendProcessOnUncaughtFaultESet;
		suspendProcessOnUncaughtFaultESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT, oldSuspendProcessOnUncaughtFault, suspendProcessOnUncaughtFault, !oldSuspendProcessOnUncaughtFaultESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetSuspendProcessOnUncaughtFault() {
		SuspendFlag oldSuspendProcessOnUncaughtFault = suspendProcessOnUncaughtFault;
		boolean oldSuspendProcessOnUncaughtFaultESet = suspendProcessOnUncaughtFaultESet;
		suspendProcessOnUncaughtFault = SUSPEND_PROCESS_ON_UNCAUGHT_FAULT_EDEFAULT;
		suspendProcessOnUncaughtFaultESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT, oldSuspendProcessOnUncaughtFault, SUSPEND_PROCESS_ON_UNCAUGHT_FAULT_EDEFAULT, oldSuspendProcessOnUncaughtFaultESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetSuspendProcessOnUncaughtFault() {
		return suspendProcessOnUncaughtFaultESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransactionType getTransactionType() {
		return transactionType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransactionType(TransactionType newTransactionType) {
		TransactionType oldTransactionType = transactionType;
		transactionType = newTransactionType == null ? TRANSACTION_TYPE_EDEFAULT : newTransactionType;
		boolean oldTransactionTypeESet = transactionTypeESet;
		transactionTypeESet = true;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PddPackage.PROCESS_TYPE__TRANSACTION_TYPE, oldTransactionType, transactionType, !oldTransactionTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void unsetTransactionType() {
		TransactionType oldTransactionType = transactionType;
		boolean oldTransactionTypeESet = transactionTypeESet;
		transactionType = TRANSACTION_TYPE_EDEFAULT;
		transactionTypeESet = false;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.UNSET, PddPackage.PROCESS_TYPE__TRANSACTION_TYPE, oldTransactionType, TRANSACTION_TYPE_EDEFAULT, oldTransactionTypeESet));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isSetTransactionType() {
		return transactionTypeESet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case PddPackage.PROCESS_TYPE__VERSION:
				return basicSetVersion(null, msgs);
			case PddPackage.PROCESS_TYPE__PARTNER_LINKS:
				return basicSetPartnerLinks(null, msgs);
			case PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES:
				return basicSetIndexedProperties(null, msgs);
			case PddPackage.PROCESS_TYPE__WSDL_REFERENCES:
				return basicSetWsdlReferences(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case PddPackage.PROCESS_TYPE__VERSION:
				return getVersion();
			case PddPackage.PROCESS_TYPE__PARTNER_LINKS:
				return getPartnerLinks();
			case PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES:
				return getIndexedProperties();
			case PddPackage.PROCESS_TYPE__WSDL_REFERENCES:
				return getWsdlReferences();
			case PddPackage.PROCESS_TYPE__LOCATION:
				return getLocation();
			case PddPackage.PROCESS_TYPE__NAME:
				return getName();
			case PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE:
				return getPersistenceType();
			case PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT:
				return getSuspendProcessOnUncaughtFault();
			case PddPackage.PROCESS_TYPE__TRANSACTION_TYPE:
				return getTransactionType();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case PddPackage.PROCESS_TYPE__VERSION:
				setVersion((VersionType)newValue);
				return;
			case PddPackage.PROCESS_TYPE__PARTNER_LINKS:
				setPartnerLinks((PartnerLinksType)newValue);
				return;
			case PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES:
				setIndexedProperties((IndexedPropertiesType)newValue);
				return;
			case PddPackage.PROCESS_TYPE__WSDL_REFERENCES:
				setWsdlReferences((WsdlReferencesType)newValue);
				return;
			case PddPackage.PROCESS_TYPE__LOCATION:
				setLocation((String)newValue);
				return;
			case PddPackage.PROCESS_TYPE__NAME:
				setName((Object)newValue);
				return;
			case PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE:
				setPersistenceType((PersistenceType)newValue);
				return;
			case PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT:
				setSuspendProcessOnUncaughtFault((SuspendFlag)newValue);
				return;
			case PddPackage.PROCESS_TYPE__TRANSACTION_TYPE:
				setTransactionType((TransactionType)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case PddPackage.PROCESS_TYPE__VERSION:
				setVersion((VersionType)null);
				return;
			case PddPackage.PROCESS_TYPE__PARTNER_LINKS:
				setPartnerLinks((PartnerLinksType)null);
				return;
			case PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES:
				setIndexedProperties((IndexedPropertiesType)null);
				return;
			case PddPackage.PROCESS_TYPE__WSDL_REFERENCES:
				setWsdlReferences((WsdlReferencesType)null);
				return;
			case PddPackage.PROCESS_TYPE__LOCATION:
				setLocation(LOCATION_EDEFAULT);
				return;
			case PddPackage.PROCESS_TYPE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE:
				unsetPersistenceType();
				return;
			case PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT:
				unsetSuspendProcessOnUncaughtFault();
				return;
			case PddPackage.PROCESS_TYPE__TRANSACTION_TYPE:
				unsetTransactionType();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case PddPackage.PROCESS_TYPE__VERSION:
				return version != null;
			case PddPackage.PROCESS_TYPE__PARTNER_LINKS:
				return partnerLinks != null;
			case PddPackage.PROCESS_TYPE__INDEXED_PROPERTIES:
				return indexedProperties != null;
			case PddPackage.PROCESS_TYPE__WSDL_REFERENCES:
				return wsdlReferences != null;
			case PddPackage.PROCESS_TYPE__LOCATION:
				return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
			case PddPackage.PROCESS_TYPE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case PddPackage.PROCESS_TYPE__PERSISTENCE_TYPE:
				return isSetPersistenceType();
			case PddPackage.PROCESS_TYPE__SUSPEND_PROCESS_ON_UNCAUGHT_FAULT:
				return isSetSuspendProcessOnUncaughtFault();
			case PddPackage.PROCESS_TYPE__TRANSACTION_TYPE:
				return isSetTransactionType();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (location: ");
		result.append(location);
		result.append(", name: ");
		result.append(name);
		result.append(", persistenceType: ");
		if (persistenceTypeESet) result.append(persistenceType); else result.append("<unset>");
		result.append(", suspendProcessOnUncaughtFault: ");
		if (suspendProcessOnUncaughtFaultESet) result.append(suspendProcessOnUncaughtFault); else result.append("<unset>");
		result.append(", transactionType: ");
		if (transactionTypeESet) result.append(transactionType); else result.append("<unset>");
		result.append(')');
		return result.toString();
	}

} //ProcessTypeImpl