/*******************************************************************************
 * Copyright (c) 2006 University College London Software Systems Engineering
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * 	Bruno Wassermann - initial API, implementation, subsequent bug fixes
 *  Liang (Ben) Chen - BPEL 2.0 to 1.1 conversion code
 *******************************************************************************/
package uk.ac.ucl.sse.omii.bpel.abr.model_2005_09.pdd;

/**
 * Holding relevant constants for the generation of PDD files.
 *
 * @author Bruno Wassermann, written 5 Jul 2006
 */
public interface IPddConstants {
	
	// pdd file extension
	public final static String PDD_EXTENSION = "pdd"; //$NON-NLS-1$
	public final static String DOT_PDD_EXTENSION = "." + PDD_EXTENSION; //$NON-NLS-1$
	
	// constants for generating and saving model
	public final static String XML_ENCODING_UTF8 = "UTF-8"; //$NON-NLS-1$
	public final static String PREFIX_ADDRESSING = "wsa"; //$NON-NLS-1$
	public final static String NS_ADDRESSING = "http://schemas.xmlsoap.org/ws/2003/03/addressing"; //$NON-NLS-1$
	public final static String ENDPOINT_REF_ELT = "EndpointReference"; //$NON-NLS-1$
	public final static String ADDRESS_ELT = "Address"; //$NON-NLS-1$
	public final static String SERVICE_NAME_ELT = "ServiceName"; //$NON-NLS-1$
	public final static String PORT_NAME_ATTR = "PortName"; //$NON-NLS-1$
	public final static String DEFAULT_INV_HANDLER = "default:Service"; //$NON-NLS-1$
	public final static String HTTP_PROTOCOL = "http"; //$NON-NLS-1$
	public final static String COLON = ":"; //$NON-NLS-1$
	public final static String TWO_SLASHES = "//"; //$NON-NLS-1$
	public final static String SINGLE_SLASH = "/"; //$NON-NLS-1$
	public final static String AXIS_SERVICES = "/axis/services/"; //$NON-NLS-1$
	public final static String AE_SERVICES = "/active-bpel/services/"; //$NON-NLS-1$
	public final static String SERVICE_SUFFIX = "Service"; //$NON-NLS-1$
	public final static String PORT_SUFFIX = "Port"; //$NON-NLS-1$

}
