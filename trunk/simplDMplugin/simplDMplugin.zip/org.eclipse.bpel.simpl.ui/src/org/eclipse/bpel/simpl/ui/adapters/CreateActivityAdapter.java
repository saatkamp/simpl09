package org.eclipse.bpel.simpl.ui.adapters;

import org.eclipse.bpel.ui.adapters.ActivityAdapter;

public class CreateActivityAdapter extends ActivityAdapter {

}
