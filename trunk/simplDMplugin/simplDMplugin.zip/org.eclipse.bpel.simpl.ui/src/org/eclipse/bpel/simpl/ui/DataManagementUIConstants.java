package org.eclipse.bpel.simpl.ui;

public class DataManagementUIConstants {

	// The path of the icons
	public static final String ICON_PATH = "icons/";
	
	// Images
	
	// Activities
	public static final String ICON_QUERY_16 = "obj16/queryactivity.png";
	public static final String ICON_QUERY_32 = "obj20/queryactivity.png";
	public static final String ICON_INSERT_16 = "obj16/insertactivity.png";
	public static final String ICON_INSERT_32 = "obj20/insertactivity.png";
	public static final String ICON_UPDATE_16 = "obj16/updateactivity.png"; 
	public static final String ICON_UPDATE_32 = "obj20/updateactivity.png";
	public static final String ICON_DELETE_16 = "obj16/deleteactivity.png"; 
	public static final String ICON_DELETE_32 = "obj20/deleteactivity.png";
	public static final String ICON_CREATE_16 = "obj16/createactivity.png"; 
	public static final String ICON_CREATE_32 = "obj20/createactivity.png";
	public static final String ICON_DROP_16 = "obj16/dropactivity.png"; 
	public static final String ICON_DROP_32 = "obj20/dropactivity.png";
	public static final String ICON_CALL_16 = "obj16/callactivity.png"; 
	public static final String ICON_CALL_32 = "obj20/callactivity.png"; 
	public static final String ICON_RETRIEVEDATA_16 = "obj16/retrievedataactivity.png";
	public static final String ICON_RETRIEVEDATA_32 = "obj20/retrievedataactivity.png";
	
	
	
	// Property-View constants for the building of statements
	private static final String[] dataSourceTypes = new String[]{"file system", "database", "sensor net"};
	
	private static final String[] fileSystemStatements = new String[]{"GET", "PUT", "RM", "MKDIR", "MKFILE"}; 
	private static final String[] dataSourceStatements = new String[]{"SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "CALL"};
	private static final String[] sensorNetStatements = new String[]{"SELECT", "CREATE BUFFER", "DROP ALL"};
	
	public static String[] getStatements(String dataSourceType){
		String[] statements = new String[]{""};
		if (dataSourceType.contentEquals("file system")) {
			statements = fileSystemStatements;
		}else {
			if (dataSourceType.contentEquals("data source")) {
				statements = dataSourceStatements;
			}else {
				if (dataSourceType.contentEquals("sensor net")) {
					statements = sensorNetStatements;
				}
			}
		}
		return statements;
	}
	
	public static String[] getStatements(int index){
		String[] statements = new String[]{""};
		if (index==0) {
			statements = fileSystemStatements;
		}else {
			if (index==1) {
				statements = dataSourceStatements;
			}else {
				if (index==2) {
					statements = sensorNetStatements;
				}
			}
		}
		return statements;
	}
	
	public static String[] getDataSourceTypes(){
		return dataSourceTypes;
	}
}
