/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.bpel.simpl.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Delete Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Allows to delete data on a data source.
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.bpel.simpl.model.ModelPackage#getDeleteActivity()
 * @model
 * @generated
 */
public interface DeleteActivity extends DataManagementActivity {
} // DeleteActivity
