/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.bpel.simpl.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Update Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Allows to update data on a data source.
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.bpel.simpl.model.ModelPackage#getUpdateActivity()
 * @model
 * @generated
 */
public interface UpdateActivity extends DataManagementActivity {
} // UpdateActivity
