/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.bpel.simpl.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Insert Activity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <!-- begin-model-doc -->
 * Allows to insert data on a data source.
 * <!-- end-model-doc -->
 *
 *
 * @see org.eclipse.bpel.simpl.model.ModelPackage#getInsertActivity()
 * @model
 * @generated
 */
public interface InsertActivity extends DataManagementActivity {
} // InsertActivity
