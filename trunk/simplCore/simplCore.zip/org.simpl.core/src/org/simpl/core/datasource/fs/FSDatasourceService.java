package org.simpl.core.datasource.fs;

import org.eclipse.emf.ecore.sdo.EDataObject;
import org.simpl.core.datasource.ConnectionException;
import org.simpl.core.datasource.DataException;
import org.simpl.core.datasource.DatasourceService;

/**
 * <p>
 * Implements the {@link DatasourceService} interface. The implementation
 * supports file systems.
 * </p>
 * 
 * @author hahnml, StuProA: SIMPL, 25.11.2009
 *
 */
public class FSDatasourceService implements DatasourceService {

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#closeConnection()
	 */
	@Override
	public boolean closeConnection() throws ConnectionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#executeStatement(java.lang.String)
	 */
	@Override
	public EDataObject executeStatement(String statement)
			throws ConnectionException, DataException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#executeStatement(java.lang.String, org.eclipse.emf.ecore.sdo.EDataObject)
	 */
	@Override
	public EDataObject executeStatement(String statement, EDataObject data)
			throws ConnectionException, DataException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#openConnection()
	 */
	@Override
	public boolean openConnection() throws ConnectionException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#sendStatement(java.lang.String)
	 */
	@Override
	public boolean sendStatement(String statement) throws ConnectionException,
			DataException {
		// TODO Auto-generated method stub
		return false;
	}

	/* (non-Javadoc)
	 * @see org.simpl.core.datasource.DatasourceService#sendStatement(java.lang.String, org.eclipse.emf.ecore.sdo.EDataObject)
	 */
	@Override
	public boolean sendStatement(String statement, EDataObject data)
			throws ConnectionException, DataException {
		// TODO Auto-generated method stub
		return false;
	}

}

