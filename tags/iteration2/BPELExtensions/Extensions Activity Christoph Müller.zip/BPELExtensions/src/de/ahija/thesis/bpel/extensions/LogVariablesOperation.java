/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// $URL::                                                                                                                                                                                                                     $:
// $Rev::         $:
// $Date::                      $:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright © 2009 Christoph Müller
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
package de.ahija.thesis.bpel.extensions;

import javax.xml.namespace.QName;

import org.apache.ode.bpel.common.FaultException;
import org.apache.ode.bpel.extension.ExtensionOperation;
import org.apache.ode.bpel.rtrep.common.extension.ExtensionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This {@link ExtensionOperation} is able to log ODE variables via an slf4j {@link Logger}.
 * <p>
 * See <code>{http://ahija.de/thesis/bpel/extensions/logging}:logVariables</code>.
 *
 * @author Christoph Müller
 *
 * @version created 13.11.2009 - $Id::                                                                                     $:
 */
public class LogVariablesOperation
  extends ALogOperation {

  private static final Logger LOG = LoggerFactory.getLogger(LogVariablesOperation.class);

  /** {@inheritDoc} */
  @Override
  protected void runSync(ExtensionContext context, Element element) throws FaultException {
    try {
      // contains all setting to enable logging (Logger, Level, Header, Footer)
      LogWrapper logWrapper = createLogWrapper(element);

      StringBuilder messageBuilder = new StringBuilder();

      // we retrieve all child nodes and write them in message builder
      NodeList variableNodes = element.getElementsByTagNameNS(LogExtensionBundle.NAMESPACE, "variable");
      if (variableNodes.getLength() == 0) {
        LOG.warn("No variable specified in\n" + nodeToString(element));
        return;
      }

      for (int i = 0; i < variableNodes.getLength(); i++) {
        Element variableElement = (Element) variableNodes.item(i);
        Attr variableAttribute = variableElement.getAttributeNode("name");

        if (variableAttribute == null) {
          LOG.warn("No variable name specified in\n" + nodeToString(element) + "\n" + getSourceInfo(context));
          continue;
        }

        String variableName = variableAttribute.getValue();
        if (!context.isVariableVisible(variableName)) {
          LOG.warn("Variable " + variableName + " is not visible or does not exist in " + getSourceInfo(context));
          continue;
        }

        Node variableContentNode = context.readVariable(variableName);
        String nodeAsString = nodeToString(variableContentNode);

        if (nodeAsString.length() > 0) {
          if (messageBuilder.length() > 0) {
            messageBuilder.append('\n');
          }
          messageBuilder.append(nodeAsString);
        }
      }

      logWrapper.log(context.getActivityName(), messageBuilder.toString());
    } catch (Exception e) {
      LOG.error("Exception in " + LogVariablesOperation.class.getSimpleName(), e);
      throw new FaultException(new QName(LogExtensionBundle.NAMESPACE, "exception"), e);
    }
  }
}
