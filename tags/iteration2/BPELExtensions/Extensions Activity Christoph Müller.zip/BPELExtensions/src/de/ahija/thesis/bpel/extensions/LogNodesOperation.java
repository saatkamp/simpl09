/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// $URL::                                                                                                                                                                                                                     $:
// $Rev::         $:
// $Date::                      $:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright © 2009 Christoph Müller
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
package de.ahija.thesis.bpel.extensions;

import javax.xml.namespace.QName;

import org.apache.ode.bpel.common.FaultException;
import org.apache.ode.bpel.extension.ExtensionOperation;
import org.apache.ode.bpel.rtrep.common.extension.ExtensionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This {@link ExtensionOperation} is able to log XML nodes via an slf4j {@link Logger}.
 * <p>
 * See <code>{http://ahija.de/thesis/bpel/extensions/logging}:logNodes</code>.
 *
 * @author Christoph Müller
 *
 * @version created 13.11.2009 - $Id::                                                                                     $:
 */
public class LogNodesOperation
  extends ALogOperation {

  private static final Logger LOG = LoggerFactory.getLogger(LogNodesOperation.class);

  /** {@inheritDoc} */
  @Override
  protected void runSync(ExtensionContext context, Element element) throws FaultException {
    try {
      // contains all setting to enable logging (Logger, Level, Header, Footer)
      LogWrapper logWrapper = createLogWrapper(element);

      StringBuilder messageBuilder = new StringBuilder();

      // we retrieve all child nodes and write them in message builder
      NodeList children = element.getChildNodes();
      for (int i = 0; i < children.getLength(); i++) {
        Node thisNode = children.item(i);

        if (thisNode.getNodeType() == Node.TEXT_NODE) {
          // we ignore text nodes at this level
          continue;
        }
        if (thisNode instanceof Element) {
          Element asElement = (Element) thisNode;
          if (asElement.getNamespaceURI().equals(LogExtensionBundle.NAMESPACE)
            && asElement.getLocalName().equals("header")
              || asElement.getLocalName().equals("footer")) {
            // we skip headers and footers
            continue;
          }
        }

        String nodeAsString = nodeToString(thisNode);
        if (nodeAsString.length() > 0) {
          if (messageBuilder.length() > 0) {
            messageBuilder.append('\n');
          }
          messageBuilder.append(nodeAsString);
        }
      }

      logWrapper.log(context.getActivityName(), messageBuilder.toString());
    } catch (Exception e) {
      LOG.error("Exception in " + LogNodesOperation.class.getSimpleName(), e);
      throw new FaultException(new QName(LogExtensionBundle.NAMESPACE, "exception"), e);
    }
  }
}
