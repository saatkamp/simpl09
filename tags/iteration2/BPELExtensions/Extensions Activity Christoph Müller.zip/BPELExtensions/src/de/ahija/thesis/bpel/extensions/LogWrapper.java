/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// $URL::                                                                                                                                                                                                                     $:
// $Rev::         $:
// $Date::                      $:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright © 2009 Christoph Müller
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
package de.ahija.thesis.bpel.extensions;

import org.slf4j.Logger;

/**
 * This class wraps a {@link Logger} call and is initialized by the configuration found in
 * <code>logging-extension.xsd</code>.
 *
 * @author Christoph Müller
 * @version created 16.11.2009 - $Id:: $:
 */
public class LogWrapper {

  private final Logger m_logger;
  private final String m_level;
  private final String m_header;
  private final String m_footer;

  public LogWrapper(Logger logger, String level, String header, String footer) {
    this.m_logger = logger;
    this.m_level = level;
    this.m_header = header;
    this.m_footer = footer;
  }

  public void log(String activityName, String message) {
    Logger logger = ALogOperation.EXT_LOG;
    if (this.m_logger != null) {
      logger = this.m_logger;
    }

    StringBuilder messageBuilder = new StringBuilder();
    messageBuilder.append("Logging by activity ");
    messageBuilder.append(activityName);

    if (this.m_header != null && this.m_header.length() > 0) {
      messageBuilder.append('\n');
      messageBuilder.append(this.m_header);
    }
    if (message != null && message.length() > 0) {
      messageBuilder.append('\n');
      messageBuilder.append(message);
    }
    if (this.m_footer != null && this.m_footer.length() > 0) {
      messageBuilder.append('\n');
      messageBuilder.append(this.m_footer);
    }

    message = messageBuilder.toString();

    if (this.m_level == null || this.m_level.equalsIgnoreCase("INFO")) {
      logger.info(message);
    } else if (this.m_level.equalsIgnoreCase("TRACE")) {
      logger.trace(message);
    } else if (this.m_level.equalsIgnoreCase("DEBUG")) {
      logger.debug(message);
    } else if (this.m_level.equalsIgnoreCase("WARN")) {
      logger.warn(message);
    } else if (this.m_level.equalsIgnoreCase("ERROR")) {
      logger.error(message);
    } else {
      logger.warn("Unknown logger level " + this.m_level);
      logger.info(message);
    }
  }
}
