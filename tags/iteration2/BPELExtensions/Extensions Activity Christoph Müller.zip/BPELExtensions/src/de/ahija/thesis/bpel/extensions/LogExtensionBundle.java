/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// $URL::                                                                                                                                                                                                                     $:
// $Rev::         $:
// $Date::                      $:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright © 2009 Christoph Müller
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
package de.ahija.thesis.bpel.extensions;

import org.apache.ode.bpel.rtrep.common.extension.AbstractExtensionBundle;

/**
 * This {@link AbstractExtensionBundle} describes a logging activity.
 *
 * @author Christoph Müller
 *
 * @version created 13.11.2009 - $Id::                                                                                     $:
 */
public class LogExtensionBundle
  extends AbstractExtensionBundle {

  public static final String NAMESPACE = "http://ahija.de/thesis/bpel/extensions/logging";

  /** {@inheritDoc} */
  @Override
  public String getNamespaceURI() {
    return NAMESPACE;
  }

  /** {@inheritDoc} */
  @Override
  public void registerExtensionActivities() {
    super.registerExtensionOperation("logNodes", LogNodesOperation.class);
    super.registerExtensionOperation("logVariables", LogVariablesOperation.class);
  }
}
