/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// $URL::                                                                                                                                                                                                                     $:
// $Rev::         $:
// $Date::                      $:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Copyright © 2009 Christoph Müller
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
package de.ahija.thesis.bpel.extensions;

import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.ode.bpel.rtrep.common.extension.AbstractSyncExtensionOperation;
import org.apache.ode.bpel.rtrep.common.extension.ExtensionContext;
import org.apache.ode.bpel.rtrep.v2.DebugInfo;
import org.apache.ode.bpel.rtrep.v2.OActivity;
import org.apache.ode.bpel.rtrep.v2.OProcess;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Abstract parent class for logging operations.
 *
 * @author Christoph Müller
 *
 * @version created 16.11.2009 - $Id::                                                                                     $:
 */
public abstract class ALogOperation
  extends AbstractSyncExtensionOperation {

  private Transformer m_xmlTransformer;

  /** {@link Logger} for non specified logger names. */
  static final Logger EXT_LOG = LoggerFactory.getLogger("de.ahija.thesis.bpel.extensions.ExtLog");

  protected Logger getLogger(String loggerName) {
    if (loggerName == null || loggerName.length() == 0) {
      return EXT_LOG;
    }

    // we create or retrieve the correct logger by its Name
    return LoggerFactory.getLogger(loggerName);
  }

  /**
   * Parses an <code>{http://ahija.de/thesis/bpel/extensions/logging}:logNodes</code> or
   * <code>{http://ahija.de/thesis/bpel/extensions/logging}:logVariables</code> and wraps the configuration
   * into an {@link LogWrapper}.
   */
  protected LogWrapper createLogWrapper(Element element) throws Exception {
    Logger logger = EXT_LOG;
    Attr attributeLoggerName = element.getAttributeNode("loggerName");
    if (attributeLoggerName != null) {
      logger = getLogger(attributeLoggerName.getValue());
    }

    String level = "INFO";
    Attr attributeLevel = element.getAttributeNode("level");
    if (attributeLevel != null) {
      level = attributeLevel.getValue();
    }

    String header = null;
    NodeList headerElementList = element.getElementsByTagNameNS(LogExtensionBundle.NAMESPACE, "header");
    if (headerElementList.getLength() > 0) {
      Element headerElement = (Element) headerElementList.item(0);
      header = nodeListToString(headerElement.getChildNodes());
    }

    String footer = null;
    NodeList footerElementList = element.getElementsByTagNameNS(LogExtensionBundle.NAMESPACE, "footer");
    if (footerElementList.getLength() > 0) {
      Element footerElement = (Element) footerElementList.item(0);
      header = nodeListToString(footerElement.getChildNodes());
    }

    return new LogWrapper(logger, level, header, footer);
  }

  protected String nodeToString(Node node) throws Exception {
    Source source = new DOMSource(node);

    StringWriter writer = new StringWriter();
    Result result = new StreamResult(writer);

    Transformer transformer = getTransformer();
    transformer.transform(source, result);

    return writer.toString();
  }

  protected String nodeListToString(NodeList nodeList) throws Exception {
    StringWriter writer = new StringWriter();
    Result result = new StreamResult(writer);

    Transformer transformer = getTransformer();

    for (int i = 0; i < nodeList.getLength(); i++) {
      Node thisNode = nodeList.item(i);

      Source source = new DOMSource(thisNode);
      transformer.transform(source, result);
    }

    return writer.toString();
  }

  private synchronized Transformer getTransformer() throws Exception {
    if (this.m_xmlTransformer == null) {
      this.m_xmlTransformer = TransformerFactory.newInstance().newTransformer();
      this.m_xmlTransformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
      this.m_xmlTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
      this.m_xmlTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
    }
    return this.m_xmlTransformer;
  }

  /** Tries to get usefull information about the activity called by the extension! */
  protected String getSourceInfo(ExtensionContext context) {
    StringBuilder sourceBuilder = new StringBuilder();

    OProcess process = context.getOActivity().getOwner();
    sourceBuilder.append("{");
    sourceBuilder.append(process.targetNamespace);
    sourceBuilder.append("}");
    sourceBuilder.append(process.processName);

    DebugInfo debugInfo = context.getOActivity().debugInfo;
    if (debugInfo != null && debugInfo.startLine > 0) {
      if (sourceBuilder.length() > 0) {
        sourceBuilder.append("; ");
      }
      sourceBuilder.append("line ");
      sourceBuilder.append(debugInfo.startLine);
    }

    OActivity activity = context.getOActivity();
    if (activity != null && activity.name != null) {
      if (sourceBuilder.length() > 0) {
        sourceBuilder.append("; ");
      }
      sourceBuilder.append("activity name: ");
      sourceBuilder.append(activity.name);
    }

    if (sourceBuilder.length() == 0) {
      return "no debug available";
    }

    return sourceBuilder.toString();
  }
}
