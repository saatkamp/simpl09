Apache Ode
==========

This is the default deployment directory for Apache Ode process bundles.

You may configure the location of the deployment directory using the
"ode-axis2.working.dir" property in ode-axis2.properties.

e.g. ode-axis2.working.dir=${org.apache.ode.configDir}/../

The "processes" directory will be created as sub-directory of this location.


